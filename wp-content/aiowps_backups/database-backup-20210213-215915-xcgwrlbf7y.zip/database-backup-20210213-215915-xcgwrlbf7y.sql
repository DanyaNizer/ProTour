-- All In One WP Security & Firewall 4.4.6
-- MySQL dump
-- 2021-02-13 18:59:15

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `wp_actionscheduler_actions`;

CREATE TABLE `wp_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheduled_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `args` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `last_attempt_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook` (`hook`),
  KEY `status` (`status`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id` (`claim_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_actionscheduler_actions` VALUES("7","aioseo_admin_notifications_update","pending","2021-01-28 01:00:00","2021-01-28 01:00:00","[]","O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1611795600;s:18:\"\0*\0first_timestamp\";i:1611795600;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1611795600;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}","1","0","0000-00-00 00:00:00","0000-00-00 00:00:00","0","");
INSERT INTO `wp_actionscheduler_actions` VALUES("9","aioseo_cleanup_action_scheduler","pending","2021-01-28 04:26:48","2021-01-28 04:26:48","[]","O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1611808008;s:18:\"\0*\0first_timestamp\";i:1611808008;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1611808008;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}","1","0","0000-00-00 00:00:00","0000-00-00 00:00:00","0","");
INSERT INTO `wp_actionscheduler_actions` VALUES("10","aioseo_cleanup_action_scheduler","complete","0000-00-00 00:00:00","0000-00-00 00:00:00","[]","O:28:\"ActionScheduler_NullSchedule\":0:{}","1","1","2021-01-27 04:26:50","2021-01-27 07:26:50","0","");
INSERT INTO `wp_actionscheduler_actions` VALUES("11","action_scheduler/migration_hook","complete","2021-01-27 04:27:48","2021-01-27 04:27:48","[]","O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1611721668;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1611721668;}","2","1","2021-01-27 04:27:48","2021-01-27 07:27:48","0","");
INSERT INTO `wp_actionscheduler_actions` VALUES("12","aioseo_image_sitemap_scan","complete","2021-01-27 04:27:01","2021-01-27 04:27:01","[]","O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1611721621;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1611721621;}","1","1","2021-01-27 04:27:49","2021-01-27 07:27:49","0","");
INSERT INTO `wp_actionscheduler_actions` VALUES("13","aioseo_image_sitemap_scan","pending","2021-01-27 04:27:59","2021-01-27 04:27:59","[]","O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1611721679;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1611721679;}","1","0","0000-00-00 00:00:00","0000-00-00 00:00:00","0","");


DROP TABLE IF EXISTS `wp_actionscheduler_claims`;

CREATE TABLE `wp_actionscheduler_claims` (
  `claim_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`claim_id`),
  KEY `date_created_gmt` (`date_created_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_actionscheduler_groups`;

CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_actionscheduler_groups` VALUES("1","aioseo");
INSERT INTO `wp_actionscheduler_groups` VALUES("2","action-scheduler-migration");


DROP TABLE IF EXISTS `wp_actionscheduler_logs`;

CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `log_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_actionscheduler_logs` VALUES("1","7","action created","2021-01-27 04:26:47","2021-01-27 04:26:47");
INSERT INTO `wp_actionscheduler_logs` VALUES("2","8","action created","2021-01-27 04:26:47","2021-01-27 04:26:47");
INSERT INTO `wp_actionscheduler_logs` VALUES("3","9","action created","2021-01-27 04:26:48","2021-01-27 04:26:48");
INSERT INTO `wp_actionscheduler_logs` VALUES("4","10","action created","2021-01-27 04:26:48","2021-01-27 04:26:48");
INSERT INTO `wp_actionscheduler_logs` VALUES("5","11","action created","2021-01-27 04:26:49","2021-01-27 04:26:49");
INSERT INTO `wp_actionscheduler_logs` VALUES("6","8","action started via WP Cron","2021-01-27 04:26:50","2021-01-27 04:26:50");
INSERT INTO `wp_actionscheduler_logs` VALUES("7","8","action complete via WP Cron","2021-01-27 04:26:50","2021-01-27 04:26:50");
INSERT INTO `wp_actionscheduler_logs` VALUES("8","10","action started via WP Cron","2021-01-27 04:26:50","2021-01-27 04:26:50");
INSERT INTO `wp_actionscheduler_logs` VALUES("9","10","action complete via WP Cron","2021-01-27 04:26:50","2021-01-27 04:26:50");
INSERT INTO `wp_actionscheduler_logs` VALUES("10","12","action created","2021-01-27 04:26:51","2021-01-27 04:26:51");
INSERT INTO `wp_actionscheduler_logs` VALUES("11","11","action started via WP Cron","2021-01-27 04:27:48","2021-01-27 04:27:48");
INSERT INTO `wp_actionscheduler_logs` VALUES("12","11","action complete via WP Cron","2021-01-27 04:27:48","2021-01-27 04:27:48");
INSERT INTO `wp_actionscheduler_logs` VALUES("13","12","action started via WP Cron","2021-01-27 04:27:48","2021-01-27 04:27:48");
INSERT INTO `wp_actionscheduler_logs` VALUES("14","12","action complete via WP Cron","2021-01-27 04:27:49","2021-01-27 04:27:49");
INSERT INTO `wp_actionscheduler_logs` VALUES("15","13","action created","2021-01-27 04:27:49","2021-01-27 04:27:49");


DROP TABLE IF EXISTS `wp_aioseo_notifications`;

CREATE TABLE `wp_aioseo_notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(13) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `notification_id` bigint(20) unsigned DEFAULT NULL,
  `notification_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `button1_label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button1_action` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button2_label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button2_action` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dismissed` tinyint(1) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ndx_aioseo_notifications_slug` (`slug`),
  KEY `ndx_aioseo_notifications_dates` (`start`,`end`),
  KEY `ndx_aioseo_notifications_type` (`type`),
  KEY `ndx_aioseo_notifications_dismissed` (`dismissed`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_aioseo_notifications` VALUES("1","6010ebda7a2b0","Conflicting Plugins Detected","Warning: AIOSEO has detected other active SEO or sitemap plugins. We recommend that you deactivate the following plugins to prevent any conflicts:<ul><li><strong>Google XML Sitemap Generator</strong></li></ul>","error","[\"all\"]","","conflicting-plugins","2021-01-27 04:28:10","","Fix Now","http://action#sitemap/deactivate-conflicting-plugins?refresh","Напомнить позже","http://action#notification/conflicting-plugins-reminder","0","2021-01-27 04:28:10","2021-01-27 04:28:20");


DROP TABLE IF EXISTS `wp_aioseo_posts`;

CREATE TABLE `wp_aioseo_posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keyphrases` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `page_analysis` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `canonical_url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_object_type` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `og_image_type` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `og_image_custom_url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_image_custom_fields` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_custom_image_width` int(11) DEFAULT NULL,
  `og_custom_image_height` int(11) DEFAULT NULL,
  `og_video` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_custom_url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_article_section` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_article_tags` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_use_og` tinyint(1) DEFAULT 0,
  `twitter_card` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `twitter_image_type` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `twitter_image_custom_url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_image_custom_fields` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_score` int(11) NOT NULL DEFAULT 0,
  `schema_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schema_type_options` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pillar_content` tinyint(1) DEFAULT NULL,
  `robots_default` tinyint(1) NOT NULL DEFAULT 1,
  `robots_noindex` tinyint(1) NOT NULL DEFAULT 0,
  `robots_noarchive` tinyint(1) NOT NULL DEFAULT 0,
  `robots_nosnippet` tinyint(1) NOT NULL DEFAULT 0,
  `robots_nofollow` tinyint(1) NOT NULL DEFAULT 0,
  `robots_noimageindex` tinyint(1) NOT NULL DEFAULT 0,
  `robots_noodp` tinyint(1) NOT NULL DEFAULT 0,
  `robots_notranslate` tinyint(1) NOT NULL DEFAULT 0,
  `robots_max_snippet` int(11) DEFAULT NULL,
  `robots_max_videopreview` int(11) DEFAULT NULL,
  `robots_max_imagepreview` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'large',
  `tabs` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `images` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_scan_date` datetime DEFAULT NULL,
  `priority` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frequency` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `videos` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_thumbnail` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_scan_date` datetime DEFAULT NULL,
  `location` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `local_seo` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ndx_aioseo_posts_post_id` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_aioseo_posts` VALUES("1","1","","","","","","","","","default","default","","","","","","","","","0","default","default","","","","","0","","","","1","0","0","0","0","0","0","0","","","large","","","2021-01-27 04:27:49","","","","","","","","2021-01-27 04:27:49","2021-01-27 04:27:49");
INSERT INTO `wp_aioseo_posts` VALUES("2","2","","","","","","","","","default","default","","","","","","","","","0","default","default","","","","","0","","","","1","0","0","0","0","0","0","0","","","large","","","2021-01-27 04:27:49","","","","","","","","2021-01-27 04:27:49","2021-01-27 04:27:49");


DROP TABLE IF EXISTS `wp_aiowps_events`;

CREATE TABLE `wp_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_aiowps_events` VALUES("1","404","","0","2021-01-29 02:29:58","127.0.0.1","","/?page_id=8","","");


DROP TABLE IF EXISTS `wp_aiowps_failed_logins`;

CREATE TABLE `wp_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_global_meta`;

CREATE TABLE `wp_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_activity`;

CREATE TABLE `wp_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `logout_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_lockdown`;

CREATE TABLE `wp_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `release_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_permanent_block`;

CREATE TABLE `wp_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_commentmeta`;

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_comments`;

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_comments` VALUES("1","1","Автор комментария","wapuu@wordpress.example","https://wordpress.org/","","2021-01-27 07:04:56","2021-01-27 04:04:56","Привет! Это комментарий.
Чтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.
Аватары авторов комментариев загружаются с сервиса <a href=\"https://ru.gravatar.com\">Gravatar</a>.","0","1","","comment","0","0");


DROP TABLE IF EXISTS `wp_links`;

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_options`;

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=294 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_options` VALUES("1","siteurl","http://protur.local","yes");
INSERT INTO `wp_options` VALUES("2","home","http://protur.local","yes");
INSERT INTO `wp_options` VALUES("3","blogname","ProTur","yes");
INSERT INTO `wp_options` VALUES("4","blogdescription","Ещё один сайт на WordPress","yes");
INSERT INTO `wp_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `wp_options` VALUES("6","admin_email","d359753@gmail.com","yes");
INSERT INTO `wp_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `wp_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `wp_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `wp_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `wp_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `wp_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `wp_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `wp_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `wp_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `wp_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `wp_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `wp_options` VALUES("18","default_category","1","yes");
INSERT INTO `wp_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `wp_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `wp_options` VALUES("21","default_pingback_flag","1","yes");
INSERT INTO `wp_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `wp_options` VALUES("23","date_format","d.m.Y","yes");
INSERT INTO `wp_options` VALUES("24","time_format","H:i","yes");
INSERT INTO `wp_options` VALUES("25","links_updated_date_format","d.m.Y H:i","yes");
INSERT INTO `wp_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `wp_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `wp_options` VALUES("28","permalink_structure","/%year%/%monthnum%/%day%/%postname%/","yes");
INSERT INTO `wp_options` VALUES("29","rewrite_rules","a:101:{s:16:\"xmlsitemap\\.xml$\";s:25:\"index.php?xml-sitemap=xml\";s:16:\"rsssitemap\\.xml$\";s:25:\"index.php?xml-sitemap=rss\";s:15:\"rsslatest\\.xml$\";s:28:\"index.php?xml-sitemap=rssnew\";s:17:\"htmlsitemap\\.htm$\";s:26:\"index.php?xml-sitemap=html\";s:16:\"xmlsitemap\\.xsl$\";s:25:\"index.php?xml-sitemap=xsl\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:13:\"favicon\\.ico$\";s:19:\"index.php?favicon=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}","yes");
INSERT INTO `wp_options` VALUES("30","hack_file","0","yes");
INSERT INTO `wp_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `wp_options` VALUES("32","moderation_keys","","no");
INSERT INTO `wp_options` VALUES("33","active_plugins","a:6:{i:0;s:30:\"advanced-custom-fields/acf.php\";i:1;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:2;s:36:\"contact-form-7/wp-contact-form-7.php\";i:3;s:21:\"imsanity/imsanity.php\";i:4;s:57:\"simple-share-buttons-adder/simple-share-buttons-adder.php\";i:5;s:63:\"www-xml-sitemap-generator-org/www-xml-sitemap-generator-org.php\";}","yes");
INSERT INTO `wp_options` VALUES("34","category_base","","yes");
INSERT INTO `wp_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `wp_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `wp_options` VALUES("37","gmt_offset","3","yes");
INSERT INTO `wp_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `wp_options` VALUES("39","recently_edited","a:2:{i:0;s:77:\"E:\\Program\\OpenServer\\domains\\protur.local/wp-content/themes/protur/style.css\";i:2;s:0:\"\";}","no");
INSERT INTO `wp_options` VALUES("40","template","protur","yes");
INSERT INTO `wp_options` VALUES("41","stylesheet","protur","yes");
INSERT INTO `wp_options` VALUES("42","comment_registration","0","yes");
INSERT INTO `wp_options` VALUES("43","html_type","text/html","yes");
INSERT INTO `wp_options` VALUES("44","use_trackback","0","yes");
INSERT INTO `wp_options` VALUES("45","default_role","subscriber","yes");
INSERT INTO `wp_options` VALUES("46","db_version","49752","yes");
INSERT INTO `wp_options` VALUES("47","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `wp_options` VALUES("48","upload_path","","yes");
INSERT INTO `wp_options` VALUES("49","blog_public","1","yes");
INSERT INTO `wp_options` VALUES("50","default_link_category","2","yes");
INSERT INTO `wp_options` VALUES("51","show_on_front","posts","yes");
INSERT INTO `wp_options` VALUES("52","tag_base","","yes");
INSERT INTO `wp_options` VALUES("53","show_avatars","1","yes");
INSERT INTO `wp_options` VALUES("54","avatar_rating","G","yes");
INSERT INTO `wp_options` VALUES("55","upload_url_path","","yes");
INSERT INTO `wp_options` VALUES("56","thumbnail_size_w","150","yes");
INSERT INTO `wp_options` VALUES("57","thumbnail_size_h","150","yes");
INSERT INTO `wp_options` VALUES("58","thumbnail_crop","1","yes");
INSERT INTO `wp_options` VALUES("59","medium_size_w","300","yes");
INSERT INTO `wp_options` VALUES("60","medium_size_h","300","yes");
INSERT INTO `wp_options` VALUES("61","avatar_default","mystery","yes");
INSERT INTO `wp_options` VALUES("62","large_size_w","1024","yes");
INSERT INTO `wp_options` VALUES("63","large_size_h","1024","yes");
INSERT INTO `wp_options` VALUES("64","image_default_link_type","none","yes");
INSERT INTO `wp_options` VALUES("65","image_default_size","","yes");
INSERT INTO `wp_options` VALUES("66","image_default_align","","yes");
INSERT INTO `wp_options` VALUES("67","close_comments_for_old_posts","0","yes");
INSERT INTO `wp_options` VALUES("68","close_comments_days_old","14","yes");
INSERT INTO `wp_options` VALUES("69","thread_comments","1","yes");
INSERT INTO `wp_options` VALUES("70","thread_comments_depth","5","yes");
INSERT INTO `wp_options` VALUES("71","page_comments","0","yes");
INSERT INTO `wp_options` VALUES("72","comments_per_page","50","yes");
INSERT INTO `wp_options` VALUES("73","default_comments_page","newest","yes");
INSERT INTO `wp_options` VALUES("74","comment_order","asc","yes");
INSERT INTO `wp_options` VALUES("75","sticky_posts","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("76","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("77","widget_text","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("78","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("79","uninstall_plugins","a:0:{}","no");
INSERT INTO `wp_options` VALUES("80","timezone_string","","yes");
INSERT INTO `wp_options` VALUES("81","page_for_posts","0","yes");
INSERT INTO `wp_options` VALUES("82","page_on_front","0","yes");
INSERT INTO `wp_options` VALUES("83","default_post_format","0","yes");
INSERT INTO `wp_options` VALUES("84","link_manager_enabled","0","yes");
INSERT INTO `wp_options` VALUES("85","finished_splitting_shared_terms","1","yes");
INSERT INTO `wp_options` VALUES("86","site_icon","0","yes");
INSERT INTO `wp_options` VALUES("87","medium_large_size_w","768","yes");
INSERT INTO `wp_options` VALUES("88","medium_large_size_h","0","yes");
INSERT INTO `wp_options` VALUES("89","wp_page_for_privacy_policy","3","yes");
INSERT INTO `wp_options` VALUES("90","show_comments_cookies_opt_in","1","yes");
INSERT INTO `wp_options` VALUES("91","admin_email_lifespan","1627272291","yes");
INSERT INTO `wp_options` VALUES("92","disallowed_keys","","no");
INSERT INTO `wp_options` VALUES("93","comment_previously_approved","1","yes");
INSERT INTO `wp_options` VALUES("94","auto_plugin_theme_update_emails","a:0:{}","no");
INSERT INTO `wp_options` VALUES("95","initial_db_version","48748","yes");
INSERT INTO `wp_options` VALUES("96","wp_user_roles","a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:80:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:17:\"aioseo_manage_seo\";b:1;s:19:\"aioseo_setup_wizard\";b:1;s:23:\"aioseo_general_settings\";b:1;s:33:\"aioseo_search_appearance_settings\";b:1;s:31:\"aioseo_social_networks_settings\";b:1;s:23:\"aioseo_sitemap_settings\";b:1;s:30:\"aioseo_internal_links_settings\";b:1;s:25:\"aioseo_redirects_settings\";b:1;s:28:\"aioseo_seo_analysis_settings\";b:1;s:21:\"aioseo_tools_settings\";b:1;s:31:\"aioseo_feature_manager_settings\";b:1;s:20:\"aioseo_page_analysis\";b:1;s:28:\"aioseo_page_general_settings\";b:1;s:29:\"aioseo_page_advanced_settings\";b:1;s:27:\"aioseo_page_schema_settings\";b:1;s:27:\"aioseo_page_social_settings\";b:1;s:25:\"aioseo_local_seo_settings\";b:1;s:20:\"aioseo_about_us_page\";b:1;s:12:\"aioseo_admin\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:39:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:20:\"aioseo_page_analysis\";b:1;s:28:\"aioseo_page_general_settings\";b:1;s:29:\"aioseo_page_advanced_settings\";b:1;s:27:\"aioseo_page_schema_settings\";b:1;s:27:\"aioseo_page_social_settings\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:15:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"aioseo_page_analysis\";b:1;s:28:\"aioseo_page_general_settings\";b:1;s:29:\"aioseo_page_advanced_settings\";b:1;s:27:\"aioseo_page_schema_settings\";b:1;s:27:\"aioseo_page_social_settings\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}","yes");
INSERT INTO `wp_options` VALUES("97","fresh_site","1","yes");
INSERT INTO `wp_options` VALUES("98","WPLANG","ru_RU","yes");
INSERT INTO `wp_options` VALUES("99","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("100","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("101","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("102","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("103","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("104","sidebars_widgets","a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `wp_options` VALUES("105","cron","a:10:{i:1611878699;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1611893097;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1611893099;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1611893116;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1611893119;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1611895723;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1611901690;a:1:{s:9:\"xmsg_ping\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1612411498;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1613245723;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `wp_options` VALUES("106","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("107","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("108","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("109","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("110","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("111","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("112","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("113","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("114","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("116","recovery_keys","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("118","theme_mods_twentytwenty","a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1611721033;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-2\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}}}}","yes");
INSERT INTO `wp_options` VALUES("129","_site_transient_timeout_browser_94fb6483abf307a4bafac80827dcc22a","1612325118","no");
INSERT INTO `wp_options` VALUES("130","_site_transient_browser_94fb6483abf307a4bafac80827dcc22a","a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"87.0.4280.141\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `wp_options` VALUES("131","_site_transient_timeout_php_check_f9714bbe413cc376a70847d9c1f86fcc","1612325118","no");
INSERT INTO `wp_options` VALUES("132","_site_transient_php_check_f9714bbe413cc376a70847d9c1f86fcc","a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}","no");
INSERT INTO `wp_options` VALUES("151","finished_updating_comment_type","1","yes");
INSERT INTO `wp_options` VALUES("152","recently_activated","a:5:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:1611722559;s:36:\"contact-form-7/wp-contact-form-7.php\";i:1611722559;s:63:\"www-xml-sitemap-generator-org/www-xml-sitemap-generator-org.php\";i:1611722559;s:43:\"all-in-one-seo-pack/all_in_one_seo_pack.php\";i:1611721701;s:19:\"akismet/akismet.php\";i:1611720483;}","yes");
INSERT INTO `wp_options` VALUES("155","widget_akismet_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("162","wpcf7","a:2:{s:7:\"version\";s:5:\"5.3.2\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1611720523;s:7:\"version\";s:5:\"5.3.2\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}","yes");
INSERT INTO `wp_options` VALUES("169","aiowpsec_db_version","1.9","yes");
INSERT INTO `wp_options` VALUES("170","aio_wp_security_configs","a:95:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:1:\"1\";s:25:\"aiowps_prevent_hotlinking\";s:1:\"1\";s:28:\"aiowps_enable_login_lockdown\";s:1:\"1\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";i:3;s:24:\"aiowps_retry_time_period\";i:5;s:26:\"aiowps_lockout_time_length\";i:60;s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"9boae3otjbi5x7b7q6kf\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:1:\"1\";s:34:\"aiowps_enable_custom_login_captcha\";s:1:\"1\";s:25:\"aiowps_captcha_secret_key\";s:20:\"aew2zhy60o1lbci0frvd\";s:42:\"aiowps_enable_manual_registration_approval\";s:1:\"1\";s:39:\"aiowps_enable_registration_page_captcha\";s:1:\"1\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:1:\"1\";s:26:\"aiowps_db_backup_frequency\";i:2;s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";i:1;s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_disable_file_editing\";s:1:\"1\";s:37:\"aiowps_prevent_default_wp_file_access\";s:1:\"1\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:1:\"1\";s:31:\"aiowps_enable_pingback_firewall\";s:1:\"1\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:1:\"1\";s:34:\"aiowps_block_debug_log_file_access\";s:1:\"1\";s:26:\"aiowps_disable_index_views\";s:1:\"1\";s:30:\"aiowps_disable_trace_and_track\";s:1:\"1\";s:28:\"aiowps_forbid_proxy_comments\";s:1:\"1\";s:29:\"aiowps_deny_bad_query_strings\";s:1:\"1\";s:34:\"aiowps_advanced_char_string_filter\";s:1:\"1\";s:25:\"aiowps_enable_5g_firewall\";s:1:\"1\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:1:\"1\";s:28:\"aiowps_enable_404_IP_lockout\";s:1:\"1\";s:30:\"aiowps_404_lockout_time_length\";i:60;s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:1:\"1\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:61:\"This site is currently not available. Please try again later.\";s:30:\"aiowps_enable_spambot_blocking\";s:1:\"1\";s:29:\"aiowps_enable_comment_captcha\";s:1:\"1\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:1:\"1\";s:33:\"aiowps_spam_ip_min_comments_block\";i:3;s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:1:\"1\";s:32:\"aiowps_prevent_users_enumeration\";s:1:\"1\";s:23:\"aiowps_last_backup_time\";s:19:\"2021-01-27 21:37:13\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:1:\"1\";s:34:\"aiowps_enable_woo_register_captcha\";s:1:\"1\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:42:\"aiowps_disallow_unauthorized_rest_requests\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";s:35:\"aiowps_enable_lost_password_captcha\";s:1:\"1\";s:28:\"aiowps_block_fake_googlebots\";s:1:\"1\";s:25:\"aiowps_recaptcha_site_key\";s:0:\"\";s:27:\"aiowps_recaptcha_secret_key\";s:0:\"\";s:24:\"aiowps_default_recaptcha\";s:0:\"\";s:38:\"aiowps_enable_woo_lostpassword_captcha\";s:0:\"\";s:27:\"aiowps_max_file_upload_size\";s:2:\"10\";}","yes");
INSERT INTO `wp_options` VALUES("174","acf_version","5.9.4","yes");
INSERT INTO `wp_options` VALUES("175","current_theme","ProTur","yes");
INSERT INTO `wp_options` VALUES("176","theme_mods_protur","a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;}","yes");
INSERT INTO `wp_options` VALUES("177","theme_switched","","yes");
INSERT INTO `wp_options` VALUES("192","action_scheduler_hybrid_store_demarkation","6","yes");
INSERT INTO `wp_options` VALUES("193","schema-ActionScheduler_StoreSchema","3.0.1611721603","yes");
INSERT INTO `wp_options` VALUES("194","schema-ActionScheduler_LoggerSchema","2.0.1611721604","yes");
INSERT INTO `wp_options` VALUES("195","aioseo_options_internal","{\"internal\":{\"validLicenseKey\":null,\"lastActiveVersion\":\"4.0.12\",\"migratedVersion\":\"0.0\",\"siteAnalysis\":{\"connectToken\":null,\"score\":0,\"results\":null,\"competitors\":[]},\"wizard\":null,\"category\":null,\"categoryOther\":null,\"deprecatedOptions\":[]}}","yes");
INSERT INTO `wp_options` VALUES("196","aioseo_options_internal_lite","{\"internal\":{\"activated\":1611721605,\"firstActivated\":1611721605,\"installed\":0,\"connect\":{\"key\":null,\"time\":0,\"network\":false,\"token\":null}}}","yes");
INSERT INTO `wp_options` VALUES("197","action_scheduler_lock_async-request-runner","1611721728","yes");
INSERT INTO `wp_options` VALUES("205","_transient_timeout_aioseo_admin_help_docs","1612326413","no");
INSERT INTO `wp_options` VALUES("206","_transient_aioseo_admin_help_docs","{\"categories\":{\"getting-started\":\"Getting Started\",\"advanced-settings\":\"Advanced Settings\",\"display-settings\":\"Display Settings\",\"general-seo-topics\":\"General SEO Topics\",\"feature-manager\":\"Feature Manager\",\"installation\":\"Installation\"},\"docs\":{\"25802\":{\"title\":\"aioseo_sitemap_additional_pages\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseo_sitemap_additional_pages\\/\",\"categories\":[\"filter-hooks\"]},\"24928\":{\"title\":\"Including Custom Fields in the SEO Page Analysis\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/including-custom-fields-in-the-seo-page-analysis\\/\",\"categories\":[\"search-appearance\"]},\"24907\":{\"title\":\"aioseo_social_meta_tags\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseo_social_meta_tags\\/\",\"categories\":[\"filter-hooks\"]},\"24285\":{\"title\":\"aioseo_prev_link\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseo_prev_link\\/\",\"categories\":[\"filter-hooks\"]},\"24284\":{\"title\":\"aioseo_next_link\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseo_next_link\\/\",\"categories\":[\"filter-hooks\"]},\"23717\":{\"title\":\"aioseo_canonical_url\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseo_canonical_url\\/\",\"categories\":[\"filter-hooks\"]},\"23604\":{\"title\":\"aioseo_schema_breadcrumbs_home\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseo_schema_breadcrumbs_home\\/\",\"categories\":[\"filter-hooks\"]},\"23448\":{\"title\":\"aioseo_schema_disable\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseo_schema_disable\\/\",\"categories\":[\"filter-hooks\"]},\"23447\":{\"title\":\"aioseo_robots_meta\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseo_robots_meta\\/\",\"categories\":[\"filter-hooks\"]},\"23446\":{\"title\":\"aioseo_disable\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseo_disable\\/\",\"categories\":[\"filter-hooks\"]},\"23441\":{\"title\":\"aioseo_generate_descriptions_from_content\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseo_generate_descriptions_from_content\\/\",\"categories\":[\"filter-hooks\"]},\"23438\":{\"title\":\"aioseo_disable_title_rewrites\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseo_disable_title_rewrites\\/\",\"categories\":[\"filter-hooks\"]},\"23437\":{\"title\":\"aioseo_post_metabox_priority\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseo_post_metabox_priority\\/\",\"categories\":[\"filter-hooks\"]},\"23436\":{\"title\":\"aioseo_show_seo_news\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseo_show_seo_news\\/\",\"categories\":[\"filter-hooks\"]},\"23433\":{\"title\":\"aioseo_show_in_admin_bar\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseo_show_in_admin_bar\\/\",\"categories\":[\"filter-hooks\"]},\"23423\":{\"title\":\"aioseo_keywords\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseo_keywords\\/\",\"categories\":[\"filter-hooks\"]},\"23350\":{\"title\":\"aioseo_title\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseo_title\\/\",\"categories\":[\"filter-hooks\"]},\"23351\":{\"title\":\"aioseo_description\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseo_description\\/\",\"categories\":[\"filter-hooks\"]},\"23415\":{\"title\":\"Troubleshooting Action Scheduler issues with AIOSEO\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/troubleshooting-action-scheduler-issues\\/\",\"categories\":[]},\"20504\":{\"title\":\"Where Did my SEO Keywords go in All in One SEO v4.0?\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/where-did-my-seo-keywords-go-in-all-in-one-seo-v4-0\\/\",\"categories\":[\"frequently-asked-questions\",\"keyword-settings\",\"v4-docs\"]},\"18792\":{\"title\":\"Sitemap rewrite rules for NGINX\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/xml-sitemap-rewrite-rules-for-nginx\\/\",\"categories\":[\"rss-sitemap\",\"v4-docs\",\"video-sitemap\",\"xml-sitemap\"]},\"18793\":{\"title\":\"Unfiltered HTML Capability is Required\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/unfiltered-html-capability\\/\",\"categories\":[\"v4-docs\"]},\"18794\":{\"title\":\"Deprecated Open Graph Settings in All in One SEO version 4.0\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/deprecated-opengraph-settings\\/\",\"categories\":[\"v4-docs\"]},\"18795\":{\"title\":\"Why does the character counter for SEO titles show a different count?\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/why-does-the-character-counter-for-seo-titles-show-a-different-count\\/\",\"categories\":[\"frequently-asked-questions\",\"post-page-settings\",\"v4-docs\"]},\"18796\":{\"title\":\"Adding nofollow, sponsored, UGC and title attributes to links\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/adding-nofollow-sponsored-and-title-attributes-to-links\\/\",\"categories\":[\"post-page-settings\",\"v4-docs\"]},\"18797\":{\"title\":\"Setting the SEO for WooCommerce Content\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-for-woocommerce-content\\/\",\"categories\":[\"search-appearance\",\"v4-docs\",\"woocommerce\"]},\"18798\":{\"title\":\"All in One SEO uses the WordPress REST API\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseo-uses-rest-api\\/\",\"categories\":[\"frequently-asked-questions\",\"v4-docs\"]},\"18799\":{\"title\":\"How to Remove All Settings and Data When you Uninstall All in One SEO\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-remove-all-settings-and-data-when-you-uninstall-all-in-one-seo\\/\",\"categories\":[\"advanced-settings\",\"general-settings\",\"v4-docs\"]},\"18800\":{\"title\":\"How to Disable TruSEO Content Analysis\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-disable-truseo-content-analysis\\/\",\"categories\":[\"advanced-settings\",\"display-settings\",\"general-settings\",\"v4-docs\"]},\"18801\":{\"title\":\"Enabling Automatic Updates for All in One SEO\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/enabling-automatic-updates-for-all-in-one-seo\\/\",\"categories\":[\"advanced-settings\",\"general-settings\",\"v4-docs\"]},\"18802\":{\"title\":\"Hiding Plugin Notifications in the Notifications Center\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/hiding-plugin-notifications-in-the-notifications-center\\/\",\"categories\":[\"advanced-settings\",\"display-settings\",\"general-settings\",\"v4-docs\"]},\"18803\":{\"title\":\"How to Hide the AIOSEO Settings on the Edit Content Screens in WordPress\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-hide-the-aioseo-settings-on-the-edit-content-screens-in-wordpress\\/\",\"categories\":[\"advanced-settings\",\"search-appearance\",\"v4-docs\"]},\"18804\":{\"title\":\"Setting Noindex and Nofollow on Paginated Content\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-noindex-and-nofollow-on-paginated-content\\/\",\"categories\":[\"advanced-settings\",\"noindex-settings\",\"search-appearance\",\"v4-docs\"]},\"18805\":{\"title\":\"Setting Unique SEO Titles and Descriptions for Paginated Content\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-unique-seo-titles-and-descriptions-for-paginated-content\\/\",\"categories\":[\"search-appearance\",\"title-settings\",\"v4-docs\"]},\"18806\":{\"title\":\"Setting the SEO Title and Description Format for Custom Post Type Archives\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-format-for-custom-post-type-archives\\/\",\"categories\":[\"search-appearance\",\"title-settings\",\"v4-docs\"]},\"18807\":{\"title\":\"Keyword Settings\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/keyword-settings\\/\",\"categories\":[\"keyword-settings\",\"search-appearance\",\"v4-docs\"]},\"18808\":{\"title\":\"Using the Quick Edit Feature in All in One SEO\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/using-the-quick-edit-feature-in-all-in-one-seo\\/\",\"categories\":[\"post-page-settings\",\"v4-docs\"]},\"18809\":{\"title\":\"How to FTP to your web server\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-ftp-to-your-web-server\\/\",\"categories\":[\"frequently-asked-questions\",\"v4-docs\"]},\"18810\":{\"title\":\"How to manually install All in One SEO Pro when the file is too big\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-manually-install-all-in-one-seo-pro-when-the-file-is-too-big\\/\",\"categories\":[\"frequently-asked-questions\",\"installation\",\"v4-docs\"]},\"18811\":{\"title\":\"How to Upgrade From All in One SEO Lite to Pro\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-upgrade-from-all-in-one-seo-lite-to-pro\\/\",\"categories\":[\"getting-started\",\"installation\",\"v4-docs\"]},\"18812\":{\"title\":\"Installation instructions for WordPress.com Users\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/installation-instructions-for-wordpress-com-users\\/\",\"categories\":[\"installation\",\"v4-docs\"]},\"18813\":{\"title\":\"Installing All in One SEO Pro\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/installing-all-in-one-seo-pro\\/\",\"categories\":[\"getting-started\",\"installation\",\"v4-docs\"]},\"18814\":{\"title\":\"Configuring the Twitter Settings for Your Content\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/configuring-the-twitter-settings-for-your-content\\/\",\"categories\":[\"post-page-settings\",\"social-networks\",\"twitter-settings\",\"v4-docs\"]},\"18815\":{\"title\":\"Configuring the Facebook Settings for Your Content\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/configuring-the-facebook-settings-for-your-content\\/\",\"categories\":[\"facebook-settings\",\"post-page-settings\",\"social-networks\",\"v4-docs\"]},\"18816\":{\"title\":\"Hiding the AIOSEO Column on Taxonomy Screens\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/hiding-the-aioseo-column-on-taxonomy-screens\\/\",\"categories\":[\"category-tag-settings\",\"display-settings\",\"general-settings\",\"v4-docs\"]},\"18817\":{\"title\":\"Setting the Schema Type for Individual Content\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-schema-type-for-individual-content\\/\",\"categories\":[\"post-page-settings\",\"schema-settings\",\"v4-docs\"]},\"18818\":{\"title\":\"Setting the Sitemap Priority and Frequency for Individual Content\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-sitemap-priority-and-frequency-for-individual-content\\/\",\"categories\":[\"post-page-settings\",\"v4-docs\",\"xml-sitemap\"]},\"18819\":{\"title\":\"Setting the Robots Meta for Individual Content\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-robots-meta-for-individual-content\\/\",\"categories\":[\"noindex-settings\",\"post-page-settings\",\"v4-docs\"]},\"18820\":{\"title\":\"Setting the SEO Title and Description for Your Content\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-for-your-content\\/\",\"categories\":[\"post-page-settings\",\"v4-docs\"]},\"18821\":{\"title\":\"Individual Post\\/Page Settings\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/post-settings\\/\",\"categories\":[\"post-page-settings\",\"v4-docs\"]},\"18822\":{\"title\":\"Bad Bot Blocker\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/bad-bot-blocker\\/\",\"categories\":[\"bad-bot-blocker\",\"v4-docs\"]},\"18823\":{\"title\":\"How to Fix a 404 Error When Viewing Your Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-fix-a-404-error-when-viewing-your-sitemap\\/\",\"categories\":[\"frequently-asked-questions\",\"google-news-sitemap\",\"rss-sitemap\",\"troubleshooting\",\"v4-docs\",\"video-sitemap\",\"xml-sitemap\"]},\"18824\":{\"title\":\"Local Business SEO\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/local-business-seo\\/\",\"categories\":[\"local-business-seo\",\"schema-settings\",\"v4-docs\"]},\"18825\":{\"title\":\"When to use NOINDEX or the robots.txt?\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/when-to-use-noindex-or-the-robots-txt\\/\",\"categories\":[\"frequently-asked-questions\",\"noindex-settings\",\"robots-txt\",\"search-appearance\",\"v4-docs\"]},\"18826\":{\"title\":\"Support for Videos Embedded Using the Media Library\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/support-for-videos-embedded-using-the-media-library\\/\",\"categories\":[\"v4-docs\",\"video-sitemap\"]},\"18827\":{\"title\":\"Supported Videos\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/supported-videos\\/\",\"categories\":[\"v4-docs\",\"video-sitemap\"]},\"18828\":{\"title\":\"Performance Settings\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/performance-settings\\/\",\"categories\":[\"performance\",\"v4-docs\"]},\"18829\":{\"title\":\"Using the Image SEO Features in All in One SEO\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/using-the-image-seo-features-in-all-in-one-seo\\/\",\"categories\":[\"image-seo\",\"media-settings\",\"search-appearance\",\"v4-docs\"]},\"18830\":{\"title\":\"Setting the SEO Title and Description Format for Author and Date Archives\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-format-for-author-and-date-archives\\/\",\"categories\":[\"search-appearance\",\"title-settings\",\"v4-docs\"]},\"18831\":{\"title\":\"Custom Fields in Titles and Descriptions\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/custom-fields-in-titles-and-descriptions\\/\",\"categories\":[\"content-type-settings\",\"post-page-settings\",\"search-appearance\",\"title-settings\",\"v4-docs\"]},\"18832\":{\"title\":\"Using the Focus Keyphrase to Analyze Your Content\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/using-the-focus-keyphrase-to-analyze-your-content\\/\",\"categories\":[\"v4-docs\"]},\"18833\":{\"title\":\"Using the Robots.txt Tool in All in One SEO\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/using-the-robots-txt-tool-in-all-in-one-seo\\/\",\"categories\":[\"robots-txt\",\"v4-docs\"]},\"18834\":{\"title\":\"Using the Robots Meta Settings in All in One SEO\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/using-the-robots-meta-settings-in-all-in-one-seo\\/\",\"categories\":[\"advanced-settings\",\"noindex-settings\",\"search-appearance\",\"v4-docs\"]},\"18835\":{\"title\":\"Noindex Settings in All in One SEO\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/noindex-settings\\/\",\"categories\":[\"noindex-settings\",\"search-appearance\",\"v4-docs\"]},\"18836\":{\"title\":\"Configuring the Schema Settings in All in One SEO\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/configuring-the-schema-settings-in-all-in-one-seo\\/\",\"categories\":[\"schema-settings\",\"search-appearance\",\"v4-docs\"]},\"18837\":{\"title\":\"A Guide to Schema.org Markup for Rich Snippets\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/a-guide-to-schema-org-markup-for-rich-snippets\\/\",\"categories\":[\"general-seo-topics\",\"schema-settings\",\"v4-docs\"]},\"18838\":{\"title\":\"Hiding the AIOSEO Admin Bar Menu\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/hiding-the-aioseo-admin-bar-menu\\/\",\"categories\":[\"display-settings\",\"general-settings\",\"v4-docs\"]},\"18839\":{\"title\":\"Hiding the AIOSEO Dashboard Widget\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/hiding-the-aioseo-dashboard-widget\\/\",\"categories\":[\"display-settings\",\"general-settings\",\"v4-docs\"]},\"18840\":{\"title\":\"Hiding the AIOSEO Column on All Posts Screens\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/hiding-the-aioseo-column-on-all-posts-screens\\/\",\"categories\":[\"display-settings\",\"general-settings\",\"v4-docs\"]},\"18841\":{\"title\":\"Display Settings\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/display-settings\\/\",\"categories\":[\"display-settings\",\"v4-docs\"]},\"18842\":{\"title\":\"Setting the SEO Title and Description Format for Media Attachments\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-format-for-media-attachments\\/\",\"categories\":[\"content-type-settings\",\"media-settings\",\"search-appearance\",\"v4-docs\"]},\"18843\":{\"title\":\"Showing or Hiding Your Content in Search Results\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/showing-or-hiding-your-content-in-search-results\\/\",\"categories\":[\"content-type-settings\",\"noindex-settings\",\"search-appearance\",\"v4-docs\"]},\"18844\":{\"title\":\"Content Type Settings\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/custom-post-type-settings\\/\",\"categories\":[\"content-type-settings\",\"search-appearance\",\"v4-docs\"]},\"18845\":{\"title\":\"What Are Media Attachments and Should I Submit Them to Search Engines?\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/what-are-media-attachments-and-should-i-submit-them-to-search-engines\\/\",\"categories\":[\"frequently-asked-questions\",\"v4-docs\"]},\"18846\":{\"title\":\"Setting the SEO Title and Description Format for Custom Taxonomies\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-format-for-custom-taxonomies\\/\",\"categories\":[\"category-tag-settings\",\"content-type-settings\",\"search-appearance\",\"v4-docs\"]},\"18847\":{\"title\":\"Setting the SEO Title and Description Format for Custom Post Types\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-format-for-custom-post-types\\/\",\"categories\":[\"content-type-settings\",\"search-appearance\",\"v4-docs\"]},\"18848\":{\"title\":\"Setting the SEO Title and Description Format for Tags\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-format-for-tags\\/\",\"categories\":[\"category-tag-settings\",\"search-appearance\",\"title-settings\",\"v4-docs\"]},\"18849\":{\"title\":\"Setting the SEO Title and Description Format for Categories\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-format-for-categories\\/\",\"categories\":[\"category-tag-settings\",\"search-appearance\",\"title-settings\",\"v4-docs\"]},\"18850\":{\"title\":\"Setting the SEO Title and Description Format for Pages\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-format-for-pages\\/\",\"categories\":[\"search-appearance\",\"title-settings\",\"v4-docs\"]},\"18851\":{\"title\":\"Setting the SEO Title and Description Format for Posts\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-format-for-posts\\/\",\"categories\":[\"search-appearance\",\"title-settings\",\"v4-docs\"]},\"18852\":{\"title\":\"Title Settings\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/title-settings\\/\",\"categories\":[\"search-appearance\",\"title-settings\",\"v4-docs\"]},\"18853\":{\"title\":\"Setting the SEO for Your Home Page\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-for-your-home-page\\/\",\"categories\":[\"home-page-settings\",\"search-appearance\",\"v4-docs\"]},\"18854\":{\"title\":\"General Settings\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/general-settings\\/\",\"categories\":[\"general-settings\",\"v4-docs\"]},\"18855\":{\"title\":\"How to Add Your License Key in All in One SEO Pro\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-add-your-license-key-in-all-in-one-seo-pro\\/\",\"categories\":[\"general-settings\",\"getting-started\",\"v4-docs\"]},\"18856\":{\"title\":\"Canonical URLs in All in One SEO\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/canonical-urls-in-all-in-one-seo\\/\",\"categories\":[\"advanced-settings\",\"general-settings\",\"search-appearance\",\"v4-docs\"]},\"18857\":{\"title\":\"Beginners Guide to Social Networks Settings for Twitter\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/beginners-guide-to-social-networks-settings-for-twitter\\/\",\"categories\":[\"getting-started\",\"social-networks\",\"twitter-settings\",\"v4-docs\"]},\"18858\":{\"title\":\"Adding non-WordPress Content to the Video Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/adding-non-wordpress-content-to-the-video-sitemap\\/\",\"categories\":[\"v4-docs\",\"video-sitemap\"]},\"18859\":{\"title\":\"Beginners Guide to Social Networks Settings for Facebook\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/beginners-guide-to-social-networks-settings-for-facebook\\/\",\"categories\":[\"facebook-settings\",\"getting-started\",\"social-networks\",\"v4-docs\"]},\"18860\":{\"title\":\"Troubleshooting Problems With Sharing Content on Twitter\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/troubleshooting-problems-with-sharing-content-on-twitter\\/\",\"categories\":[\"social-networks\",\"troubleshooting\",\"twitter-settings\",\"v4-docs\"]},\"18861\":{\"title\":\"Troubleshooting Problems With Sharing Content on Facebook\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/troubleshooting-problems-with-sharing-content-on-facebook\\/\",\"categories\":[\"facebook-settings\",\"social-networks\",\"troubleshooting\",\"v4-docs\"]},\"18862\":{\"title\":\"Getting Started With Pinterest Rich Pins\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/using-social-meta-for-pinterest-rich-pins\\/\",\"categories\":[\"pinterest-settings\",\"social-networks\",\"v4-docs\"]},\"18863\":{\"title\":\"Setting the Content Publisher for Twitter\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-content-publisher-for-twitter\\/\",\"categories\":[\"social-networks\",\"twitter-settings\",\"v4-docs\"]},\"18864\":{\"title\":\"Exclude Images from XML Sitemap for Yandex\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/exclude-images-from-xml-sitemap-for-yandex\\/\",\"categories\":[\"v4-docs\",\"xml-sitemap\"]},\"18865\":{\"title\":\"Submitting a Sitemap to Yandex\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/submitting-a-sitemap-to-yandex\\/\",\"categories\":[\"rss-sitemap\",\"v4-docs\",\"video-sitemap\",\"xml-sitemap\"]},\"18866\":{\"title\":\"Submitting a Sitemap to Bing\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/submitting-a-sitemap-to-bing\\/\",\"categories\":[\"rss-sitemap\",\"v4-docs\",\"video-sitemap\",\"xml-sitemap\"]},\"18867\":{\"title\":\"Submitting a Sitemap to Google\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/submitting-a-sitemap-to-google\\/\",\"categories\":[\"google-news-sitemap\",\"google-search-console\",\"rss-sitemap\",\"v4-docs\",\"video-sitemap\",\"xml-sitemap\"]},\"18868\":{\"title\":\"Including Date and Author Archives in Your XML Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/including-date-and-author-archives-in-your-xml-sitemap\\/\",\"categories\":[\"v4-docs\",\"xml-sitemap\"]},\"18869\":{\"title\":\"Choosing Which Content to Include in Your Video Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/choosing-which-content-to-include-in-your-video-sitemap\\/\",\"categories\":[\"v4-docs\",\"video-sitemap\"]},\"18870\":{\"title\":\"Choosing Which Content to Include in Your XML Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/choosing-which-content-to-include-in-your-xml-sitemap\\/\",\"categories\":[\"v4-docs\",\"xml-sitemap\"]},\"18871\":{\"title\":\"Using Sitemap Indexes and Pagination\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/using-sitemap-indexes-and-pagination\\/\",\"categories\":[\"v4-docs\",\"video-sitemap\",\"xml-sitemap\"]},\"18872\":{\"title\":\"How to Disable Sitemaps in All in One SEO\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-disable-sitemaps-in-all-in-one-seo\\/\",\"categories\":[\"google-news-sitemap\",\"rss-sitemap\",\"v4-docs\",\"video-sitemap\",\"xml-sitemap\"]},\"18873\":{\"title\":\"Baidu Webmaster Tools Verification\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/baidu-webmaster-tools-verification\\/\",\"categories\":[\"v4-docs\",\"webmaster-verification\"]},\"18874\":{\"title\":\"Setting Twitter Social Meta for Your Homepage\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-twitter-social-meta-for-your-homepage\\/\",\"categories\":[\"social-networks\",\"twitter-settings\",\"v4-docs\"]},\"18875\":{\"title\":\"Setting Facebook Social Meta for Your Homepage\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-facebook-social-meta-for-your-homepage\\/\",\"categories\":[\"facebook-settings\",\"social-networks\",\"v4-docs\"]},\"18876\":{\"title\":\"Setting the Card Type for Twitter\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-card-type-for-twitter\\/\",\"categories\":[\"social-networks\",\"twitter-settings\",\"v4-docs\"]},\"18877\":{\"title\":\"Setting the Object Types for Facebook\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-object-types-for-facebook\\/\",\"categories\":[\"facebook-settings\",\"social-networks\",\"v4-docs\"]},\"18878\":{\"title\":\"Setting the Image Dimensions for Facebook\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-image-dimensions-for-facebook\\/\",\"categories\":[\"facebook-settings\",\"social-networks\",\"v4-docs\"]},\"18879\":{\"title\":\"Setting the Priority and Frequency for Content in the Video Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-priority-and-frequency-for-content-in-the-video-sitemap\\/\",\"categories\":[\"v4-docs\",\"video-sitemap\"]},\"18880\":{\"title\":\"Setting the Priority and Frequency for Content in the XML Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-priority-and-frequency-for-content-in-the-xml-sitemap\\/\",\"categories\":[\"v4-docs\",\"xml-sitemap\"]},\"18881\":{\"title\":\"How to Exclude Content from Your RSS Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-exclude-content-from-your-rss-sitemap\\/\",\"categories\":[\"rss-sitemap\",\"v4-docs\"]},\"18882\":{\"title\":\"How to Exclude Content from Your Google News Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-exclude-content-from-your-google-news-sitemap\\/\",\"categories\":[\"google-news-sitemap\",\"v4-docs\"]},\"18883\":{\"title\":\"How to Exclude Content from Your Video Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-exclude-content-from-your-video-sitemap\\/\",\"categories\":[\"v4-docs\",\"video-sitemap\"]},\"18884\":{\"title\":\"How to Exclude Content from Your XML Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-exclude-content-from-your-xml-sitemap\\/\",\"categories\":[\"v4-docs\",\"xml-sitemap\"]},\"18885\":{\"title\":\"Setting Article Tags for Facebook\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-article-tags-for-facebook\\/\",\"categories\":[\"facebook-settings\",\"social-networks\",\"v4-docs\"]},\"18886\":{\"title\":\"Setting the Content Author for Twitter\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-content-author-for-twitter\\/\",\"categories\":[\"social-networks\",\"twitter-settings\",\"v4-docs\"]},\"18887\":{\"title\":\"Setting the Content Author for Facebook\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-content-author-for-facebook\\/\",\"categories\":[\"facebook-settings\",\"social-networks\",\"v4-docs\"]},\"18888\":{\"title\":\"Setting the Content Publisher for Facebook\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-the-content-publisher-for-facebook\\/\",\"categories\":[\"facebook-settings\",\"social-networks\",\"v4-docs\"]},\"18889\":{\"title\":\"How to Create a Google News Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-create-a-google-news-sitemap\\/\",\"categories\":[\"google-news-sitemap\",\"v4-docs\",\"xml-sitemap\"]},\"18890\":{\"title\":\"Including Videos in Custom Fields in Your Video Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/including-videos-in-custom-fields-in-your-video-sitemap\\/\",\"categories\":[\"v4-docs\",\"video-sitemap\"]},\"18891\":{\"title\":\"What is a Dynamically Generated Sitemap and Why is it Better to Use?\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/what-is-a-dynamically-generated-sitemap-and-why-is-it-better-to-use\\/\",\"categories\":[\"frequently-asked-questions\",\"v4-docs\",\"video-sitemap\",\"xml-sitemap\"]},\"18892\":{\"title\":\"How to Create a Video Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-create-a-video-sitemap\\/\",\"categories\":[\"v4-docs\",\"video-sitemap\"]},\"18893\":{\"title\":\"Adding Your Facebook Admin ID\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/adding-your-facebook-admin-id\\/\",\"categories\":[\"facebook-settings\",\"social-networks\",\"v4-docs\"]},\"18894\":{\"title\":\"Adding Your Facebook App ID\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/adding-your-facebook-app-id\\/\",\"categories\":[\"facebook-settings\",\"social-networks\",\"v4-docs\"]},\"18895\":{\"title\":\"Access Control Settings\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/access-control-settings\\/\",\"categories\":[\"access-control-settings\",\"v4-docs\"]},\"18896\":{\"title\":\"Advanced Settings for Google Analytics\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/advanced-settings-for-google-analytics\\/\",\"categories\":[\"google-analytics\",\"v4-docs\"]},\"18897\":{\"title\":\"Miscellaneous Site Verification\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/miscellaneous-site-verification\\/\",\"categories\":[\"v4-docs\",\"webmaster-verification\"]},\"18898\":{\"title\":\"Displaying Your Social Media Profiles in Knowledge Panel\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/displaying-your-social-media-profiles-in-knowledge-panel\\/\",\"categories\":[\"schema-settings\",\"v4-docs\"]},\"18899\":{\"title\":\"How to Create an RSS Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-create-an-rss-sitemap\\/\",\"categories\":[\"rss-sitemap\",\"v4-docs\",\"xml-sitemap\"]},\"18900\":{\"title\":\"Excluding Images from the XML Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/excluding-images-from-the-xml-sitemap\\/\",\"categories\":[\"v4-docs\",\"xml-sitemap\"]},\"18901\":{\"title\":\"Adding non-WordPress Content to the XML Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/adding-non-wordpress-content-to-the-xml-sitemap\\/\",\"categories\":[\"v4-docs\",\"xml-sitemap\"]},\"18902\":{\"title\":\"How to Create an XML Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-create-an-xml-sitemap\\/\",\"categories\":[\"getting-started\",\"v4-docs\",\"xml-sitemap\"]},\"18903\":{\"title\":\"Setting a Default Image for Twitter\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-a-default-image-for-twitter\\/\",\"categories\":[\"social-networks\",\"twitter-settings\",\"v4-docs\"]},\"18904\":{\"title\":\"Setting a Default Image for Facebook\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-a-default-image-for-facebook\\/\",\"categories\":[\"facebook-settings\",\"social-networks\",\"v4-docs\"]},\"18905\":{\"title\":\"Setting a Title Separator\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-a-title-separator\\/\",\"categories\":[\"title-settings\",\"v4-docs\"]},\"18906\":{\"title\":\"How to Protect Your Content With RSS Content Settings\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-protect-your-content-with-rss-content-settings\\/\",\"categories\":[\"rss-content-settings\",\"v4-docs\"]},\"18907\":{\"title\":\"How to Connect Your Site with Google Tag Manager\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-connect-your-site-with-google-tag-manager\\/\",\"categories\":[\"google-analytics\",\"v4-docs\"]},\"18908\":{\"title\":\"How to Connect Your Site with Google Analytics\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-connect-your-site-with-google-analytics\\/\",\"categories\":[\"google-analytics\",\"v4-docs\"]},\"18909\":{\"title\":\"How to Verify Your Site with Pinterest\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-verify-your-site-with-pinterest\\/\",\"categories\":[\"pinterest-settings\",\"v4-docs\",\"webmaster-verification\"]},\"18910\":{\"title\":\"How to Verify Your Site with Yandex Webmaster Tools\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-verify-your-site-with-yandex-webmaster-tools\\/\",\"categories\":[\"v4-docs\",\"webmaster-verification\"]},\"18911\":{\"title\":\"How to Verify Your Site with Bing Webmaster Tools\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-verify-your-site-with-bing-webmaster-tools\\/\",\"categories\":[\"v4-docs\",\"webmaster-verification\"]},\"18912\":{\"title\":\"How to Verify Your Site with Google Search Console\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-verify-your-site-with-google-search-console\\/\",\"categories\":[\"google-search-console\",\"v4-docs\",\"webmaster-verification\"]},\"18913\":{\"title\":\"Usage Tracking\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/usage-tracking\\/\",\"categories\":[\"uncategorized\"]},\"18914\":{\"title\":\"aiosp_opengraph_default_image_type\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aiosp_opengraph_default_image_type\\/\",\"categories\":[\"seo-api\"]},\"18915\":{\"title\":\"How do I use All in One SEO in my language?\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-do-i-use-all-in-one-seo-in-my-language\\/\",\"categories\":[\"frequently-asked-questions\"]},\"18916\":{\"title\":\"Disabling the Google News Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop-news-sitemap-enabled\\/\",\"categories\":[\"seo-api\"]},\"18917\":{\"title\":\"Filtering the post types included in the Google News sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop-news-sitemap-post-types\\/\",\"categories\":[\"seo-api\"]},\"18918\":{\"title\":\"Exclude terms from the XML Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/exclude-terms-from-the-xml-sitemap\\/\",\"categories\":[\"seo-api\"]},\"18919\":{\"title\":\"Disable Selectize.js in XML Sitemap settings\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/disable-selectize-js-in-xml-sitemap-settings\\/\",\"categories\":[\"seo-api\"]},\"18920\":{\"title\":\"NGINX rewrite rules for Robots.txt\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/nginx-rewrite-rules-for-robots-txt\\/\",\"categories\":[\"robots-txt\",\"v4-docs\"]},\"18921\":{\"title\":\"Disable BreadcrumbList Schema\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/disable-breadcrumblist-schema\\/\",\"categories\":[\"seo-api\"]},\"18922\":{\"title\":\"Excluding Posts from the sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop-sitemap-post-filter\\/\",\"categories\":[\"seo-api\"]},\"18923\":{\"title\":\"aisop_woocommerce_hide_hidden_products\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aisop_woocommerce_hide_hidden_products\\/\",\"categories\":[\"seo-api\"]},\"18924\":{\"title\":\"Disabling our Image SEO columns in the Media Library\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop-image-seo-media-columns\\/\",\"categories\":[\"seo-api\"]},\"18925\":{\"title\":\"Filtering the alt tag attribute of an image\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop-image-seo-alt-tag\\/\",\"categories\":[\"seo-api\"]},\"18926\":{\"title\":\"Filtering the title attribute of an image\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop-image-seo-title\\/\",\"categories\":[\"seo-api\"]},\"18927\":{\"title\":\"Supported PHP Versions for All in One SEO\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/supported-php-version\\/\",\"categories\":[\"troubleshooting\"]},\"18928\":{\"title\":\"aioseop_video_sitemap_scan_posts_limit\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop_video_sitemap_scan_posts_limit\\/\",\"categories\":[\"uncategorized\"]},\"18929\":{\"title\":\"Using a different CDN for script enqueuing\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/using-a-different-cdn-for-script-enqueuing\\/\",\"categories\":[\"troubleshooting\"]},\"18930\":{\"title\":\"How do I get Google to show sitelinks for my site?\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-do-i-get-google-to-show-sitelinks-for-my-site\\/\",\"categories\":[\"frequently-asked-questions\"]},\"18931\":{\"title\":\"Disable Schema markup\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/disable-schema-markup\\/\",\"categories\":[\"seo-api\"]},\"18932\":{\"title\":\"Filter social profiles in Schema.org\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/filter-social-profiles-in-schema-org\\/\",\"categories\":[\"seo-api\"]},\"18933\":{\"title\":\"Filter image in Schema.org\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/filter-image-in-schema-org\\/\",\"categories\":[\"seo-api\"]},\"18934\":{\"title\":\"Filter XML Sitemap data\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/filter-xml-sitemap-data\\/\",\"categories\":[\"seo-api\"]},\"18935\":{\"title\":\"Filter the description used in Schema markup\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/filter-the-description-used-in-schema-markup\\/\",\"categories\":[\"seo-api\"]},\"18936\":{\"title\":\"Add support for additional video URLs for oEmbed discovery\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/add-support-for-additional-video-urls-for-oembed-discovery\\/\",\"categories\":[\"seo-api\"]},\"18937\":{\"title\":\"Dynamically change the Google Tag Manager Container ID\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/dynamically-change-the-google-tag-manager-container-id\\/\",\"categories\":[\"seo-api\"]},\"18938\":{\"title\":\"aioseop_disable_google_tag_manager\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop_disable_google_tag_manager\\/\",\"categories\":[\"uncategorized\"]},\"18939\":{\"title\":\"Add support to Video Sitemap for additional video embed shortcodes\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/add-support-to-video-sitemap-for-additional-video-embed-shortcodes\\/\",\"categories\":[\"seo-api\"]},\"18940\":{\"title\":\"Filter Schema markup for Person\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/filter-schema-markup-for-person\\/\",\"categories\":[\"seo-api\"]},\"18941\":{\"title\":\"Change schema type\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/change-schema-type\\/\",\"categories\":[\"seo-api\"]},\"18942\":{\"title\":\"Disable Schema markup on AMP pages\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/disable-schema-markup-on-amp-pages\\/\",\"categories\":[\"seo-api\"]},\"18943\":{\"title\":\"Adding corporate contacts in Schema markup\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/adding-corporate-contacts-in-schema-markup\\/\",\"categories\":[\"schema-settings\",\"seo-api\"]},\"18944\":{\"title\":\"Enabling Schema for custom post types and custom taxonomies\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/enabling-schema-for-custom-post-types-and-custom-taxonomies\\/\",\"categories\":[\"schema-settings\",\"seo-api\"]},\"18945\":{\"title\":\"aioseop robots meta\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop-robots-meta\\/\",\"categories\":[\"seo-api\"]},\"18946\":{\"title\":\"aioseop noindex rss\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop-noindex-rss\\/\",\"categories\":[\"seo-api\"]},\"18947\":{\"title\":\"aioseop sitemap exclude tax terms\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop-sitemap-exclude-tax-terms\\/\",\"categories\":[\"seo-api\"]},\"18948\":{\"title\":\"aioseop_admin_notice-$slug\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop_admin_notice-slug\\/\",\"categories\":[\"seo-api\"]},\"18949\":{\"title\":\"aioseop_robotstxt_sitemap_url\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop_robotstxt_sitemap_url\\/\",\"categories\":[\"seo-api\"]},\"18950\":{\"title\":\"aiosp_opengraph_disable_meta_tag_truncation\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aiosp_opengraph_disable_meta_tag_truncation\\/\",\"categories\":[\"seo-api\"]},\"18951\":{\"title\":\"aiosp_opengraph_generate_descriptions_from_content\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aiosp_opengraph_generate_descriptions_from_content\\/\",\"categories\":[\"seo-api\"]},\"18952\":{\"title\":\"aiosp_generate_descriptions_from_content\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aiosp_generate_descriptions_from_content\\/\",\"categories\":[\"seo-api\"]},\"18953\":{\"title\":\"aioseop_title_format\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop_title_format\\/\",\"categories\":[\"seo-api\"]},\"18954\":{\"title\":\"How does the import process for SEO data work?\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-does-the-import-process-for-seo-data-work\\/\",\"categories\":[\"frequently-asked-questions\",\"importer-exporter\"]},\"18955\":{\"title\":\"aioseop_pre_tax_types_setting\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop_pre_tax_types_setting\\/\",\"categories\":[\"seo-api\"]},\"18956\":{\"title\":\"aiosp_video_sitemap_filename\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aiosp_video_sitemap_filename\\/\",\"categories\":[\"seo-api\"]},\"18957\":{\"title\":\"aiosp_sitemap_filename\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aiosp_sitemap_filename\\/\",\"categories\":[\"seo-api\"]},\"18958\":{\"title\":\"Support for Jetpack galleries and Image CDN\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/support-for-jetpack-galleries-and-image-cdn\\/\",\"categories\":[\"xml-sitemap\"]},\"18959\":{\"title\":\"Exclude post type archives from XML Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/exclude-post-type-archives-from-xml-sitemap\\/\",\"categories\":[\"seo-api\",\"xml-sitemap\"]},\"18960\":{\"title\":\"Robots.txt Editor for Multisite Networks\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/robots-txt-editor-for-multisite-networks\\/\",\"categories\":[\"robots-txt\"]},\"18961\":{\"title\":\"What are the minimum requirements for All in One SEO?\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/what-are-the-minimum-requirements-for-all-in-one-seo-pack\\/\",\"categories\":[\"frequently-asked-questions\"]},\"18962\":{\"title\":\"Support external images in the XML Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/support-external-images-in-the-xml-sitemap\\/\",\"categories\":[\"seo-api\",\"xml-sitemap\"]},\"18963\":{\"title\":\"aioseop_format_date\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop_format_date\\/\",\"categories\":[\"seo-api\"]},\"18964\":{\"title\":\"How do I use your API code examples?\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-do-i-use-your-api-code-examples\\/\",\"categories\":[\"frequently-asked-questions\"]},\"18965\":{\"title\":\"Use CDN for Google Analytics Autotrack.js\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/use-cdn-for-google-analytics-autotrack-js\\/\",\"categories\":[\"seo-api\"]},\"18966\":{\"title\":\"Add headers to XML Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/add-headers-to-xml-sitemap\\/\",\"categories\":[\"seo-api\"]},\"18967\":{\"title\":\"Truncate manually entered SEO descriptions\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/truncate-manually-entered-seo-descriptions\\/\",\"categories\":[\"seo-api\"]},\"18968\":{\"title\":\"Disable images in XML Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/disable-images-in-xml-sitemap\\/\",\"categories\":[\"seo-api\"]},\"18969\":{\"title\":\"XML Parsing Error - This page contains the following errors\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/this-page-contains-the-following-errors\\/\",\"categories\":[\"google-news-sitemap\",\"troubleshooting\",\"v4-docs\",\"video-sitemap\",\"xml-sitemap\"]},\"18970\":{\"title\":\"Add Attribute to Google Analytics\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/add-attribute-to-google-analytics\\/\",\"categories\":[\"seo-api\"]},\"18971\":{\"title\":\"How to remove rel=\'next\' and rel=\'prev\' from paginated content\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/remove-relnext-and-relprev-from-paginated-content-in-all-in-one-seo-pack\\/\",\"categories\":[\"seo-api\"]},\"18972\":{\"title\":\"The File Editor or Robots.txt modules are missing\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/the-file-editor-or-robots-txt-modules-are-missing\\/\",\"categories\":[\"frequently-asked-questions\"]},\"18973\":{\"title\":\"Beginners Guide for All in One SEO\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/quick-start-guide\\/\",\"categories\":[\"getting-started\"]},\"18974\":{\"title\":\"Disable Meta Description on AMP pages\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/disable-meta-description-on-amp-pages\\/\",\"categories\":[\"seo-api\"]},\"18975\":{\"title\":\"Disable Open Graph meta on AMP pages\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/disable-open-graph-meta-on-amp-pages\\/\",\"categories\":[\"seo-api\"]},\"18976\":{\"title\":\"Noindex Password Protected Posts\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/noindex-password-protected-posts\\/\",\"categories\":[\"seo-api\"]},\"18977\":{\"title\":\"Excluding the XML Sitemap from caching\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/excluding-the-xml-sitemap-from-caching\\/\",\"categories\":[\"xml-sitemap\"]},\"18978\":{\"title\":\"Disable removal of Twitter meta from official Twitter plugin\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/disable-removal-of-twitter-meta-from-official-twitter-plugin\\/\",\"categories\":[\"seo-api\"]},\"18979\":{\"title\":\"Remove Password Protected Posts from XML Sitemap\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/remove-password-protected-posts-from-xml-sitemap\\/\",\"categories\":[\"xml-sitemap\"]},\"18980\":{\"title\":\"Password Protected Posts in XML Sitemaps\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/password-protected-posts-in-xml-sitemaps\\/\",\"categories\":[\"seo-api\"]},\"18981\":{\"title\":\"Remove Canonical URL on a Page\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/remove-canonical-url-on-a-page\\/\",\"categories\":[\"seo-api\"]},\"18982\":{\"title\":\"Why doesn\'t the title and description I set appear in search results?\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/why-doesnt-the-title-and-description-i-set-appear-in-search-results\\/\",\"categories\":[\"frequently-asked-questions\",\"post-page-settings\"]},\"18983\":{\"title\":\"Can I remove the date from Google search results?\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/can-i-remove-the-date-from-google-search-results\\/\",\"categories\":[\"frequently-asked-questions\"]},\"18984\":{\"title\":\"Filter to change canonical URL protocol\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/filter-to-change-canonical-url-protocol\\/\",\"categories\":[\"seo-api\"]},\"18985\":{\"title\":\"Setting up HTTPS SSL\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/setting-up-https-ssl\\/\",\"categories\":[\"general-seo-topics\"]},\"18987\":{\"title\":\"Filter to Disable All in One SEO Pack\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/filter-to-disable-all-in-one-seo-pack\\/\",\"categories\":[\"seo-api\"]},\"18988\":{\"title\":\"Remove SEO News Dashboard Widget\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/remove-seo-news-dashboard-widget\\/\",\"categories\":[\"seo-api\"]},\"18989\":{\"title\":\"Filter SEO columns from posts screen\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/filter-seo-columns-edit-post-screen\\/\",\"categories\":[\"seo-api\"]},\"18990\":{\"title\":\"Remove All in One SEO Pack from top of menu\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/remove-all-in-one-seo-pack-from-top-of-menu\\/\",\"categories\":[\"seo-api\"]},\"18991\":{\"title\":\"Disable SEO in Toolbar\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/disable-seo-in-toolbar\\/\",\"categories\":[\"seo-api\"]},\"18992\":{\"title\":\"Disable Pinging Sitemap to Search Engines - All in One SEO\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/disable-pinging-sitemap-search-engines\\/\",\"categories\":[\"seo-api\"]},\"18993\":{\"title\":\"Use All in One SEO to send XML Sitemap to additional search engines\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/all-in-one-seo-send-xml-sitemap-search-engines\\/\",\"categories\":[\"seo-api\"]},\"18994\":{\"title\":\"Capitalize Category Titles in All in One SEO Pack\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/capitalize-category-titles\\/\",\"categories\":[\"seo-api\"]},\"18995\":{\"title\":\"How to Increase the WordPress PHP Memory Limit\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/increase-wordpress-php-memory-limit\\/\",\"categories\":[\"troubleshooting\"]},\"18996\":{\"title\":\"Adding additional headers\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/adding-additional-headers\\/\",\"categories\":[\"seo-api\"]},\"18997\":{\"title\":\"Change attachment size for sharing on social media in All in One SEO Pack\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/opengraph_attachment_size\\/\",\"categories\":[\"seo-api\"]},\"18998\":{\"title\":\"Change thumbnail size for sharing on social media in All in One SEO Pack\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/opengraph-image-size\\/\",\"categories\":[\"seo-api\"]},\"18999\":{\"title\":\"Use classic asynchronous Google Analytics for All in One SEO Pack\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/use-classic-asynchronous-google-analytics-for-all-in-one-seo-pack\\/\",\"categories\":[\"seo-api\"]},\"19000\":{\"title\":\"Add code after Google Analytics in All in One SEO Pack\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/add-code-after-google-analytics-in-all-in-one-seo-pack\\/\",\"categories\":[\"seo-api\"]},\"19001\":{\"title\":\"Filter All in One SEO Pack Google Analytics\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/filter-all-in-one-seo-pack-google-analytics\\/\",\"categories\":[\"seo-api\"]},\"19002\":{\"title\":\"Checking Index Status in Google Search Results\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/checking-index-status-in-google-search-results\\/\",\"categories\":[\"general-seo-topics\"]},\"19003\":{\"title\":\"before_doing_updates\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/before_doing_updates\\/\",\"categories\":[\"seo-api\"]},\"19004\":{\"title\":\"aiosp_sitemap_addl_pages\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aiosp_sitemap_addl_pages\\/\",\"categories\":[\"seo-api\"]},\"19005\":{\"title\":\"aioseop_sitemap_xsl_url\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop_sitemap_xsl_url\\/\",\"categories\":[\"seo-api\"]},\"19006\":{\"title\":\"SEO Data Importer\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/seo-data-importer\\/\",\"categories\":[\"seo-data-importer\"]},\"19007\":{\"title\":\"aiosp_opengraph_meta\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aiosp_opengraph_meta\\/\",\"categories\":[\"seo-api\"]},\"19008\":{\"title\":\"How to troubleshoot issues with All in One SEO\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/how-to-troubleshoot-issues-with-all-in-one-seo-pack\\/\",\"categories\":[\"troubleshooting\"]},\"19010\":{\"title\":\"Quality Guidelines for SEO Titles and Descriptions\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/quality-guidelines-for-seo-titles-and-descriptions\\/\",\"categories\":[\"general-seo-topics\"]},\"19011\":{\"title\":\"All in One SEO Pack Title Filter - aioseop_title\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop_title\\/\",\"categories\":[\"seo-api\"]},\"19012\":{\"title\":\"manage_aiosp\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/manage_aiosp\\/\",\"categories\":[\"seo-api\"]},\"19013\":{\"title\":\"aioseop_attachment_title\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop_attachment_title\\/\",\"categories\":[\"seo-api\"]},\"19014\":{\"title\":\"aioseop_archive_title\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop_archive_title\\/\",\"categories\":[\"seo-api\"]},\"19015\":{\"title\":\"aioseop_description\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/aioseop_description\\/\",\"categories\":[\"seo-api\"]},\"19016\":{\"title\":\"Top Tips for Good On-Page SEO\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/top-tips-for-good-on-page-seo\\/\",\"categories\":[\"general-seo-topics\"]},\"19017\":{\"title\":\"Meta Descriptions\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/meta-descriptions\\/\",\"categories\":[\"general-seo-topics\"]},\"19028\":{\"title\":\"What is SEO meta?\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/what-is-seo-meta\\/\",\"categories\":[\"getting-started\"]},\"19029\":{\"title\":\"Social Meta Settings - Individual Page\\/Post Settings\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/social-meta-settings-individual-pagepost-settings\\/\",\"categories\":[\"post-page-settings\",\"social-networks\"]},\"19030\":{\"title\":\"File Editor Module\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/file-editor-module\\/\",\"categories\":[\"file-editor\"]},\"19031\":{\"title\":\"Social Meta Settings\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/social-meta-module\\/\",\"categories\":[\"social-networks\",\"v4-docs\"]},\"19032\":{\"title\":\"Importer & Exporter Module\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/importer-exporter-module\\/\",\"categories\":[\"importer-exporter\"]},\"19033\":{\"title\":\"XML Sitemaps Module\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/xml-sitemaps-module\\/\",\"categories\":[\"xml-sitemap\"]},\"19034\":{\"title\":\"Feature Manager\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/feature-manager\\/\",\"categories\":[\"feature-manager\"]},\"19035\":{\"title\":\"Advanced Settings for All in One SEO Pack\",\"url\":\"https:\\/\\/aioseo.com\\/docs\\/all-in-one-seo-pack-advanced-settings\\/\",\"categories\":[]}}}","no");
INSERT INTO `wp_options` VALUES("209","imsanity_max_width","1920","no");
INSERT INTO `wp_options` VALUES("210","imsanity_max_height","1920","no");
INSERT INTO `wp_options` VALUES("211","imsanity_max_width_library","1920","no");
INSERT INTO `wp_options` VALUES("212","imsanity_max_height_library","1920","no");
INSERT INTO `wp_options` VALUES("213","imsanity_max_width_other","1920","no");
INSERT INTO `wp_options` VALUES("214","imsanity_max_height_other","1920","no");
INSERT INTO `wp_options` VALUES("215","imsanity_bmp_to_jpg","1","no");
INSERT INTO `wp_options` VALUES("216","imsanity_png_to_jpg","","no");
INSERT INTO `wp_options` VALUES("217","imsanity_quality","82","no");
INSERT INTO `wp_options` VALUES("218","imsanity_delete_originals","","no");
INSERT INTO `wp_options` VALUES("219","imsanity_version","2.7.1","yes");
INSERT INTO `wp_options` VALUES("223","widget_ssba_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("224","wpXSG_databaseUpgraded","1","no");
INSERT INTO `wp_options` VALUES("225","wpXSG_rewrite_done","0003","yes");
INSERT INTO `wp_options` VALUES("226","wpXSG_MapId","6010ebd91791f9.54087405","yes");
INSERT INTO `wp_options` VALUES("227","xmsg_LastPing","1611724123","yes");
INSERT INTO `wp_options` VALUES("228","xmsg_Update","1","yes");
INSERT INTO `wp_options` VALUES("231","core_updater.lock","1611721766","no");
INSERT INTO `wp_options` VALUES("235","dismissed_update_core","a:1:{s:9:\"5.6|ru_RU\";b:1;}","no");
INSERT INTO `wp_options` VALUES("237","auto_update_core_dev","enabled","yes");
INSERT INTO `wp_options` VALUES("238","auto_update_core_minor","enabled","yes");
INSERT INTO `wp_options` VALUES("239","auto_update_core_major","unset","yes");
INSERT INTO `wp_options` VALUES("240","db_upgraded","","yes");
INSERT INTO `wp_options` VALUES("242","can_compress_scripts","1","no");
INSERT INTO `wp_options` VALUES("252","ssba_settings","a:149:{s:15:\"ssba_omit_pages\";s:0:\"\";s:20:\"ssba_omit_pages_plus\";s:0:\"\";s:19:\"ssba_omit_pages_bar\";s:0:\"\";s:14:\"ssba_image_set\";s:7:\"somacro\";s:9:\"ssba_size\";s:2:\"35\";s:10:\"ssba_pages\";s:0:\"\";s:10:\"ssba_posts\";s:0:\"\";s:15:\"ssba_cats_archs\";s:0:\"\";s:13:\"ssba_homepage\";s:0:\"\";s:13:\"ssba_excerpts\";s:0:\"\";s:15:\"ssba_plus_pages\";s:0:\"\";s:15:\"ssba_plus_posts\";s:0:\"\";s:20:\"ssba_plus_cats_archs\";s:0:\"\";s:18:\"ssba_plus_homepage\";s:0:\"\";s:18:\"ssba_plus_excerpts\";s:0:\"\";s:14:\"ssba_bar_pages\";s:0:\"\";s:14:\"ssba_bar_posts\";s:0:\"\";s:19:\"ssba_bar_cats_archs\";s:0:\"\";s:17:\"ssba_bar_homepage\";s:0:\"\";s:17:\"ssba_bar_excerpts\";s:0:\"\";s:10:\"ssba_align\";s:4:\"left\";s:15:\"ssba_plus_align\";s:4:\"left\";s:14:\"ssba_bar_align\";s:4:\"left\";s:12:\"ssba_padding\";s:1:\"6\";s:20:\"ssba_before_or_after\";s:5:\"after\";s:25:\"ssba_before_or_after_plus\";s:5:\"after\";s:19:\"ssba_additional_css\";s:0:\"\";s:18:\"ssba_custom_styles\";s:0:\"\";s:26:\"ssba_custom_styles_enabled\";s:0:\"\";s:24:\"ssba_plus_additional_css\";s:0:\"\";s:23:\"ssba_plus_custom_styles\";s:0:\"\";s:31:\"ssba_plus_custom_styles_enabled\";s:0:\"\";s:23:\"ssba_bar_additional_css\";s:0:\"\";s:22:\"ssba_bar_custom_styles\";s:0:\"\";s:30:\"ssba_bar_custom_styles_enabled\";s:0:\"\";s:18:\"ssba_email_message\";s:0:\"\";s:17:\"ssba_twitter_text\";s:0:\"\";s:16:\"ssba_buffer_text\";s:0:\"\";s:19:\"ssba_flattr_user_id\";s:0:\"\";s:15:\"ssba_flattr_url\";s:0:\"\";s:25:\"ssba_bar_share_new_window\";s:1:\"Y\";s:21:\"ssba_share_new_window\";s:1:\"Y\";s:26:\"ssba_plus_share_new_window\";s:1:\"Y\";s:16:\"ssba_link_to_ssb\";s:1:\"N\";s:21:\"ssba_show_share_count\";s:0:\"\";s:26:\"ssba_plus_show_share_count\";s:0:\"\";s:25:\"ssba_bar_show_share_count\";s:0:\"\";s:22:\"ssba_share_count_style\";s:7:\"default\";s:20:\"ssba_share_count_css\";s:0:\"\";s:21:\"ssba_share_count_once\";s:1:\"Y\";s:27:\"ssba_plus_share_count_style\";s:7:\"default\";s:25:\"ssba_plus_share_count_css\";s:0:\"\";s:26:\"ssba_plus_share_count_once\";s:1:\"Y\";s:26:\"ssba_bar_share_count_style\";s:7:\"default\";s:24:\"ssba_bar_share_count_css\";s:0:\"\";s:25:\"ssba_bar_share_count_once\";s:1:\"Y\";s:16:\"ssba_widget_text\";s:0:\"\";s:17:\"ssba_rel_nofollow\";s:0:\"\";s:22:\"ssba_default_pinterest\";s:0:\"\";s:23:\"ssba_pinterest_featured\";s:0:\"\";s:21:\"ssba_plus_widget_text\";s:0:\"\";s:22:\"ssba_plus_rel_nofollow\";s:0:\"\";s:27:\"ssba_plus_default_pinterest\";s:0:\"\";s:28:\"ssba_plus_pinterest_featured\";s:0:\"\";s:20:\"ssba_bar_widget_text\";s:0:\"\";s:21:\"ssba_bar_rel_nofollow\";s:0:\"\";s:26:\"ssba_bar_default_pinterest\";s:0:\"\";s:27:\"ssba_bar_pinterest_featured\";s:0:\"\";s:21:\"ssba_content_priority\";s:2:\"10\";s:16:\"ssba_div_padding\";s:0:\"\";s:24:\"ssba_div_rounded_corners\";s:0:\"\";s:17:\"ssba_border_width\";s:0:\"\";s:15:\"ssba_div_border\";s:0:\"\";s:19:\"ssba_div_background\";s:0:\"\";s:15:\"ssba_share_text\";s:13:\"Share this...\";s:19:\"ssba_text_placement\";s:5:\"above\";s:16:\"ssba_font_family\";s:0:\"\";s:15:\"ssba_font_color\";s:0:\"\";s:14:\"ssba_font_size\";s:2:\"12\";s:16:\"ssba_font_weight\";s:0:\"\";s:20:\"ssba_plus_share_text\";s:13:\"Share this...\";s:24:\"ssba_plus_text_placement\";s:5:\"above\";s:21:\"ssba_plus_font_family\";s:0:\"\";s:20:\"ssba_plus_font_color\";s:0:\"\";s:19:\"ssba_plus_font_size\";s:2:\"12\";s:21:\"ssba_plus_font_weight\";s:0:\"\";s:21:\"ssba_selected_buttons\";s:35:\"facebook,pinterest,twitter,linkedin\";s:25:\"ssba_selected_bar_buttons\";s:35:\"facebook,pinterest,twitter,linkedin\";s:26:\"ssba_selected_plus_buttons\";s:35:\"facebook,pinterest,twitter,linkedin\";s:22:\"ssba_plus_button_style\";i:1;s:14:\"ssba_bar_style\";i:1;s:16:\"ssba_new_buttons\";s:0:\"\";s:16:\"ssba_bar_enabled\";s:0:\"\";s:17:\"ssba_bar_position\";s:4:\"left\";s:16:\"ssba_plus_height\";s:2:\"48\";s:15:\"ssba_plus_width\";s:2:\"48\";s:16:\"ssba_plus_margin\";s:2:\"12\";s:22:\"ssba_plus_button_color\";s:0:\"\";s:28:\"ssba_plus_button_hover_color\";s:0:\"\";s:19:\"ssba_plus_icon_size\";s:0:\"\";s:20:\"ssba_plus_icon_color\";s:0:\"\";s:26:\"ssba_plus_icon_hover_color\";s:0:\"\";s:15:\"ssba_bar_height\";s:2:\"48\";s:14:\"ssba_bar_width\";s:2:\"48\";s:15:\"ssba_bar_margin\";s:1:\"0\";s:18:\"ssba_bar_icon_size\";s:0:\"\";s:21:\"ssba_bar_button_color\";s:0:\"\";s:27:\"ssba_bar_button_hover_color\";s:0:\"\";s:19:\"ssba_bar_icon_color\";s:0:\"\";s:25:\"ssba_bar_icon_hover_color\";s:0:\"\";s:16:\"ssba_bar_desktop\";s:1:\"Y\";s:15:\"ssba_bar_mobile\";s:1:\"Y\";s:22:\"ssba_mobile_breakpoint\";s:0:\"\";s:17:\"ssba_custom_email\";s:0:\"\";s:20:\"ssba_custom_facebook\";s:0:\"\";s:19:\"ssba_custom_twitter\";s:0:\"\";s:18:\"ssba_custom_diggit\";s:0:\"\";s:16:\"ssba_custom_line\";s:0:\"\";s:17:\"ssba_custom_skype\";s:0:\"\";s:17:\"ssba_custom_weibo\";s:0:\"\";s:20:\"ssba_custom_linkedin\";s:0:\"\";s:18:\"ssba_custom_reddit\";s:0:\"\";s:23:\"ssba_custom_stumbleupon\";s:0:\"\";s:21:\"ssba_custom_pinterest\";s:0:\"\";s:18:\"ssba_custom_buffer\";s:0:\"\";s:18:\"ssba_custom_flattr\";s:0:\"\";s:18:\"ssba_custom_tumblr\";s:0:\"\";s:17:\"ssba_custom_print\";s:0:\"\";s:14:\"ssba_custom_vk\";s:0:\"\";s:18:\"ssba_custom_yummly\";s:0:\"\";s:25:\"ssba_custom_facebook_save\";s:0:\"\";s:19:\"sharedcount_enabled\";s:0:\"\";s:19:\"sharedcount_api_key\";s:0:\"\";s:16:\"sharedcount_plan\";s:4:\"free\";s:24:\"sharedcount_plus_enabled\";s:0:\"\";s:24:\"sharedcount_plus_api_key\";s:0:\"\";s:21:\"sharedcount_plus_plan\";s:4:\"free\";s:25:\"sharedcount_share_enabled\";s:0:\"\";s:25:\"sharedcount_share_api_key\";s:0:\"\";s:22:\"sharedcount_share_plan\";s:4:\"free\";s:17:\"facebook_insights\";s:0:\"\";s:15:\"facebook_app_id\";s:0:\"\";s:19:\"ignore_facebook_sdk\";s:0:\"\";s:22:\"plus_facebook_insights\";s:0:\"\";s:20:\"plus_facebook_app_id\";s:0:\"\";s:24:\"plus_ignore_facebook_sdk\";s:0:\"\";s:23:\"share_facebook_insights\";s:0:\"\";s:21:\"share_facebook_app_id\";s:0:\"\";s:24:\"accepted_sharethis_terms\";s:1:\"N\";}","yes");
INSERT INTO `wp_options` VALUES("253","ssba_buttons","a:20:{s:6:\"buffer\";a:1:{s:9:\"full_name\";s:6:\"Buffer\";}s:6:\"diggit\";a:1:{s:9:\"full_name\";s:6:\"Diggit\";}s:4:\"line\";a:1:{s:9:\"full_name\";s:4:\"Line\";}s:5:\"skype\";a:1:{s:9:\"full_name\";s:5:\"Skype\";}s:5:\"weibo\";a:1:{s:9:\"full_name\";s:5:\"Weibo\";}s:5:\"email\";a:1:{s:9:\"full_name\";s:5:\"Email\";}s:8:\"facebook\";a:1:{s:9:\"full_name\";s:8:\"Facebook\";}s:13:\"facebook_save\";a:1:{s:9:\"full_name\";s:13:\"Facebook Save\";}s:6:\"flattr\";a:1:{s:9:\"full_name\";s:6:\"Flattr\";}s:8:\"linkedin\";a:1:{s:9:\"full_name\";s:8:\"LinkedIn\";}s:9:\"pinterest\";a:1:{s:9:\"full_name\";s:9:\"Pinterest\";}s:5:\"print\";a:1:{s:9:\"full_name\";s:5:\"Print\";}s:6:\"reddit\";a:1:{s:9:\"full_name\";s:6:\"Reddit\";}s:11:\"stumbleupon\";a:1:{s:9:\"full_name\";s:11:\"StumbleUpon\";}s:6:\"tumblr\";a:1:{s:9:\"full_name\";s:6:\"Tumblr\";}s:7:\"twitter\";a:1:{s:9:\"full_name\";s:7:\"Twitter\";}s:2:\"vk\";a:1:{s:9:\"full_name\";s:2:\"VK\";}s:8:\"whatsapp\";a:1:{s:9:\"full_name\";s:8:\"WhatsApp\";}s:4:\"xing\";a:1:{s:9:\"full_name\";s:4:\"Xing\";}s:6:\"yummly\";a:1:{s:9:\"full_name\";s:6:\"Yummly\";}}","yes");
INSERT INTO `wp_options` VALUES("254","ssba_version","8.1.2","yes");
INSERT INTO `wp_options` VALUES("258","xmsg_Log","a:3:{i:0;s:76:\"Jan 28 2021 23:28:15 - <strong>Auto ping skipped. No modified posts</strong>\";i:1;s:220:\"Jan 27 2021 18:37:15 - <strong>Bing Auto ping - Дякуємо, що надіслали свою карту Sitemap. Станьте користувачем засобів веб-майстра Bing, щоб пе</strong>\";i:2;s:116:\"Jan 27 2021 18:37:15 - <strong>Google Auto ping - 
Google Webmaster Tools
-
Sitemap Notification Received

</strong>\";}","yes");
INSERT INTO `wp_options` VALUES("264","_transient_users_online","a:1:{i:0;a:4:{s:7:\"user_id\";i:1;s:13:\"last_activity\";i:1611887266;s:10:\"ip_address\";s:9:\"127.0.0.1\";s:7:\"blog_id\";b:0;}}","no");
INSERT INTO `wp_options` VALUES("265","_transient_timeout_users_online","1611878288","no");
INSERT INTO `wp_options` VALUES("269","_site_transient_timeout_theme_roots","1611878278","no");
INSERT INTO `wp_options` VALUES("270","_site_transient_theme_roots","a:1:{s:6:\"protur\";s:7:\"/themes\";}","no");
INSERT INTO `wp_options` VALUES("271","_transient_timeout_aiowps_captcha_string_info_32jskumt4h","1611878288","no");
INSERT INTO `wp_options` VALUES("272","_transient_aiowps_captcha_string_info_32jskumt4h","MTYxMTg3NjQ4OGFldzJ6aHk2MG8xbGJjaTBmcnZkNg==","no");
INSERT INTO `wp_options` VALUES("273","_transient_health-check-site-status-result","{\"good\":\"14\",\"recommended\":\"6\",\"critical\":\"0\"}","yes");
INSERT INTO `wp_options` VALUES("275","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:63:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.6.zip\";s:6:\"locale\";s:5:\"ru_RU\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:63:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.6.zip\";s:10:\"no_content\";s:0:\"\";s:11:\"new_bundled\";s:0:\"\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:3:\"5.6\";s:7:\"version\";s:3:\"5.6\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.6\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1611876492;s:15:\"version_checked\";s:3:\"5.6\";s:12:\"translations\";a:1:{i:0;a:7:{s:4:\"type\";s:4:\"core\";s:4:\"slug\";s:7:\"default\";s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:3:\"5.6\";s:7:\"updated\";s:19:\"2021-01-28 20:09:26\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.6/ru_RU.zip\";s:10:\"autoupdate\";b:1;}}}","no");
INSERT INTO `wp_options` VALUES("276","_site_transient_update_themes","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1611876493;s:7:\"checked\";a:1:{s:6:\"protur\";s:5:\"1.0.0\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:0:{}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("277","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1611876494;s:7:\"checked\";a:7:{s:30:\"advanced-custom-fields/acf.php\";s:5:\"5.9.4\";s:43:\"all-in-one-seo-pack/all_in_one_seo_pack.php\";s:6:\"4.0.12\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:5:\"4.4.6\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.3.2\";s:63:\"www-xml-sitemap-generator-org/www-xml-sitemap-generator-org.php\";s:5:\"1.3.5\";s:21:\"imsanity/imsanity.php\";s:5:\"2.7.1\";s:57:\"simple-share-buttons-adder/simple-share-buttons-adder.php\";s:5:\"8.1.2\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:7:{s:30:\"advanced-custom-fields/acf.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:36:\"w.org/plugins/advanced-custom-fields\";s:4:\"slug\";s:22:\"advanced-custom-fields\";s:6:\"plugin\";s:30:\"advanced-custom-fields/acf.php\";s:11:\"new_version\";s:5:\"5.9.4\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/advanced-custom-fields/\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/plugin/advanced-custom-fields.5.9.4.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746\";s:2:\"1x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";s:2:\"1x\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";}s:11:\"banners_rtl\";a:0:{}}s:43:\"all-in-one-seo-pack/all_in_one_seo_pack.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:33:\"w.org/plugins/all-in-one-seo-pack\";s:4:\"slug\";s:19:\"all-in-one-seo-pack\";s:6:\"plugin\";s:43:\"all-in-one-seo-pack/all_in_one_seo_pack.php\";s:11:\"new_version\";s:6:\"4.0.12\";s:3:\"url\";s:50:\"https://wordpress.org/plugins/all-in-one-seo-pack/\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/plugin/all-in-one-seo-pack.4.0.12.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:72:\"https://ps.w.org/all-in-one-seo-pack/assets/icon-256x256.png?rev=2443290\";s:2:\"1x\";s:64:\"https://ps.w.org/all-in-one-seo-pack/assets/icon.svg?rev=2443290\";s:3:\"svg\";s:64:\"https://ps.w.org/all-in-one-seo-pack/assets/icon.svg?rev=2443290\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/all-in-one-seo-pack/assets/banner-1544x500.png?rev=2443290\";s:2:\"1x\";s:74:\"https://ps.w.org/all-in-one-seo-pack/assets/banner-772x250.png?rev=2443290\";}s:11:\"banners_rtl\";a:0:{}}s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:5:\"4.4.6\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:91:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-1544x500.png?rev=1914011\";s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1914013\";}s:11:\"banners_rtl\";a:0:{}}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.3.2\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.3.2.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:67:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=2279696\";s:2:\"1x\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";s:3:\"svg\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}}s:63:\"www-xml-sitemap-generator-org/www-xml-sitemap-generator-org.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:43:\"w.org/plugins/www-xml-sitemap-generator-org\";s:4:\"slug\";s:29:\"www-xml-sitemap-generator-org\";s:6:\"plugin\";s:63:\"www-xml-sitemap-generator-org/www-xml-sitemap-generator-org.php\";s:11:\"new_version\";s:5:\"1.3.5\";s:3:\"url\";s:60:\"https://wordpress.org/plugins/www-xml-sitemap-generator-org/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/www-xml-sitemap-generator-org.1.3.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:82:\"https://ps.w.org/www-xml-sitemap-generator-org/assets/icon-256x256.jpg?rev=1207053\";s:2:\"1x\";s:82:\"https://ps.w.org/www-xml-sitemap-generator-org/assets/icon-128x128.jpg?rev=1207053\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:85:\"https://ps.w.org/www-xml-sitemap-generator-org/assets/banner-1544x500.jpg?rev=1207053\";s:2:\"1x\";s:84:\"https://ps.w.org/www-xml-sitemap-generator-org/assets/banner-772x250.jpg?rev=1207053\";}s:11:\"banners_rtl\";a:0:{}}s:21:\"imsanity/imsanity.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:22:\"w.org/plugins/imsanity\";s:4:\"slug\";s:8:\"imsanity\";s:6:\"plugin\";s:21:\"imsanity/imsanity.php\";s:11:\"new_version\";s:5:\"2.7.1\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/imsanity/\";s:7:\"package\";s:51:\"https://downloads.wordpress.org/plugin/imsanity.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:61:\"https://ps.w.org/imsanity/assets/icon-256x256.png?rev=2420360\";s:2:\"1x\";s:53:\"https://ps.w.org/imsanity/assets/icon.svg?rev=2420360\";s:3:\"svg\";s:53:\"https://ps.w.org/imsanity/assets/icon.svg?rev=2420360\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/imsanity/assets/banner-1544x500.png?rev=2420360\";s:2:\"1x\";s:63:\"https://ps.w.org/imsanity/assets/banner-772x250.png?rev=2420360\";}s:11:\"banners_rtl\";a:0:{}}s:57:\"simple-share-buttons-adder/simple-share-buttons-adder.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:40:\"w.org/plugins/simple-share-buttons-adder\";s:4:\"slug\";s:26:\"simple-share-buttons-adder\";s:6:\"plugin\";s:57:\"simple-share-buttons-adder/simple-share-buttons-adder.php\";s:11:\"new_version\";s:5:\"8.1.2\";s:3:\"url\";s:57:\"https://wordpress.org/plugins/simple-share-buttons-adder/\";s:7:\"package\";s:75:\"https://downloads.wordpress.org/plugin/simple-share-buttons-adder.8.1.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:79:\"https://ps.w.org/simple-share-buttons-adder/assets/icon-256x256.png?rev=1267481\";s:2:\"1x\";s:79:\"https://ps.w.org/simple-share-buttons-adder/assets/icon-256x256.png?rev=1267481\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:82:\"https://ps.w.org/simple-share-buttons-adder/assets/banner-1544x500.png?rev=1267481\";s:2:\"1x\";s:81:\"https://ps.w.org/simple-share-buttons-adder/assets/banner-772x250.png?rev=1267481\";}s:11:\"banners_rtl\";a:0:{}}}}","no");
INSERT INTO `wp_options` VALUES("278","_site_transient_timeout_browser_5cd022c67bba483be4643a4599b579f2","1612481320","no");
INSERT INTO `wp_options` VALUES("279","_site_transient_browser_5cd022c67bba483be4643a4599b579f2","a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"88.0.4324.104\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `wp_options` VALUES("280","_site_transient_timeout_community-events-1aecf33ab8525ff212ebdffbb438372e","1611919727","no");
INSERT INTO `wp_options` VALUES("281","_site_transient_community-events-1aecf33ab8525ff212ebdffbb438372e","a:4:{s:9:\"sandboxed\";b:0;s:5:\"error\";N;s:8:\"location\";a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}s:6:\"events\";a:2:{i:0;a:10:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:49:\"Discussion group: How To Find Help With WordPress\";s:3:\"url\";s:72:\"https://www.meetup.com/learn-wordpress-discussions/events/xdcjdsyccdbwb/\";s:6:\"meetup\";s:27:\"Learn WordPress Discussions\";s:10:\"meetup_url\";s:51:\"https://www.meetup.com/learn-wordpress-discussions/\";s:4:\"date\";s:19:\"2021-02-03 20:00:00\";s:8:\"end_date\";s:19:\"2021-02-03 21:00:00\";s:20:\"start_unix_timestamp\";i:1612411200;s:18:\"end_unix_timestamp\";i:1612414800;s:8:\"location\";a:4:{s:8:\"location\";s:6:\"Online\";s:7:\"country\";s:2:\"US\";s:8:\"latitude\";d:37.779998779297;s:9:\"longitude\";d:-122.41999816895;}}i:1;a:10:{s:4:\"type\";s:8:\"wordcamp\";s:5:\"title\";s:23:\"WordCamp India (Online)\";s:3:\"url\";s:32:\"https://india.wordcamp.org/2021/\";s:6:\"meetup\";N;s:10:\"meetup_url\";N;s:4:\"date\";s:19:\"2021-01-30 00:00:00\";s:8:\"end_date\";s:19:\"2021-02-14 00:00:00\";s:20:\"start_unix_timestamp\";i:1611945000;s:18:\"end_unix_timestamp\";i:1613241000;s:8:\"location\";a:4:{s:8:\"location\";s:6:\"Online\";s:7:\"country\";s:2:\"IN\";s:8:\"latitude\";d:20.593684;s:9:\"longitude\";d:78.96288;}}}}","no");
INSERT INTO `wp_options` VALUES("282","_transient_timeout_feed_126d1ca39d75da07beec8b892738427b","1611919729","no");
INSERT INTO `wp_options` VALUES("283","_transient_feed_126d1ca39d75da07beec8b892738427b","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Блог | WordPress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"https://ru.wordpress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Русский\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 15 Dec 2020 18:54:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"ru-RU\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=5.7-alpha-50060\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"Представляем Learn WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://ru.wordpress.org/news/2020/12/learn-wordpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 15 Dec 2020 18:52:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2250\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:691:\"  Learn WordPress — это учебная платформа, предлагающая мастер-классы, викторины, курсы, планы уроков и группы для обсуждения, чтобы любой, от начинающего пользователя до опытного разработчика мог делать больше с WordPress. Понимание того, как работает WordPress, как разрабатывать на его основе и как живет сообщество, важно для всех, кто хочет профессионально расти и принимать участие в [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:11826:\"<p> </p>
<p><strong><a href=\"https://learn.wordpress.org/\">Learn WordPress</a> — это учебная платформа, предлагающая мастер-классы, викторины, курсы, планы уроков и группы для обсуждения, чтобы любой, от начинающего пользователя до опытного разработчика мог делать больше с WordPress. Понимание того, как работает WordPress, как разрабатывать на его основе и как живет сообщество, важно для всех, кто хочет профессионально расти и принимать участие в развитии системы. </strong></p>
<div class=\"wp-block-buttons aligncenter\">
<div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link\" href=\"https://learn.wordpress.org/\">Learn WordPress</a></div>
</div>
<p>​Это результат совместной работы нескольких команд международного сообщества WordPress, является частью сети WordPress.org и содержит контент от участников из со всего мира. Платформа поможет поддерживать связь в процессе обучения, как новым, так и существующим членам сообщества.</p>
<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" class=\"wp-image-9457\" src=\"https://i1.wp.com/wordpress.org/news/files/2020/12/learn-link-preview.png?resize=632%2C331&amp;ssl=1\" alt=\"\" width=\"632\" height=\"332\" /></figure>
<p>​</p>
<h2>Что можно узнать о WordPress?</h2>
<p>​<br />На платформе Learn WordPress вы можете найти широкий перечень материалов и возможностей для обучения в удобное для вас время.</p>
<p>​<a href=\"https://learn.wordpress.org/workshops/\"><strong>Мастер-классы</strong></a> — это видеоролики, ориентированные на получение практических навыков, показывающие как решать определенные задачи в WordPress: публикацию и управление контентом, разработку и участие в развитии WordPress. Большая часть мастер-классов включает викторины и тесты для проверки полученных знаний.</p>
<p><a href=\"https://learn.wordpress.org/discussion-groups/\"><strong>Дискуссионные группы</strong></a> — это возможность для совместного обучения. Встречи для обсуждения тем мастер-классов проводятся онлайн как в виде видеоконференций, так и в Slack для комфортного участия вне зависимости от временных зон.</p>
<p><a href=\"https://learn.wordpress.org/lesson-plans/\"><strong>Планы уроков</strong></a> — это руководства, которые ведущие и докладчики могут использовать для организации мероприятий и образовательных презентаций. Планы уроков содержат всю необходимую информацию, начиная от цели урока и требований к навыкам участников, заканчивая вопросами для оценки результатов усвоения материала, а также дополнительные визуальные материалы, такие как скриншоты и слайды.<br /><a href=\"https://learn.wordpress.org/courses/\"><strong>Курсы</strong></a> — это серии связанных планов уроков для ведущего или организатора серии мероприятий для достижения определенной конечной образовательной цели. Участники могут проходить такой курс как индивидуально, так и в составе группы. После прохождения курса участники должны уметь применять полученные знания на практике.<br />В дополнение к огромному количеству информационных материалов, платформа Learn WordPress дает возможность учиться совместно с другими участниками и наладить взаимоотношения с мировым сообществом пользователей, разработчиков и теми, кто вносит вклад в развитие WordPress.</p>
<p><a href=\"https://www.youtube.com/playlist?list=PLCVEqsAbLffeEXhn9T1yBVTMaHIMtlzFj\">Почему вам стоит использовать Learn WordPress</a> – видео от нашего сообщества.</p>
<h2>Как вы можете принять участие?</h2>
<p>​</p>
<div class=\"wp-block-buttons aligncenter\">
<div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link\" href=\"https://learn.wordpress.org/\">Начните учиться сегодня!</a></div>
</div>
<p>​Learn WordPress — это платформа с открытым исходным кодом доступная для размещения контента всеми участниками по темам, означенным выше. <a href=\"https://learn.wordpress.org/contribute/\">Узнайте подробнее, как можно принять участие </a> в этой инициативе.</p>
<p>​<a href=\"https://make.wordpress.org/marketing/2020/12/09/help-us-promote-learn-wordpress/\">Примите участие в нашей рекламной компании </a> в социальных сетях.</p>
<p><em>Сотни людей на протяжении нескольких лет вносили свой вклад в развитие данных образовательных материалов. Спасибо всем, кто усердно работал, чтобы платформа Learn WordPress стала реальностью. </em></p>
<p><strong><em>Особая благодарность участникам команд</em></strong>:</p>
<p><strong><em>Образование:</em></strong><em> <a class=\"mention\" href=\"https://profiles.wordpress.org/courane01/\"><span class=\"mentions-prefix\">@</span>courane01</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/azhiyadev/\"><span class=\"mentions-prefix\">@</span>azhiyadev</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/jonoaldersonwp/\"><span class=\"mentions-prefix\">@</span>jonoaldersonwp</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/geheren/\"><span class=\"mentions-prefix\">@</span>geheren</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/webtechpooja/\"><span class=\"mentions-prefix\">@</span>webtechpooja</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/jessecowens/\"><span class=\"mentions-prefix\">@</span>jessecowens</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/onealtr/\"><span class=\"mentions-prefix\">@</span>onealtr</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/rastaban/\"><span class=\"mentions-prefix\">@</span>rastaban</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/evarlese/\"><span class=\"mentions-prefix\">@</span>evarlese</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/manzwebdesigns/\"><span class=\"mentions-prefix\">@</span>manzwebdesigns</a></em><br /><strong><em>Мета: </em></strong><em><a class=\"mention\" href=\"https://profiles.wordpress.org/coreymckrill/\"><span class=\"mentions-prefix\">@</span>coreymckrill</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/dufresnesteven/\"><span class=\"mentions-prefix\">@</span>dufresnesteven</a></em><br /><strong><em>Сообщество:</em></strong><em> <a class=\"mention\" href=\"https://profiles.wordpress.org/hlashbrooke/\"><span class=\"mentions-prefix\">@</span>hlashbrooke</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/camikaos/\"><span class=\"mentions-prefix\">@</span>camikaos</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/harishanker/\"><span class=\"mentions-prefix\">@</span>harishanker</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/angelasjin/\"><span class=\"mentions-prefix\">@</span>angelasjin</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/nao/\"><span class=\"mentions-prefix\">@</span>nao</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/courtneypk/\"><span class=\"mentions-prefix\">@</span>courtneypk</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/andreamiddleton/\"><span class=\"mentions-prefix\">@</span>andreamiddleton</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/rmarks/\"><span class=\"mentions-prefix\">@</span>rmarks</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/sippis/\"><span class=\"mentions-prefix\">@</span>sippis</a></em><br /><strong><em>Маркетинг: </em></strong><em><a class=\"mention\" href=\"https://profiles.wordpress.org/webcommsat/\"><span class=\"mentions-prefix\">@</span>webcommsat</a>,  <a class=\"mention mention-current-user\" href=\"https://profiles.wordpress.org/oglekler/\"><span class=\"mentions-prefix\">@</span>oglekler</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/lmurillom/\"><span class=\"mentions-prefix\">@</span>lmurillom</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/yvettesonneveld/\"><span class=\"mentions-prefix\">@</span>yvettesonneveld</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/meher/\"><span class=\"mentions-prefix\">@</span>meher</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/nalininonstopnewsuk/\"><span class=\"mentions-prefix\">@</span>nalininonstopnewsuk</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/megphillips91/\"><span class=\"mentions-prefix\">@</span>megphillips91</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/marks99/\"><span class=\"mentions-prefix\">@</span>marks99</a>, <em><a class=\"mention\" href=\"https://profiles.wordpress.org/marybaum/\"><span class=\"mentions-prefix\">@</span>marybaum</a></em></em>, <em><a class=\"mention\" href=\"https://profiles.wordpress.org/antialiasfactory/\"><span class=\"mentions-prefix\">@</span>antialiasfactory</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/herculespekkas/\"><span class=\"mentions-prefix\">@</span>herculespekkas</a>, <a class=\"mention\" href=\"https://profiles.wordpress.org/chaion07/\"><span class=\"mentions-prefix\">@</span>chaion07</a></em><br /><strong><em>Дизайн:</em></strong><em> <a class=\"mention\" href=\"https://profiles.wordpress.org/melchoyce/\"><span class=\"mentions-prefix\">@</span>melchoyce</a> </em></p>
<p><em>Для того, чтобы посмотреть подробный список участников проекта, посетите <a href=\"https://make.wordpress.org/community/2020/08/12/learn-wordpress-is-live/\">статью о начале бета-тестирования</a>. Спасибо всем, кто принял участие и внесет свой вклад в будущем. </em></p>
<p><a href=\"https://learn.wordpress.org/tag/learnwordpress\">#LearnWordPress</a> <a href=\"https://learn.wordpress.org/tag/learnwp\">#LearnWP</a></p>


<p></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"Ежегодный опрос пользователей и разработчиков WordPress 2020\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://ru.wordpress.org/news/2020/10/2020-annual-survey/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 28 Oct 2020 07:22:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2223\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:743:\"Каждый год сообщество WordPress проводит ежегодный опрос для пользователей и участников сообщества. В этом году мы также предлагаем пройти вам этот опрос как и в прошлом году, предлагаются и другие языки &#8212; французский, немецкий, испанский и японский. Сбор данных осуществляется в полном соответствии с политикой конфиденциальности WordPress.org: все данные будут анонимизированы и не будут ассоциироваться [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5714:\"
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile\"><figure class=\"wp-block-media-text__media\"><img loading=\"lazy\" width=\"768\" height=\"342\" src=\"https://ru.wordpress.org/files/2019/11/image-12-1.png\" alt=\"\" class=\"wp-image-2145 size-full\" srcset=\"https://ru.wordpress.org/files/2019/11/image-12-1.png 768w, https://ru.wordpress.org/files/2019/11/image-12-1-300x134.png 300w\" sizes=\"(max-width: 768px) 100vw, 768px\" /></figure><div class=\"wp-block-media-text__content\">
<p style=\"font-size:18px\">Каждый год сообщество WordPress проводит ежегодный опрос для пользователей и участников сообщества. </p>
</div></div>



<p>В этом году мы также предлагаем пройти вам этот опрос</p>



<div class=\"wp-block-buttons aligncenter\">
<div class=\"wp-block-button\"><a class=\"wp-block-button__link has-black-color has-text-color has-background\" href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-russian\" style=\"border-radius:2px;background:linear-gradient(135deg,rgb(202,248,128) 0%,rgb(114,207,182) 81%)\" target=\"_blank\" rel=\"noreferrer noopener\">На русском</a></div>



<div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link has-text-color\" href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-english\" style=\"border-radius:2px;color:#ba0c49\" target=\"_blank\" rel=\"noreferrer noopener\">On english</a></div>
</div>



<p>как и в прошлом году, предлагаются и другие языки &#8212; <a rel=\"noreferrer noopener\" href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-french\" target=\"_blank\">французский</a>, <a href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-german\" target=\"_blank\" rel=\"noreferrer noopener\">немецкий</a>, <a rel=\"noreferrer noopener\" href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-spanish\" target=\"_blank\">испанский</a> и <a rel=\"noreferrer noopener\" href=\"https://wordpressdotorg.survey.fm/wordpress-2020-survey-japanese\" target=\"_blank\">японский</a>.</p>



<p>Сбор данных осуществляется в полном соответствии с <a rel=\"noreferrer noopener\" href=\"https://ru.wordpress.org/about/privacy/\" target=\"_blank\">политикой конфиденциальности WordPress.org</a>: все данные будут анонимизированы и не будут ассоциироваться с IP-адресами и адресами e-mail.</p>



<p>Как и в прошлом году, опрос 2020 года будет продвигаться с помощью баннера на WordPress.org, а также энтузиастами WordPress. </p>



<p>Каждый из переведённых опросов будет продвигаться с помощью баннеров на соответствующих локализованных сайтах WordPress.org. Пожалуйста, поощряйте и  стимулируйте своих друзей  и подписчиков социальных сетей тоже принять участие в опросе!</p>



<p>Для того, чтобы Ваш опыт работы с WordPress был представлен в результатах опроса 2020 года… не откладывайте! Опрос будет доступен для прохождения в течении 6 недель после даты публикации.</p>



<p>Также предлагаются результаты опроса за прошлый год в сравнении с результатами с 2015 года (некоторые результаты ранее не были опубликованы).</p>



<div class=\"wp-block-buttons\">
<div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link\" href=\"https://docs.google.com/presentation/d/1FI7eEvSB5SHTSILIBpwOmH9rBffgD6mFnnqSkrEScYo/edit\" target=\"_blank\" rel=\"noreferrer noopener\">Посмотреть слайды (Google Docs)</a></div>
</div>



<div class=\"wp-block-buttons\">
<div class=\"wp-block-button\"><a class=\"wp-block-button__link has-white-color has-text-color has-background\" href=\"https://www.dropbox.com/sh/bq62sficymopgos/AAA-wx73cDviVG84NSCTgjNDa?dl=0\" style=\"background-color:#005586\" target=\"_blank\" rel=\"noreferrer noopener\">Скачать презентацию (PDF, PPTX)</a></div>
</div>



<div class=\"wp-block-image\"><figure class=\"aligncenter size-large\"><a href=\"https://ru.wordpress.org/files/2020/11/Polyglots-Translator-Research-1.png\"><img loading=\"lazy\" width=\"655\" height=\"218\" src=\"https://ru.wordpress.org/files/2020/11/Polyglots-Translator-Research-1.png\" alt=\"\" class=\"wp-image-2241\" srcset=\"https://ru.wordpress.org/files/2020/11/Polyglots-Translator-Research-1.png 655w, https://ru.wordpress.org/files/2020/11/Polyglots-Translator-Research-1-300x100.png 300w\" sizes=\"(max-width: 655px) 100vw, 655px\" /></a></figure></div>



<p>Команда переводчиков WordPress и связанных с ним проектов (Polyglots team) также предлагает пройти небольшой опрос, касательно переводов проектов WordPress. Подробности об опросе для переводчиков можно прочитать <a href=\"https://ru.wordpress.org/team/2020/11/09/the-2020-polyglots-translator-research-form-is-now-open/\" target=\"_blank\" rel=\"noreferrer noopener\">по этой ссылке</a>.</p>



<p class=\"has-white-color has-text-color\"></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:63:\"
		
		
		
		
		
				
		
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"Mini WordPress Translation Day 2020 — Переводим WordPress вместе!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"https://ru.wordpress.org/news/2020/09/wptd2020/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 28 Sep 2020 09:33:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:4:\"WPTD\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2192\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:635:\"3 октября 2020 в 12:00 по Москве на YouTube пройдет стрим c Денисом Янчевским по переводу плагинов и тем для WordPress на русский язык. Планируемая продолжительность мероприятия — 3 часа. Присоединиться к стриму Перевод — отличный шанс внести свой вклад в развитие WordPress. Для участия не обязательно быть разработчиком и безупречно знать английский язык — [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:6677:\"
<div class=\"wp-block-image\"><figure class=\"aligncenter size-large\"><a href=\"https://www.youtube.com/watch?v=RMcDQvlBRSM\"><img loading=\"lazy\" width=\"1024\" height=\"538\" src=\"https://ru.wordpress.org/files/2020/09/Translation-Day-banner-1024x538.jpg\" alt=\"\" class=\"wp-image-2211\" srcset=\"https://ru.wordpress.org/files/2020/09/Translation-Day-banner-1024x538.jpg 1024w, https://ru.wordpress.org/files/2020/09/Translation-Day-banner-300x158.jpg 300w, https://ru.wordpress.org/files/2020/09/Translation-Day-banner-768x403.jpg 768w, https://ru.wordpress.org/files/2020/09/Translation-Day-banner.jpg 1281w\" sizes=\"(max-width: 1024px) 100vw, 1024px\" /></a></figure></div>



<p>3 октября 2020 в 12:00 по Москве на YouTube пройдет стрим c <a rel=\"noreferrer noopener\" href=\"https://profiles.wordpress.org/denisco/\" data-type=\"URL\" data-id=\"https://profiles.wordpress.org/denisco/\" target=\"_blank\">Денисом Янчевским</a> по переводу плагинов и тем для WordPress на русский язык. Планируемая продолжительность мероприятия — 3 часа.</p>



<p><a rel=\"noreferrer noopener\" href=\"https://www.youtube.com/watch?v=RMcDQvlBRSM\" data-type=\"URL\" data-id=\"https://www.youtube.com/watch?v=RMcDQvlBRSM\" target=\"_blank\">Присоединиться к стриму</a></p>



<p>Перевод — отличный шанс внести свой вклад в развитие WordPress. Для участия не обязательно быть разработчиком и безупречно знать английский язык — достаточно базовых знаний и желания учиться. Это также позволит пообщаться с единомышленниками и узнать новые темы и плагины.</p>



<p>Стримы проходят в дружеской атмосфере, с возможностью пообщаться в чате или голосом. Плагины и темы для перевода можно предложить в комментариях к стриму. На данный момент проведено <a href=\"https://ru.wordpress.org/team/category/%D1%81%D1%82%D1%80%D0%B8%D0%BC%D1%8B/\" data-type=\"URL\" data-id=\"https://ru.wordpress.org/team/category/%D1%81%D1%82%D1%80%D0%B8%D0%BC%D1%8B/\" target=\"_blank\" rel=\"noreferrer noopener\">более 20 стримов</a> и переведено несколько десятков плагинов (в том числе Gutenberg). Наиболее активные участники получили статус редакторов переводов с возможностью переводить плагины и темы без дополнительной проверки и проверять переводы других участников.</p>



<p><a rel=\"noreferrer noopener\" href=\"https://www.youtube.com/watch?v=RMcDQvlBRSM\" target=\"_blank\">Присоединиться к стриму</a></p>



<p>Для координации и обсуждения вопросов можно воспользоваться:</p>



<ul><li>каналом <code>translations</code> в <a rel=\"noreferrer noopener\" href=\"https://ruwp.slack.com/\" target=\"_blank\">Slack-группе русскоязычного сообщества WordPress</a> (при регистрации введите адрес вида <code>username@chat.wordpress.org</code>, где <code>username</code> — ваш логин на WordPress.org).</li><li>группой по <a rel=\"noreferrer noopener\" href=\"https://t.me/wp_translate\" data-type=\"URL\" data-id=\"https://t.me/wp_translate\" target=\"_blank\">переводам WordPress в Telegram</a>.</li></ul>



<p>Чтобы составить представление о мероприятии, можно посмотреть один из последних стримов по <a href=\"https://www.youtube.com/watch?v=DJunP3WvZOU\" data-type=\"URL\" data-id=\"https://www.youtube.com/watch?v=DJunP3WvZOU\" target=\"_blank\" rel=\"noreferrer noopener\">этой ссылке</a>.</p>



<p><strong>Полезные ресурсы</strong></p>



<ul><li><a href=\"https://ru.wordpress.org/team/handbook/translations/\" target=\"_blank\" rel=\"noreferrer noopener\">Как перевести тему или плагин?</a></li><li><a rel=\"noreferrer noopener\" href=\"https://codex.wordpress.org/Вниманию_переводчиков#.D0.A1.D1.82.D0.B8.D0.BB.D1.8C_.D0.BF.D0.B5.D1.80.D0.B5.D0.B2.D0.BE.D0.B4.D0.B0\" target=\"_blank\">Рекомендации по стилю перевода</a></li><li><a rel=\"noreferrer noopener\" href=\"https://codex.wordpress.org/Вниманию_переводчиков#.D0.9A.D0.B0.D0.BA_.D1.81.D0.B4.D0.B5.D0.BB.D0.B0.D1.82.D1.8C_.D1.85.D0.BE.D1.80.D0.BE.D1.88.D0.B8.D0.B9_.D0.BF.D0.B5.D1.80.D0.B5.D0.B2.D0.BE.D0.B4.3F\" target=\"_blank\">Как сделать хороший перевод</a></li><li><a rel=\"noreferrer noopener\" href=\"https://translate.wordpress.org/locale/ru/default/glossary\" target=\"_blank\">Словарь терминов</a></li><li><a rel=\"noreferrer noopener\" href=\"https://make.wordpress.org/polyglots/handbook/about/get-involved/first-steps/\" target=\"_blank\">Первые шаги переводчика</a></li><li><a rel=\"noreferrer noopener\" href=\"https://make.wordpress.org/polyglots/handbook/tools/glotpress-translate-wordpress-org/\" target=\"_blank\">Как работать с сайтом translate.wordpress.org (GlotPress)</a></li></ul>



<p><em><strong>Mini WordPress Translation Day 2020</strong> — это серия онлайн-мероприятий, которые пройдут с 28 сентября по 4 октября 2020 во множестве стран мира и приурочено к <a rel=\"noreferrer noopener\" href=\"https://make.wordpress.org/polyglots/2020/09/09/lets-celebrate-international-translation-day-together/\" target=\"_blank\">празднованию всемирного Дня переводчика</a>. Если вы уверенно владеете английским языком, присоединяйтесь к глобальному сообществу <a rel=\"noreferrer noopener\" href=\"https://make.wordpress.org/chat/\" target=\"_blank\">WordPress в Slack</a> и заходите на канал <a rel=\"noreferrer noopener\" href=\"https://wordpress.slack.com/messages/polyglots\" target=\"_blank\">#polyglots</a> в течение всей недели, чтобы познакомиться с коллегами со всего мира.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"Yoast SEO: Ищем русскоязычных блогеров\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:201:\"https://ru.wordpress.org/news/2020/05/yoast-seo-%d0%b8%d1%89%d0%b5%d0%bc-%d1%80%d1%83%d1%81%d1%81%d0%ba%d0%be%d1%8f%d0%b7%d1%8b%d1%87%d0%bd%d1%8b%d1%85-%d0%b1%d0%bb%d0%be%d0%b3%d0%b5%d1%80%d0%be%d0%b2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 17 May 2020 10:19:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2176\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:677:\"Два года назад в популярном плагине Yoast SEO появилась&#160;поддержка русского языка&#160;при анализе текста. В ближайших версиях плагина планируется улучшить морфологию для более полной поддержки различных словоформ. Ищем блогеров из русскоязычного сообщества, желающих опробовать эту функцию и, возможно, написать о ней 🙂 Кому интересно — пишите в теме на форуме. Спасибо!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Sergey Biryukov\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1013:\"
<p>Два года назад в популярном плагине Yoast SEO появилась&nbsp;<a href=\"https://yoast.com/yoast-seo-7-5/\">поддержка русского языка</a>&nbsp;при анализе текста.</p>



<p>В ближайших версиях плагина планируется улучшить морфологию для более полной поддержки различных словоформ.</p>



<p>Ищем блогеров из русскоязычного сообщества, желающих опробовать эту функцию и, возможно, написать о ней <img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>



<p>Кому интересно — пишите в <a href=\"https://ru.wordpress.org/support/topic/yoast-seo-ищем-русскоязычных-блогеров/\">теме на форуме</a>. Спасибо!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:63:\"
		
		
		
		
		
				
		
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"Прием заявок на выступление на WordCamp Moscow 2020 открыт!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:239:\"https://ru.wordpress.org/news/2020/03/%d0%bf%d1%80%d0%b8%d0%b5%d0%bc-%d0%b7%d0%b0%d1%8f%d0%b2%d0%be%d0%ba-%d0%bd%d0%b0-%d0%b2%d1%8b%d1%81%d1%82%d1%83%d0%bf%d0%bb%d0%b5%d0%bd%d0%b8%d0%b5-%d0%bd%d0%b0-wordcamp-moscow-2020-%d0%be%d1%82%d0%ba/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 10 Mar 2020 16:29:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:15:\"WordCamp Russia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2168\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:727:\"Ознакомиться с подробностями и подать заявку можно по ссылке: https://2020.moscow.wordcamp.org/call-for-speakers/ Прием заявок от спикеров будет идти до 20 апреля или до момента формирования расписания. Решение по каждой заявке будет отправлено в ответном письме до 1-го мая. Быть опытным спикером не обязательно, гораздо важнее разбираться в теме и желание поделиться опытом и знаниями. Сомневаетесь? Ознакомьтесь с [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1147:\"
<p>Ознакомиться с подробностями и подать заявку можно по ссылке: <a href=\"https://2020.moscow.wordcamp.org/call-for-speakers/\">https://2020.moscow.wordcamp.org/call-for-speakers/</a></p>



<p>Прием заявок от спикеров будет идти до 20 апреля или до момента формирования расписания. Решение по каждой заявке будет отправлено в ответном письме до 1-го мая.</p>



<p>Быть опытным спикером не обязательно, гораздо важнее разбираться в теме и желание поделиться опытом и знаниями. Сомневаетесь? <a href=\"https://2020.moscow.wordcamp.org/10-reasons-to-become-a-speaker-at-wordcamp/\" target=\"_blank\" rel=\"noreferrer noopener\">Ознакомьтесь с 10 причинами стать спикером</a>.</p>



<p>Любые вопросы можно задать по адресу <a href=\"mailto:moscow@wordcamp.org\">moscow@wordcamp.org</a>.</p>



<p></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:63:\"
		
		
		
		
		
				
		
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"Продажа билетов на WordCamp Moscow 2020 уже открыта!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:220:\"https://ru.wordpress.org/news/2020/03/%d0%bf%d1%80%d0%be%d0%b4%d0%b0%d0%b6%d0%b0-%d0%b1%d0%b8%d0%bb%d0%b5%d1%82%d0%be%d0%b2-%d0%bd%d0%b0-wordcamp-moscow-2020-%d1%83%d0%b6%d0%b5-%d0%be%d1%82%d0%ba%d1%80%d1%8b%d1%82%d0%b0/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 03 Mar 2020 07:00:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:15:\"WordCamp Russia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2160\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:652:\"Приобрести билет Вы можете на странице регистрации мероприятия. Конференции WordCamp в Москве проводятся c 2013 года и обычно в последний месяц лета на площадке Digital October. Мы решили нарушить традицию и провести мероприятие в другое время и на новом месте. На этот раз технопарк «ФизТехПарк» радушно встретит всех участников 30-го мая! На конференции будет два [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2370:\"
<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"1024\" height=\"273\" src=\"https://ru.wordpress.org/files/2020/03/Frame-4-1024x273.jpg\" alt=\"\" class=\"wp-image-2164\" srcset=\"https://ru.wordpress.org/files/2020/03/Frame-4-1024x273.jpg 1024w, https://ru.wordpress.org/files/2020/03/Frame-4-300x80.jpg 300w, https://ru.wordpress.org/files/2020/03/Frame-4-768x205.jpg 768w, https://ru.wordpress.org/files/2020/03/Frame-4.jpg 1200w\" sizes=\"(max-width: 1024px) 100vw, 1024px\" /></figure>



<p>Приобрести билет Вы можете на странице <a rel=\"noreferrer noopener\" href=\"https://2020.moscow.wordcamp.org/tickets/\" target=\"_blank\">регистрации</a> мероприятия.</p>



<p>Конференции WordCamp в Москве проводятся c 2013 года и обычно в последний месяц лета на площадке Digital October. Мы решили нарушить традицию и провести мероприятие в другое время и на новом месте. На этот раз технопарк «ФизТехПарк» радушно встретит всех участников 30-го мая!</p>



<p>На конференции будет два потока. Вы сможете посетить основной поток из 10-11 докладов в Главном зале и участвовать в 2-3 мастер-классах в Малом зале. Также будет организован хелпдеск, где вы сможете задать вопросы и проконсультироваться у профессиональных разработчиков по поводу своих сайтов и проектов в течение дня.</p>



<p>WordCamp это ключевое событие года для WordPress-сообщества в Москве и за ее пределами. Наша задача сделать конференцию яркой, запоминающейся и максимально полезной для каждого участника.</p>



<p>Приобрести билет Вы можете на странице <a href=\"https://2020.moscow.wordcamp.org/tickets/\" target=\"_blank\" rel=\"noreferrer noopener\">регистрации</a> мероприятия.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"Ежегодный опрос пользователей и разработчиков WordPress 2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://ru.wordpress.org/news/2019/11/2019-annual-survey/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 03 Nov 2019 08:53:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2141\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:721:\"Каждый год сообщество WordPress проводит ежегодный опрос для пользователей и участников сообщества. В этом году мы рады предложить вам опрос не только на английском, но и на русском языке (также были добавлены испанский, французский, немецкий и японский). Опрос будет проводиться в течении четырех недель, результаты будут опубликованы в английском блоге WordPress.org. Сбор данных осуществляется в [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3146:\"
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile\"><figure class=\"wp-block-media-text__media\"><img loading=\"lazy\" width=\"768\" height=\"342\" src=\"https://ru.wordpress.org/files/2019/11/image-12-1.png\" alt=\"\" class=\"wp-image-2145 size-full\" srcset=\"https://ru.wordpress.org/files/2019/11/image-12-1.png 768w, https://ru.wordpress.org/files/2019/11/image-12-1-300x134.png 300w\" sizes=\"(max-width: 768px) 100vw, 768px\" /></figure><div class=\"wp-block-media-text__content\">
<p style=\"font-size:18px\">Каждый год сообщество WordPress проводит ежегодный опрос для пользователей и участников сообщества. </p>
</div></div>



<p>В этом году мы рады предложить вам опрос не только <a href=\"https://wordpressdotorg.survey.fm/wordpress-2019-survey-english\" target=\"_blank\" rel=\"noreferrer noopener\" aria-label=\"на английском (opens in a new tab)\">на английском</a>, но и на русском языке (также были добавлены <a href=\"https://wordpressdotorg.survey.fm/wordpress-2019-survey-spanish\">испанский</a>, <a href=\"https://wordpressdotorg.survey.fm/wordpress-2019-survey-french\">французский</a>, <a href=\"https://wordpressdotorg.survey.fm/wordpress-2019-survey-german\">немецкий</a> и <a href=\"https://wordpressdotorg.survey.fm/wordpress-2019-survey-japanese\">японский</a>). Опрос будет проводиться в течении четырех недель, результаты будут опубликованы в <a rel=\"noreferrer noopener\" aria-label=\"английском блоге WordPress.org (opens in a new tab)\" href=\"https://wordpress.org/news/\" target=\"_blank\">английском блоге WordPress.org</a>.</p>



<p>Сбор данных осуществляется в полном соответствии с <a href=\"https://ru.wordpress.org/about/privacy/\" target=\"_blank\" rel=\"noreferrer noopener\" aria-label=\"политикой конфиденциальности WordPress.org (opens in a new tab)\">политикой конфиденциальности WordPress.org</a>: все данные будут анонимизированы и не будут ассоциироваться с IP-адресами и адресами e-mail.</p>



<div class=\"wp-block-button\"><a class=\"wp-block-button__link has-very-light-gray-color has-vivid-cyan-blue-background-color has-text-color has-background\" href=\"https://wordpressdotorg.survey.fm/wordpress-2019-survey-russian\">Пройти опрос</a></div>



<p>Если вы ответите, что принимали участие в жизни сообщества или сделали что-либо для WordPress, то вам будет предложен дополнительный опрос для участников сообщества. Каждый из опросов займет примерно 5 минут.</p>



<p>Дополнение: опрос был продлён до 16 декабря.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:63:\"
		
		
		
		
		
				
		
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"Конференция WordCamp Санкт-Петербург 2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://ru.wordpress.org/news/2019/08/wordcamp-saint-petersburg-2019/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 Aug 2019 09:07:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:15:\"WordCamp Russia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2119\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:443:\"Второй WordCamp в Санкт-Петербурге пройдет 28 сентября. Для ознакомления с подробностями о мероприятии, а также если вы хотите стать спикером или волонтёром, посетите сайт: https://2019.saintpetersburg.wordcamp.org/ Заказ билетов на мероприятие доступен уже сегодня!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1525:\"
<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://2019.saintpetersburg.wordcamp.org/files/2019/08/b46860.png\" alt=\"\" /></figure></div>



<p>Второй WordCamp в Санкт-Петербурге пройдет 28 сентября. Для ознакомления с подробностями о мероприятии, а также если вы хотите стать спикером или волонтёром, посетите сайт: <a rel=\"noreferrer noopener\" aria-label=\"https://2019.saintpetersburg.wordcamp.org/ (opens in a new tab)\" href=\"https://2019.saintpetersburg.wordcamp.org/\" target=\"_blank\">https://2019.saintpetersburg.wordcamp.org/</a></p>



<figure class=\"wp-block-image\"><img loading=\"lazy\" width=\"1024\" height=\"629\" src=\"https://ru.wordpress.org/files/2019/08/YP_0081-gallery-2-1024x629.jpg\" alt=\"\" class=\"wp-image-2125\" srcset=\"https://ru.wordpress.org/files/2019/08/YP_0081-gallery-2-1024x629.jpg 1024w, https://ru.wordpress.org/files/2019/08/YP_0081-gallery-2-300x184.jpg 300w, https://ru.wordpress.org/files/2019/08/YP_0081-gallery-2-768x472.jpg 768w, https://ru.wordpress.org/files/2019/08/YP_0081-gallery-2.jpg 1680w\" sizes=\"(max-width: 1024px) 100vw, 1024px\" /><figcaption>Конференция пройдет в пространстве коворкинга &#171;Ясная Поляна&#187; ул. Льва Толстого 1-3</figcaption></figure>



<p>Заказ билетов на мероприятие доступен уже сегодня!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"WordPress Translation Day 4 — Санкт-Петербург\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:152:\"https://ru.wordpress.org/news/2019/05/wordpress-translation-day-4-%d1%81%d0%b0%d0%bd%d0%ba%d1%82-%d0%bf%d0%b5%d1%82%d0%b5%d1%80%d0%b1%d1%83%d1%80%d0%b3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 09 May 2019 11:53:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2099\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:685:\"Друзья! Ни для кого не секрет, что 11-го мая проходит всемирный суточный марафон перевода WordPress. В рамках https://wptranslationday.org/ в Петербурге очная часть пройдет по адресу 9-я Советская, 18 (пространство funhouse, цоколь) с 12.00 до 21.00. Вход свободный в любое время. В программе &#8212; философия WordPress полиглотов, инструктаж, практическая часть, где мы переводим непереведенные плагины, темы, [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1476:\"
<p>Друзья! Ни для кого не секрет, что 11-го мая проходит всемирный суточный марафон перевода WordPress. В рамках <a href=\"https://wptranslationday.org/\">https://wptranslationday.org/</a>  в Петербурге очная часть <a href=\"https://www.meetup.com/St-Petersburg-WordPress-Meetup/events/261316455/\" target=\"_blank\" rel=\"noreferrer noopener\" aria-label=\"пройдет (opens in a new tab)\">пройдет</a> по адресу 9-я Советская, 18  (пространство funhouse, цоколь) с 12.00 до 21.00. Вход свободный в любое  время.</p>



<p>В программе &#8212; философия WordPress полиглотов, инструктаж,  практическая часть, где мы переводим непереведенные плагины, темы, и  т.д. Заочно можно участвовать присоединившись в Телеграм-группу @wcspb  <img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>



<p>Берем свои ноутбуки, знание русского языка (и немного английского), и отличное настроение!</p>



<p>Полиглоты, лингвисты, программисты объединяйтесь!</p>



<p></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:96:\"WP Moscow #6. Собственная тема на Elementor, кейс по WordPress + React JS\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:222:\"https://ru.wordpress.org/news/2019/02/wp-moscow-6-%d1%81%d0%be%d0%b1%d1%81%d1%82%d0%b2%d0%b5%d0%bd%d0%bd%d0%b0%d1%8f-%d1%82%d0%b5%d0%bc%d0%b0-%d0%bd%d0%b0-elementor-%d0%ba%d0%b5%d0%b9%d1%81-%d0%bf%d0%be-wordpress-react-js/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 Feb 2019 05:10:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2081\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:563:\"Очередной митап по WordPress состоится в четверг 28 февраля. Запланировано два доклада: «Создание собственной темы для WordPress сайта при помощи плагина Elementor»Леонид Лукин «Как сделать впечатляющий промо-сайт на WordPress + React JS. Разбор кейса.»Андрей Панферов Вход свободной по предварительной регистрации. Начало в 19.00.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:742:\"
<p>Очередной митап по WordPress состоится в четверг 28 февраля.</p>



<p>Запланировано два доклада:</p>



<p><strong>«Создание собственной темы для WordPress сайта при помощи плагина Elementor»</strong><br>Леонид Лукин</p>



<p><strong>«Как сделать впечатляющий промо-сайт на WordPress + React JS. Разбор кейса.»</strong><br>Андрей Панферов</p>



<p>Вход свободной по <a href=\"https://www.meetup.com/ru-RU/wordpress-moscow/events/258755820/\">предварительной регистрации</a>.</p>



<p>Начало в 19.00.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:35:\"https://ru.wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"
	hourly	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"
	1	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Thu, 28 Jan 2021 23:28:46 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Thu, 28 Jan 2021 23:26:22 GMT\";s:4:\"link\";s:61:\"<https://ru.wordpress.org/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 2\";}}s:5:\"build\";s:14:\"20201016172007\";}","no");
INSERT INTO `wp_options` VALUES("284","_transient_timeout_feed_mod_126d1ca39d75da07beec8b892738427b","1611919729","no");
INSERT INTO `wp_options` VALUES("285","_transient_feed_mod_126d1ca39d75da07beec8b892738427b","1611876529","no");
INSERT INTO `wp_options` VALUES("286","_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9","1611919730","no");
INSERT INTO `wp_options` VALUES("287","_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:61:\"
	
	
	
	




















































\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Planet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"en\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WordPress Planet - http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:50:{i:0;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:112:\"WPTavern: WP Lookout Lets WordPress Users Track and Receive Notifications for Their Preferred Plugins and Themes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=108062\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:269:\"https://wptavern.com/wp-lookout-lets-wordpress-users-track-and-receive-notifications-for-their-preferred-plugins-and-themes?utm_source=rss&utm_medium=rss&utm_campaign=wp-lookout-lets-wordpress-users-track-and-receive-notifications-for-their-preferred-plugins-and-themes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8074:\"<p class=\"has-drop-cap\"><em>Should WordPress notify users of plugin ownership changes?</em> That was the question that Ian Atkins asked two months ago. WP Tavern readers seemed to think it was a good idea, at least those who commented on our <a href=\"https://wptavern.com/should-wordpress-notify-users-of-plugin-ownership-changes\">coverage of it</a>. However, the original <a href=\"https://meta.trac.wordpress.org/ticket/5509\">Trac ticket</a> has not seen any movement since.</p>



<p>There are real technical issues with automating the process. A change of ownership does not necessarily equate to a change of the plugin author. This is often the case when someone acquires a company and maintains the brand.</p>



<p>Tracking such changes does not necessarily need to go through WordPress. Chris Hardie built a service called <a href=\"https://wplookout.com/\">WP Lookout</a> that notifies users of such changes and much more. It has also been available since August of 2020.</p>



<p>&ldquo;WP Lookout watches for interesting changes to the WordPress themes and plugins that someone cares about,&rdquo; said Hardie. &ldquo;I created WP Lookout for professional WordPress developers, consultants, and site managers who want to stay more informed about the plugins and themes that they (and their clients) depend on.&rdquo;</p>



<p>While WP Lookout faces the same challenges with plugin ownership changes, it does have an advantage. It also <a href=\"https://wplookout.com/2020/12/tracking-mentions-in-wordpress-news/\">tracks WordPress news organizations</a>, including WP Tavern and <a href=\"https://poststatus.com/\">Post Status</a>. Even if the ownership change is not reflected on the plugin&rsquo;s WordPress.org page, the story may be picked up in the news.</p>



<p>Hardie launched the news-tracking feature in early December 2020. It includes the <a href=\"https://www.wordfence.com/blog/category/vulnerabilities/\">Wordfence vulnerabilities blog</a> and <a href=\"https://ithemes.com/category/wordpress-vulnerability-roundup/\">iThemes vulnerabilities roundup blog</a> as a part of the service&rsquo;s security notification system. The service also scans change logs for keywords related to security.</p>



<p>Notifications do not stop there. The WP Lookout tracks plugin, theme, and core WordPress updates. It also supports several commercial plugins such as Advanced Custom Fields Pro, Gravity Forms, and WP Rocket.</p>



<p>&ldquo;When we first decide to use a theme or plugin on a WordPress site, we hopefully research it thoroughly &mdash; code quality, ratings, support responsiveness, new release history, speed of security fixes, and so on &mdash; but once it&rsquo;s installed it&rsquo;s easy to neglect those important bits of &lsquo;health&rsquo; information over time,&rdquo; said Hardie. &ldquo;Auto-updates are great from many perspectives, but I think anyone who has had to manage and troubleshoot a non-trivial WordPress site over time knows that it&rsquo;s also important to stay aware of, for example, what&rsquo;s happening in the change log or whether ownership of a plugin has changed hands. But nobody wants to log in to wp-admin on a bunch of sites every week to gather that info.&rdquo;</p>



<p>Hardie said WP Lookout will always have a robust free option for people who just want a daily email notification for a handful of plugins and themes. However, there are paid tiers for customers to access more features. They allow users to track more plugins and themes and get immediate alerts through email, RSS, Slack, or custom webhooks.</p>



<p>&ldquo;The middle tier supports up to 50 themes/plugins, immediate email notifications, and a personalized RSS feed,&rdquo; he said. &ldquo;The Builder tier supports up to 200 themes/plugins and adds in Slack and custom webhook support along with the option to just get security-related notifications. With more real-world user feedback, we may adjust what&rsquo;s in each tier over time.&rdquo;</p>



<p>All users get access to the Builder tier for a few weeks after signing up. After that, they must subscribe or stick with the free tier features.</p>



<h2>How the Service Works</h2>



<img />Single plugin tracking history.



<p class=\"has-drop-cap\">WP Lookout allows users to search for and add a tracker for individual plugins. The service primarily relies on the public WordPress.org API for getting plugin and theme data. This is the same system that WordPress uses to check to see if updates are available.</p>



<p>&ldquo;But it also goes beyond what the API offers,&rdquo; said Hardie. &ldquo;For example, there&rsquo;s no standard yet for theme authors to provide .ORG theme change logs, and so that information doesn&rsquo;t show up when you go to update a theme in wp-admin; you&rsquo;d have to go poking around in Trac or source files to find it. So WP Lookout follows the trail to the change log details and <a href=\"https://wplookout.com/2020/08/wordpress-theme-changelog-details/\">puts that right in front of you</a>.&rdquo;</p>



<img />Active plugin trackers.



<p>There is also a <a href=\"https://wordpress.org/plugins/wp-lookout/\">WP Lookout plugin</a> available in the plugin directory. It uses an API key, which users can get from the WP Lookout website. The plugin then lets the WP Lookout service know what plugins and themes are installed and adds them as trackers. Using the plugin is far more efficient than manually adding individual plugins and themes.</p>



<p>For plugins and themes that are not on WordPress.org, the service uses custom update APIs provided by the third-party developers. If that is not sufficient, it uses webpage scraping. For news sources, it parses RSS feeds.</p>



<p>&ldquo;It&rsquo;s been interesting to see the wide variety of ways that WordPress theme and plugin authors do or don&rsquo;t manage and present data publicly about their products,&rdquo; said Hardie. &ldquo;Some have API endpoints that return the same level of detail as the .ORG API, others have change log/version documents generated by some internal tools, and still others don&rsquo;t bother doing much at all. I think an argument could be made to standardize on something here for the long-run to help boost the culture of keeping software updated, even/especially if it eventually makes the need for a tool like WP Lookout obsolete.&rdquo;</p>



<h2>The Future of WP Lookout</h2>



<p class=\"has-drop-cap\">Hardie has no plans of sitting on what he has already built. One of the next goals is regularly adding new themes and plugins that are not on WordPress.org. This will mean connecting with development teams and figuring out how users can get notifications of things that often have no public APIs. The lack of standardization in the space could be a tough hurdle to jump.</p>



<p>&ldquo;I have a long list of features I&rsquo;m planning to add, including things like integrating tracking GitHub repo releases, bringing some helpful data points from WP Lookout into the wp-admin interface, WordPress Packagist integration, allowing per-tracker Slack channel configurations, better internationalization, and better handling of change logs that theme/plugin authors chose to maintain outside of their .org code repositories,&rdquo; he said.</p>



<p>Hardie does not want to get too far ahead of himself with feature ideas. He said he is excited to get more feedback from users about what they find useful. Currently, there are 80 users, which is publicly available data. WP Lookout maintains an <a href=\"https://wplookout.com/open/\">open data and financial transparency page</a>.</p>



<p>&ldquo;Despite having paid options for more advanced users, I mostly think of this as a service I want to operate for the WordPress community, and I&rsquo;ll always have a robust set of free functionality,&rdquo; he said. &ldquo;I&rsquo;m also committed to participation in Five for the Future, bringing what I&rsquo;ve learned here back into improvements that might benefit all WordPress users, whether they take advantage of WP Lookout or not.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 28 Jan 2021 21:56:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:104:\"WPTavern: ElasticPress.io Service Considers Next Move after Elasticsearch Abandons Open Source Licensing\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110644\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:253:\"https://wptavern.com/elasticpress-io-service-considers-next-move-after-elasticsearch-abandons-open-source-licensing?utm_source=rss&utm_medium=rss&utm_campaign=elasticpress-io-service-considers-next-move-after-elasticsearch-abandons-open-source-licensing\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6933:\"<p>Elastic, makers of the search and analytic engine&nbsp;<a rel=\"noreferrer noopener\" href=\"https://www.elastic.co/what-is/elasticsearch\" target=\"_blank\">Elasticsearch</a>, have re-licensed its core product so that it is no longer open source. The company is moving new versions of both Kibana and Elasticsearch from the&nbsp;<a rel=\"noreferrer noopener\" href=\"https://www.apache.org/licenses/LICENSE-2.0\" target=\"_blank\">Apache 2.0-license</a>&nbsp;to be dual-licensed under the&nbsp;<a rel=\"noreferrer noopener\" href=\"https://www.mongodb.com/licensing/server-side-public-license\" target=\"_blank\">Server Side Public License (SSPL)</a>&nbsp;and the&nbsp;<a rel=\"noreferrer noopener\" href=\"https://github.com/elastic/elasticsearch/blob/0d8aa7527e242fbda9d84867ab8bc955758eebce/licenses/ELASTIC-LICENSE.txt\" target=\"_blank\">Elastic License</a>, which do not meet the <a href=\"https://opensource.org/osd\">Open Source Definition</a>. </p>



<p>In a post titled &ldquo;<a href=\"https://www.elastic.co/blog/why-license-change-AWS\">Amazon: NOT OK &ndash; why we had to change Elastic licensing</a>,&rdquo; Elastic blames Amazon for the license change:</p>



<blockquote class=\"wp-block-quote\"><p>Our license change is aimed at preventing companies from taking our Elasticsearch and Kibana products and providing them directly as a service without collaborating with us.</p><p>Our license change comes after years of what we believe to be Amazon/AWS misleading and confusing the community &ndash; enough is enough.</p></blockquote>



<p>Elastic claims AWS&rsquo;s behavior has &ldquo;forced&rdquo; the company to abandon its open source licensing, citing examples of what they perceive to be &ldquo;ethically challenged behavior.&rdquo; In 2019, Amazon created an Open Distro for Elasticsearch, and Elastic claims they used code copied by a third party from their commercial code, further dividing the community.</p>



<p>As a result of the license change, Amazon <a href=\"https://aws.amazon.com/blogs/opensource/stepping-up-for-a-truly-open-source-elasticsearch/\">announced</a> its intention to officially fork Elasticsearch and Kibana, with plans to roll the forks into its Open Distro distributions:</p>



<blockquote class=\"wp-block-quote\"><p>Our forks of Elasticsearch and Kibana will be based on the latest ALv2-licensed codebases, version 7.10. We will publish new GitHub repositories in the next few weeks. In time, both will be included in the existing Open Distro distributions, replacing the ALv2 builds provided by Elastic. We&rsquo;re in this for the long haul, and will work in a way that fosters healthy and sustainable open source practices&mdash;including implementing shared project governance with a community of contributors.</p></blockquote>



<p>The Open Source Initiative (OSI) <a href=\"https://opensource.org/node/1099\">reacted</a> to the news of the license change, calling the SSPL a &ldquo;fauxpen&rdquo; source license:</p>



<blockquote class=\"wp-block-quote\"><p>Fauxpen source licenses allow a user to view the source code but do not allow other highly important rights protected by the <a href=\"https://opensource.org/osd\">Open Source Definition</a>, such as the right to make use of the program for any field of endeavor. By design, and as explained by <a href=\"https://www.elastic.co/blog/licensing-change\">the most recent adopter</a>, Elastic, in a post it unironically titled &ldquo;<a href=\"https://www.elastic.co/blog/licensing-change\">Doubling Down on Open</a>,&rdquo; Elastic says that it now can &ldquo;restrict cloud service providers from offering our software as a service&rdquo; in violation of OSD6. Elastic didn&rsquo;t double down, it threw its cards in.</p></blockquote>



<p>Elastic&rsquo;s license changes may affect a few companies in the WordPress ecosystem that are redistributing Elasticsearch as a commercial offering. <a href=\"https://10up.com/\">10up</a>, creators of <a href=\"https://wordpress.org/plugins/elasticpress/\">ElasticPress</a>, by far the most popular Elasticsearch plugin for WordPress, also runs the&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"http://elasticpress.io/\">ElasticPress.io</a>&nbsp;SaaS platform. More than 6,000 sites are using the open source plugin, but the company said these users will not be affected.</p>



<p>&ldquo;No matter what this won&rsquo;t affect the EP plugin,&rdquo; 10up vice president of engineering Taylor Lovett said. &ldquo;I would say the news is definitely discouraging and not a great look for Elastic.&rdquo;</p>



<p>10up <a href=\"https://wptavern.com/10up-unveils-elasticpress-io-elasticsearch-as-a-service-for-wordpress-sites\">launched</a> ElasticPress.io in 2017 and Lovett says it has become &ldquo;an active part of the business with a plethora of customers,&rdquo; and continues to grow. The company is currently seeking legal advice on how Elasticsearch&rsquo;s licensing change will affect the ElasticPress.io service. Since previous versions of Elasticsearch remain open source, the company has time to figure out a new way forward.</p>



<p>&ldquo;Right now we really don&rsquo;t know what&rsquo;s going to happen,&rdquo; Lovett said. &ldquo;There is no rush for us to upgrade&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"http://elasticpress.io/\">ElasticPress.io</a>&nbsp;to Elasticsearch 7.11+ so we have plenty of time to decide how to address the issue.&rdquo;</p>



<p>Lovett confirmed that 10up is considering using the Amazon fork as an option but has not  made a decision on the matter yet.</p>



<p>&ldquo;I will say this does affect the end user in a way that they may end up having to choose between different flavors of Elasticserarch,&rdquo; Lovett said.<br /><br />&ldquo;For example, you may need to decide if you want the official Elastic distribution or if you want to go with AWS&rsquo;s fork.&rdquo;</p>



<p>Unfortunately, for businesses that built services on top of redistributing the previously open source Elasticsearch, Elastic&rsquo;s creators have gone back on <a href=\"https://web.archive.org/web/20200120104750/https:/www.elastic.co/what-is/open-x-pack\">the promise they made in 2018</a> to never change the license of any of the Apache 2.0 code of Elasticsearch, Kibana, Beats, and Logstash projects.&nbsp;As a consequence, Amazon has emerged as the one to drive the truly open source option for Elasticsearch and Kibana for the future.</p>



<p>&ldquo;Elastic&rsquo;s relicensing is not evidence of any failure of the open source licensing model or a gap in open source licenses,&rdquo; the OSI board of directors stated in a recent <a href=\"https://opensource.org/node/1099\">post</a> on the matter. &ldquo;It is simply that Elastic&rsquo;s current business model is inconsistent with what open source licenses are designed to do. Its current business desires are what proprietary licenses (which includes source available) are designed for.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 28 Jan 2021 20:25:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:96:\"WPTavern: Automattic Launches the Blank Canvas WordPress Theme for Building Single-Page Websites\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110986\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:237:\"https://wptavern.com/automattic-launches-the-blank-canvas-wordpress-theme-for-building-single-page-websites?utm_source=rss&utm_medium=rss&utm_campaign=automattic-launches-the-blank-canvas-wordpress-theme-for-building-single-page-websites\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7389:\"<img />Split Screen pattern from Blank Canvas.



<p class=\"has-drop-cap\">On Monday, Automattic <a href=\"https://wordpress.com/blog/2021/01/25/building-single-page-websites-on-wordpress-com/\">announced its Blank Canvas theme</a> on WordPress.com. The goal is to allow end-users to build single-page websites, such as an &ldquo;about me&rdquo; or product landing page.</p>



<p>Blank Canvas is a child theme of <a href=\"https://wptavern.com/exploring-seedlet-automattics-block-first-wordpress-theme\">Seedlet</a>, which Automattic&rsquo;s <a href=\"https://themeshaper.com/about/\">Theme Team</a> has been using as a launchpad. One example is its recently-released <a href=\"https://wptavern.com/automattic-releases-spearhead-a-seedlet-child-theme-aimed-at-podcasters-and-content-creators\">Spearhead</a> child theme. It also provided the foundational work for the recent Twenty Twenty-One default WordPress theme.</p>



<p>One-page themes are nothing new. Theme builders have been releasing them for years in various forms.</p>



<p>&ldquo;We&rsquo;ve been working on block patterns a lot lately, and it became clear that many of the single-page websites we come across daily &mdash; collections of links, newsletter signups, etc. &mdash; are basically just simple block patterns sitting on an otherwise blank page,&rdquo; said Kjell Reigstad, the lead developer on the theme. &ldquo;That being the case, it seemed like WordPress should be able to power these sorts of single-page sites pretty easily. Blank Canvas is an attempt to try that out.&rdquo;</p>



<p>WordPress is not the ideal platform for the majority of one-page sites. Doing so includes setting up a database, installing the software, and keeping everything updated. The admin interface is not well-suited to those types of sites. WordPress is a content management system. One page is not enough content to need a full-blown CMS to manage. There simply is little upside for the average user to go through the hassle of doing this on even the cheapest of shared hosting.</p>



<p>However, if you have a network where someone else, such as WordPress.com, takes out all the hassle of maintaining the backend and when it does not cost you a dime, WordPress suddenly makes more sense. It becomes an ideal platform for these types of sites.</p>



<p>Frankly, I do not know why they have not pushed this concept sooner. Jason Schuller has made a go of it with Leeflets in the past. Since then, he and Philip Kurth have taken that idea further and launched <a href=\"https://wptavern.com/landing-kit-for-wordpress-maps-any-post-or-page-to-a-custom-domain\">WP Landing Kit</a>, which builds on the same concept of creating multiple single-page landing sites from one WordPress installation.</p>



<p>In some respects, Blank Canvas offers a glimpse into Full Site Editing. It is almost a stepping stone or a small yet limited preview of things to come. The theme puts the entire design process into a single page and a single editor. Eventually, this will be extended to the whole website.</p>



<p>&ldquo;I think that&rsquo;s a great way to think about it,&rdquo; said Reigstad. &ldquo;Full Site Editing is coming soon, but in the meantime, Blank Canvas lets you do just a little bit more with Gutenberg than you could before.&rdquo;</p>



<h2>About the Theme</h2>



<p class=\"has-drop-cap\">The theme is called <strong>Blank</strong> Canvas for a reason. Its <a href=\"https://blankcanvasdemo.wordpress.com/\">demo page</a> is literally a blank screen with a footer message. The idea is that the end-user designs their homepage &mdash; or their entire site in the case of a single-page website &mdash; via the block editor.</p>



<p>For those who need a starting point, the theme comes packaged with six block patterns:</p>



<ul><li>About Me</li><li>Links</li><li>Invitation</li><li>Split Screen</li><li>Card</li><li>Email Signup</li></ul>



<img />Invitation block pattern.



<p>Self-hosted WordPress users can install the theme too. It is currently awaiting review for the theme directory, but they can snag the ZIP file or SVN link from its <a href=\"https://themes.trac.wordpress.org/ticket/94482\">Trac ticket</a>. For those giving it a test, be sure to disable the title and tagline via the customizer so they do not appear on the front end. That is assuming you want to use the theme as intended. It will also work as a more traditional theme because the Seedlet parent theme covers all the necessary features.</p>



<p>There are differences between the theme on WordPress.com and that submitted to the WordPress.org theme directory. The .ORG version has only four block patterns. The .COM version includes an additional Card pattern, which integrates with Automattic&rsquo;s Layout Grid plugin. The Email Signup pattern needs Jetpack&rsquo;s form feature.</p>



<p>Simple conditional checks for Layout Grid or Jetpack before registering the patterns would suffice for users with those plugins installed. &ldquo;That&rsquo;s planned,&rdquo; said Reigstad of adding the missing patterns, &ldquo;but we just didn&rsquo;t implement it yet.&rdquo;</p>



<img />Email Signup block pattern.



<p>WordPress.com users have something else to look forward to. In November, the service <a href=\"https://wptavern.com/wordpress-com-drops-over-100-block-patterns-carving-a-path-the-design-community-should-follow\">launched over 100 patterns</a>. &ldquo;One of the nice things is that there are already a lot of patterns out there that seem ready-made for single-page websites,&rdquo; said Reigstad.</p>



<p>He did say the team is working on bundling more patterns in the future. These may include more &ldquo;link in bio&rdquo; designs that expand on the one already in the theme today.</p>



<h2>Pioneering Block-Friendly Themes</h2>



<p class=\"has-drop-cap\">Several of the ideas available in this theme seemed to have started from the WordPress <a href=\"https://github.com/WordPress/theme-experiments\">Theme Experiments repository</a>. It features block patterns similar in scope to the <a href=\"https://wptavern.com/carrd-like-theme-experiment-provides-a-glimpse-into-the-future-of-theming\">Carrd-like theme</a> Reigstad built last October.</p>



<p>&ldquo;In general, building block-based themes helped redefine our idea of what a theme needed to be,&rdquo; he said. &ldquo;We&rsquo;d tended to think of a theme as a complicated piece of software that accounts for every scenario you throw at it: a blog, custom post types, category pages, search pages, the 404 page, etc.&rdquo;</p>



<p>Reigstad said that the block-based themes paradigm has forced the Theme Team to start small. Because Full Site Editing is still in flux, its features not ready, the team has built proof-of-concept themes with limited functionality.</p>



<p>&ldquo;The possibilities for block-based themes have grown considerably since then (as shown by TT1 Blocks, Q, Block-based Bosco, and others), but the early constraints helped spark ideas like that Carrd-inspired theme,&rdquo; he said. &ldquo;It turned out that you could build a pretty useful site with just a handful of blocks.</p>



<p>&ldquo;That mindset definitely informed Blank Canvas &mdash; we started small, with just the functionality someone would need to build a single-page site. Since it&rsquo;s based on a full-featured theme (Seedlet), you can grow with it too.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 27 Jan 2021 22:11:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:106:\"WPTavern: Plugin Team Draws a Line: Plugins Must Not Change WordPress’ Default Automatic Update Settings\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=111034\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:249:\"https://wptavern.com/plugin-team-draws-a-line-plugins-must-not-change-wordpress-default-automatic-update-settings?utm_source=rss&utm_medium=rss&utm_campaign=plugin-team-draws-a-line-plugins-must-not-change-wordpress-default-automatic-update-settings\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3110:\"<p>WordPress&rsquo; plugin team has published a <a href=\"https://make.wordpress.org/plugins/2021/01/26/reminder-plugins-must-not-interfere-with-updates/\">statement</a> regarding plugins making changes to users&rsquo; update services: </p>



<blockquote class=\"wp-block-quote\"><p>Unless your&nbsp;plugin&nbsp;has the&nbsp;<em>purpose</em>&nbsp;of managing updates, you&nbsp;<strong>must not</strong>&nbsp;change the&nbsp;defaults&nbsp;of WordPress&rsquo; update settings.</p><p>You&nbsp;<em>may</em>&nbsp;offer a feature to auto-update, but it has to honor the&nbsp;core&nbsp;settings. This means if someone has set their site to &ldquo;Never update any of my plugins or themes&rdquo; you are not to change those for them unless they opt-in and request it.</p></blockquote>



<p>The statement was prompted by plugins overstepping this boundary, which, up until recently, has simply been understood but not explicitly forbidden. Mika Epstein said the practice &ldquo;destroys the faith users have in you to not break their sites.&rdquo; It also reflects poorly on WordPress as a whole when plugin authors abuse core features to serve their own interests.</p>



<p>&ldquo;Sadly, this happened recently to a well used plugin, and the fallout has been pretty bad,&rdquo; Epstein said. </p>



<p>She did not identify the plugin in question, but one particular incident that happened last month bears a strong likeness to this description. On December 21, 2020, the <a href=\"https://wptavern.com/all-in-one-seo-plugin-turns-on-automatic-updates-without-notifying-users-removes-functionality-in-latest-release\">All in One SEO plugin turned on automatic updates without notifying its users</a>, aside from a short, ambiguous note in the changelog.</p>



<div class=\"wp-block-image\"><img /></div>



<p>All in One SEO was active on more than 2 million WordPress sites when it rolled out this update. Many users were frustrated to discover that their sites had been updated without permission, despite having auto updates turned off for the plugin. The plugin&rsquo;s developers removed the auto updates wrapper&nbsp;functionality from the plugin earlier this month, in favor of letting WordPress handle updates.</p>



<p>After this incident, those who were affected were left with questions. Should WordPress allow this practice? Should plugin developers be required to place a notice in the dashboard if they are going to flip automatic updates on? While many users are willing to trust WordPress core to do automatic updates in a safe way, some are not willing to extend that trust to plugin developers, whose quality of updates vary widely. The plugin team offering guidance and communication on this matter was absolutely necessary to deter aggressive plugin developers from destroying what is still a fragile trust in automatic updates.</p>



<p>&ldquo;At this time, we have no plans to spell this out in a guideline,&rdquo; Epstein said. &ldquo;We do currently, regularly flag plugins that go outside their dictated (self defined) boundaries, and this is not a change. Please, respect your users.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 27 Jan 2021 20:43:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"WPTavern: Jetpack Launches Customer Research Project to Improve the Plugin and Reduce User Frustration\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110995\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:249:\"https://wptavern.com/jetpack-launches-customer-research-project-to-improve-the-plugin-and-reduce-user-frustration?utm_source=rss&utm_medium=rss&utm_campaign=jetpack-launches-customer-research-project-to-improve-the-plugin-and-reduce-user-frustration\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6244:\"<p>Jetpack&rsquo;s Design and Research Team is <a href=\"https://automattic.design/2021/01/26/were-all-ears/\">launching a new customer research panel</a> as part of an ongoing effort to collect feedback in advance of launching new features. They are allocating one day every month to talk with users:</p>



<blockquote class=\"wp-block-quote\"><p>It&rsquo;s a small step toward an important goal of better understanding what our users need, seeing and hearing first hand where they are frustrated, and learning how Jetpack can work better for them.</p><p>The relationship benefits both sides. Our customers enjoy a sneak preview of features coming down the roadmap, and are empowered to help shape the product&rsquo;s future. And our design slash research team sees first hand, how our products perform with real folks using them.</p></blockquote>



<p>Jetpack is recruiting customers for 45-minute long interviews on Zoom where they will preview some new designs and talk about proposed product improvements that are already in the works. In exchange, participants receive a $25 Amazon gift card.  </p>



<p>This outreach effort may help in easing the periodic friction between Automattic and the larger WordPress community, which tends to emerge like pop-up storms on social media and quickly dissipate, but not without taxing onlookers&rsquo; good will. Although Jetpack is active on more than 5 million sites, and is marketed as &ldquo;the most popular WordPress plugin for just about everything,&rdquo; its team occasionally seems out of touch with users.</p>



<p>One recent example of this happened when Matt Medeiros drew attention to the wording for the Jetpack Scan upsells that appear on the plugins page in the admin.  Specifically, people took issue with the claim that &ldquo;adding plugins can expose your site to security risks.&rdquo; While this is true, participants in the resulting heated discussion said it implies that Jetpack, the plugin that claims to do &ldquo;just about everything,&rdquo; is the only safe plugin. </p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Everyone: WordPress is amazing because you can use plugins! <br />Jetpack: Careful, it\'s a scary place that WordPress repo is.<br />Everyone: Didn\'t you come from .org? <br />Jetpack: Just buy my protection plan. <a href=\"https://t.co/5oqbsroqSA\">pic.twitter.com/5oqbsroqSA</a></p>&mdash; I podcast a lot&#127897; (@mattmedeiros) <a href=\"https://twitter.com/mattmedeiros/status/1352275821763948550?ref_src=twsrc%5Etfw\">January 21, 2021</a></blockquote>
</div>



<p>Some perceived it to be in violation of <a href=\"https://developer.wordpress.org/plugins/wordpress-org/detailed-plugin-guidelines/#11-plugins-should-not-hijack-the-admin-dashboard\">#11 of the Plugin Directory guidelines</a>, which states that plugins should not hijack the admin dashboard. The guideline also recommends avoiding advertising in the admin &ldquo;as it is generally ineffective,&rdquo; as well as frustrating for users who are not looking for additional complications while solving problems.</p>



<p>This particular case was resolved after Automattic product designer Jeff Golenski took the community feedback to his team. They <a href=\"https://twitter.com/jeffgolenski/status/1352417067849428993\">updated the advertisement</a> to be less fear-inspiring regarding the WordPress plugin ecosystem.</p>



<p>In another potent example of disconnect from the larger community, <a href=\"https://wptavern.com/jetpack-7-1-adds-feature-suggestions-to-plugin-search-results\">Jetpack 7.1 quietly introduced suggestions to the plugin search screen</a>. The update artificially inserted a search result into the first plugin card slot, identifying the corresponding Jetpack feature if one was available. Jetpack&rsquo;s module placement in the results subtly implied that other plugins were inferior options to its existing modules. Some of the modules advertised required an upgrade. The UI did not make it clear that the artificial search result was not coming from the plugin directory&rsquo;s algorithm. The Jetpack team claimed that it was designed to be a notice but its implementation was virtually indistinguishable from an advertisement.</p>



<p>In a later release, Jetpack <a href=\"https://wptavern.com/jetpack-7-2-1-removes-promotions-for-paid-upgrades-from-the-search-screen\">removed all feature suggestions that previously advertised upgrades</a>, characterizing the mistake as &ldquo;an error in judgment.&rdquo; This kind of misstep could have easily been avoided if the feature had been presented to actual users in advance. User researchers could have asked, &ldquo;How would you like it if we put some of our paid upgrades in the top search spot when you are searching for a new plugin?&rdquo; </p>



<p>Historically, the company has had a few rocky launches where it seemed some product teams did not consider the community&rsquo;s perception in their marketing approaches. Most recently, this was evident in the launch of WordPress.com&rsquo;s new&nbsp;<a href=\"https://wptavern.com/wordpress-com-rattles-freelancer-community-with-new-website-building-service-launch\">website building service</a>, which failed to include important information, i.e. that the intention was to refer business out. </p>



<p>The new customer research panel is a strategic move for Automattic and should allow the company to avoid a lot more frustration and miscommunication around Jetpack. It could also be valuable as a means of testing potential marketing angles, beyond just specific features the team is developing.</p>



<p>&ldquo;When you have a team continually connecting with their customers, you find that they start to become internal ambassadors for the users, helping to weave the user&rsquo;s voice into product and design conversations throughout the entire product design process.&rdquo; Automattic UX/Product Designer Yvonne Doll said in the announcment.</p>



<p>If you want to help the Jetpack team realize these goals and become ambassadors for their users, visit the plugin&rsquo;s <a href=\"https://jetpackresearch.blog/\">user research blog</a> and sign up to participate in upcoming interviews. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 27 Jan 2021 02:33:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"WPTavern: WP Buffs Finalizes First Acquisition, Purchases WP EZI\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110796\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:171:\"https://wptavern.com/wp-buffs-finalizes-first-acquisition-purchases-wp-ezi?utm_source=rss&utm_medium=rss&utm_campaign=wp-buffs-finalizes-first-acquisition-purchases-wp-ezi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6915:\"<img />



<p class=\"has-drop-cap\">Earlier today, WP Buffs <a href=\"https://wpbuffs.com/wp-ezi-acqusition/\">announced that it had acquired WP EZI</a>, a WordPress maintenance and support service. It was a five-figure acquisition for 64 active subscriptions and 343 total customers. Paul Tselekidis, the former owner of WP EZI, is <a href=\"https://wpezi.com/joining-wp-buffs/\">stepping away from the project</a>.</p>



<p>WP Buffs offers 24/7 WordPress website management. Its team works directly with website owners and startups. They also work with white-label partners in the WordPress space. Agencies, freelancers, and hosting companies resell the WP Buffs subscription services instead of hiring a global team of their own.</p>



<p>This is the first acquisition for the company and was done through their new <a href=\"https://wpbuffs.com/acquisitions/\">Business Acquisition Unit</a>.</p>



<p>For WP EZI users, nothing should change about how they use the service. &ldquo;The day-to-day of the folks at WP EZI (aside from Paul) will continue unchanged as they&rsquo;ve all decided to stay on board and are excited for this new chapter of the business,&rdquo; said Joe Howard, the Founder and CEO of WP Buffs. &ldquo;For the time being, they will continue to function as team members of WP EZI, although they&rsquo;ll, of course, be given a warm welcome as new members of the WP Buffs family.&rdquo;</p>



<p>At the moment, none of the pre-acquisition WP Buffs staff will move over to any WP EZI projects or vice versa. The two brands will remain separate.</p>



<p>&ldquo;Mostly, this is for current WP EZI subscription clients, as keeping them happy and unbothered is our top priority,&rdquo; said Howard.</p>



<p>One change coming to WP EZI is that it will no longer offer new care plan subscriptions. The goal is to send those leads to WP Buffs. WP EZI will continue serving current care plan customers and handle one-off projects.</p>



<p>&ldquo;The strength of WP Buffs is in our strong systems and scalable business model of selling and executing on subscription services,&rdquo; said Howard. &ldquo;That&rsquo;s why we&rsquo;ll continue to accept new care plans there and send all one-time requests to WP EZI. They have experience with this business model, so we&rsquo;re going to keep that team doing the work they&rsquo;ve proved to be strong at.&rdquo;</p>



<p>Howard did not give much away in terms of long-term changes. He said that while they are mulling over some ideas, their priorities were a peaceful transition for WP EZI clients and learning from and helping the current team.</p>



<p>&ldquo;Most of the benefits for WP Buffs come from acquiring an already profitable business and client base,&rdquo; he said. &ldquo;Furthermore, the acquisition allows us to funnel care plan leads into WP Buffs and more one-time work into WP EZI. These silos will allow each team to be more efficient since they&rsquo;ll be able to focus on their areas of strength.&rdquo;</p>



<h2>On Acquisitions and Growth</h2>



<p class=\"has-drop-cap\">On the low end, the deal was likely at least mid to upper-five figures. We know that it was a five-figure acquisition. There were 64 active customers with an $87 per month subscription or more. This also assumes a consistent active subscription count for the last year or so. This is speculation but should provide some low ballpark numbers for others looking to sell a WordPress-related business.</p>



<p>While Howard did not provide an exact figure, his company provided far more information than is typical of business acquisitions in the WordPress ecosystem. Often, these deals are made only with an agreement that neither party share the sale price. The transparency from WP Buffs should come as a breath of fresh air to other small business owners. It can be overwhelming venturing into a first acquisition from either end.</p>



<p>One of his goals is to be transparent with how WP Buffs is run. His <a href=\"https://wpbuffs.com/2020-year-in-review/\">2020 year in review</a> post is lengthy, but he does not hold back on mistakes and successes. It provides a lot of insight that other business owners can learn from.</p>



<p>Howard has some experience scaling businesses beyond that $10,000 &ndash; $15,000 monthly recurring revenue (MRR) spot, which is where some small businesses begin to plateau. I asked him to share his experience with other business owners.</p>



<p>&ldquo;WP Buffs now does $100,000+ MRR,&rdquo; he said. &ldquo;That means we don&rsquo;t have the same issues as a care plan company at the scale of WP EZI &mdash; and if we do, we can pay to make those challenges go away.&rdquo;</p>



<p>With WP Buffs now in control of the WP EZI brand, they can dedicate funding where needed and use their leadership and management where needed. Because their team has been here before, it should provide the experience to push past any hurdles.</p>



<p>&ldquo;The reality here is just an economics of scale,&rdquo; said Howard. &ldquo;&lsquo;Bigger&rsquo; companies can simply flex a little more muscle to get rid of roadblocks. Plus, they have more financial flexibility to experiment and get things wrong to find that one thing that makes the difference when it comes to growth.&rdquo;</p>



<p>He wrapped up his advice by saying that businesses should focus on their subscription metrics:</p>



<ul><li>Develop 1-2 predictable, lead acquisition channels and grow those (increase MRR growth from new sales).</li><li>Get a ton of client feedback and make fast adjustments to keep them happy (lower churn).</li><li>From the client feedback, implement new features, offerings, value to current clients so they&rsquo;ll stay with you longer and tell others about you (increase expansion revenue and lifetime value).</li></ul>



<p>&ldquo;One basic piece of advice is it&rsquo;s never too early to start thinking about selling, even if it&rsquo;s not on your roadmap,&rdquo; said Howard. &ldquo;Whether you ever want to sell your business or not, the things that make the kind of business people want to purchase are the same things that simply make it a good business, so why not do them?&rdquo;</p>



<p>Howard and Tselekidis had an <a href=\"https://wpmrr.com/podcast/paul-kidis-wp-ezi/\">open and honest conversation</a> about the acquisition on the WPMRR podcast. Some of it is personal, but it provides a glimpse behind the curtain of a WordPress business sale.</p>



<p>Tselekidis talked about spreading himself too thin among his various projects in the podcast. After a self-analysis and reevaluating his interests, he decided to find a new home for WP EZI. This will allow him to focus on and pursue other goals. &ldquo;It&rsquo;s time to move on; like it&rsquo;s my time,&rdquo; he said of continuing work that he was not as passionate about. &ldquo;I don&rsquo;t want to do a disservice by my clients.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 26 Jan 2021 21:41:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Matt: Revue Joins Twitter\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"https://ma.tt/2021/01/revue-joins-twitter/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"https://ma.tt/2021/01/revue-joins-twitter/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:591:\"<p>Very excited to share the <a href=\"https://blog.twitter.com/en_us/topics/company/2021/making-twitter-a-better-home-for-writers.html\">news that Revue is joining Twitter</a>. I’m a huge fan of the idea of better newsletters and <a href=\"https://automattic.com\">Automattic</a> was the largest investor in <a href=\"https://www.getrevue.co/\">Revue</a>. I’m looking forward to seeing what the very talented team will do as part of the Twitter network. Also many thanks to <a href=\"https://kk.org\">Kevin Kelly</a> and <a href=\"https://om.co\">Om</a> for introducing me to Revue early on. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 26 Jan 2021 18:43:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"WPTavern: WordPress Roadmap Update: Full-Site Editing Targeted for 5.8 Release in June 2021\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110884\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:225:\"https://wptavern.com/wordpress-roadmap-update-full-site-editing-targeted-for-5-8-release-in-june-2021?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-roadmap-update-full-site-editing-targeted-for-5-8-release-in-june-2021\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3700:\"<p>WordPress core contributors are pushing forward on an ambitious plan to land full-site editing in core before the end of the year. Josepha Haden Chomphosy, the open source project&rsquo;s executive director, published an <a href=\"https://make.wordpress.org/updates/2021/01/21/big-picture-goals-2021/\">updated roadmap</a> for 2021 that aims to get an MVP of full-site editing (FSE) in the Gutenberg plugin by April, 2021. FSE v1 would then be on track for shipping with WordPress 5.8, which is anticipated in June, 2021.</p>



<table><tbody><tr><th>5.7&nbsp;</th><td>April 2021 &ndash; <strong>MVP for FSE in Gutenberg plugin</strong></td></tr><tr><th>5.8</th><td>June 2021 &ndash; <strong>&nbsp;v1 in Core</strong></td></tr></tbody></table>



<p>Chomphosy defined the scope of FSE as &ldquo;the ability to edit all elements of a site using Gutenberg blocks&rdquo; and said it will include &ldquo;all in-progress features designed to help existing users transition to Gutenberg as well.&rdquo;</p>



<p>When asked what would be considered an MVP of full-site editing, Chomphosy pointed to <a href=\"https://github.com/WordPress/gutenberg/issues/24551\">a GitHub issue</a> that contributors are using for tracking all the milestones associated with the project. Part of the infrastructure and UI is marked as complete, as well as browsing between pages, templates, and template parts. Styling, theme blocks, the query block, and the navigation block still need more work. More progress may have been made but the tracking issue has not been updated since December 19, 2020. </p>



<p>Dipping into the <a href=\"https://make.wordpress.org/core/2021/01/22/editor-chat-summary-20th-january-2021/\">notes</a> from the recent editor meetings shows a steady stream of FSE improvements, which presumably will coalesce into an MVP in approximately five weeks. Chomphosy&rsquo;s announcement avoided explicit promises regarding what features are expected at that time.  </p>



<p>Related projects like the widgets and navigation block editors have new dedicated Slack channels for those interested in following and contributing: </p>



<ul><li><a rel=\"noreferrer noopener\" href=\"https://wordpress.slack.com/archives/C01D71823PB\" target=\"_blank\">#feature-widgets-block-editor</a></li><li><a rel=\"noreferrer noopener\" href=\"https://wordpress.slack.com/archives/C01KDAZJMQ9\" target=\"_blank\">#feature-navigation-block-editor</a></li></ul>



<p>If you have questions about where FSE is headed, an upcoming Gutenberg Times Live Q&amp;A episode titled &ldquo;<em>Updates on WordPress Site-Editor (FSE) and Themes</em>&rdquo; will feature a panel of people who are actively contributing in these areas. It includes Carolina Nymark, author of <a href=\"https://fullsiteediting.com/\">a course on full site editing and block based themes</a>, Ari Stathopoulos, core contributor and author of the first block-based theme in the repository, and Anne McCarthy, who is managing the FSE outreach experiment. </p>



<p>The episode will air live on Friday, January 29th, 2021, at 11AM EST, hosted by Birgit Pauli-Haack, curator of the <a href=\"https://gutenbergtimes.com/\">Gutenberg Times</a>. <a href=\"https://us02web.zoom.us/webinar/register/9716061492351/WN_vtNXZ0zTTs2S0S98X0Y9og\">Registration</a> for the event is free. Pauli-Haack plans to cover all the latest updates on full-site editing, block-based themes, and global styles. The panel will also touch on the navigation and widget screens, as well as what features will most likely land in WordPress 5.7. Viewers can bring questions and participate via Zoom and YouTube live. The episode will be recorded and shared afterwards with a transcript and resources.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 26 Jan 2021 03:16:56 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"WPTavern: Jump-Start a Year’s Worth of Content via the Launch With Words Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110800\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:201:\"https://wptavern.com/jump-start-a-years-worth-of-content-via-the-launch-with-words-plugin?utm_source=rss&utm_medium=rss&utm_campaign=jump-start-a-years-worth-of-content-via-the-launch-with-words-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8435:\"<p class=\"has-drop-cap\">On Sunday, Bridget Willard announced her latest project, <a href=\"http://launchwithwords.com\">Launch With Words</a>. In collaboration with Ronald Huereca, who performed the development work, they built a plugin that helps clients jump-start routine, monthly blog posts. In the future, there will be premium &ldquo;content packs&rdquo; that include content for various industries.</p>



<p>The Launch With Words plugin is essentially a JSON importer for blog posts. The plugin itself is simple. However, the idea is what makes this plugin special.</p>



<p>&ldquo;The audience is small business owners,&rdquo; said Willard. &ldquo;So many of us in the WordPress ecosystem are overeducated. We are annoyed that clients don&rsquo;t know how to do X, Y, and Z. But that&rsquo;s not their job; it&rsquo;s ours.&rdquo;</p>



<p>Willard wrote starter content for both the Twenty Nineteen and Twenty Twenty default WordPress themes. She said it occurred to her that theme starter content is great, but why was no one tackling this for blog posts?</p>



<p>&ldquo;This plugin comes from something I&rsquo;ve been saying to friends for years, &lsquo;launch with words; get paid faster,\'&rdquo; she said. &ldquo;<em>Lorem ipsum</em> is such a pain. Seriously. As someone who partners with WordPress agencies and freelancers to write copy for website launches, placeholder text is my nemesis.&rdquo;</p>



<p>Willard <a href=\"https://bridgetwillard.com/\">runs her own business</a>, which offers social media management, copywriting, consulting, and business coaching. She is a marketing consultant who has been writing for the web since 2001.</p>



<p>&ldquo;I was a secretary by trade with a background in accounts receivables and collections,&rdquo; she said. &ldquo;After I earned my teaching credential, I spent a year teaching junior high and high school math before I realized I didn&rsquo;t like parents. But hey, that bachelor&rsquo;s degree isn&rsquo;t wasted. I decided to go back to office work and landed in accounting (hello, algebra). I excelled in accounts receivable and collections but was at the top of my salary range.&rdquo;</p>



<p>She left the construction industry in 2015 and began working for an advertising agency. During this time, she helped build the GiveWP brand. She also led the WordPress Marketing Team for two years.</p>



<h2>How the Plugin Works</h2>



<img />Importing content with the Launch With Words plugin.



<p class=\"has-drop-cap\">Launch With Words simply imports content. On its own, it does nothing else. Willard provides a downloadable JSON file via the Launch With Words website. This &ldquo;<a href=\"https://bridgetwillard.com/downloads/launch-with-words-starter-content-pack/\">starter pack</a>&rdquo; is available for free to everyone. It includes 12 draft blog posts to keep users blogging on their site for the next year.</p>



<p>While it is geared toward freelancers and agencies working with small business owners, anyone can use the plugin and starter pack. If you are having trouble pushing out content regularly, the monthly prompts could be the injection you need to get the creative juices flowing.</p>



<p>Each draft post includes a topic theme, topic type, and blog checklist. The topic theme is centered on usual events or holidays that match the month of the year. For example, the following is the theme for May:</p>



<blockquote class=\"wp-block-quote\"><p>Topic Theme: Summer is around the corner and, if your business is seasonal, you may have a bit of extra time or be swamped. It generally depends on your sales cycle.</p><p>This is a great time to go to your inspiration journal and look for a case study that can be written. Get the content published before people start going on vacations and forget about hiring a small business.</p></blockquote>



<p>Just pull up each month&rsquo;s draft post, follow the topic, and go from there.</p>



<img />Draft blog post for December.



<p>Willard says that the plugin builds off the services she offers. &ldquo;This plugin absolutely solves the repeated issues I encounter with people &mdash; namely, &lsquo;What do I write about?\'&rdquo;</p>



<p>She has not started using the Launch With Words plugin with her clients yet. In the past, she has used the <a href=\"https://bit.ly/BridgetWebQuestions\">Website Content Questionnaire</a>, a tool she built that others can copy to their Google Drive for free.</p>



<p>&ldquo;What makes web copy great is having a bit of the backstory about people,&rdquo; she said. &ldquo;What makes them different? Do they like hockey? Did they start working in fast food? Are they building sites for the healthcare industry?&rdquo;</p>



<h2>Premium Content Packs</h2>



<p class=\"has-drop-cap\">Willard will begin offering premium content packs soon. Each will come with 12 fully-written blog post drafts for each month of the year, catering to specific industries. She plans to launch these individual packs at $497.</p>



<p>&ldquo;I get asked how I come up with prices often,&rdquo; she said. &ldquo;Because I look at websites and products and SaaS services constantly, pricing is now intuitive to me. It&rsquo;s pretty easy for a developer or a small business to throw down $500 knowing it will give them content for a year. It&rsquo;s a crazy low price. I&rsquo;m not a fan of the word &lsquo;cheap.&rsquo; But this is buying in bulk. This is the Costco model.&rdquo;</p>



<p>The blog posts should range between 300 and 500 words, a service in which Willard would generally charge $200.</p>



<p>&ldquo;Anyone can tweak the copy to localize it or make it their own,&rdquo; she said. &ldquo;Before you ask, the only thing worse than duplicate content is no content. It&rsquo;s not novel to offer content; what&rsquo;s novel is to offer content that lives in a blog post. It&rsquo;s not an RSS feed from a syndication service that you can&rsquo;t edit. It&rsquo;s amazing how much franchises pay for boring content to distribute to their networks. Any business should have access to quality content that they can localize.&rdquo;</p>



<p>One has to wonder how Willard could pace herself and produce quality content for these premium packs. However, she is no stranger to the writing process. She has published several books, writing four in the past year.</p>



<p>&ldquo;I write to teach,&rdquo; she said. &ldquo;If you boil my essence down, I am a teacher. A few people have encouraged me to publish books. I have two Christian-based books out on Amazon that I did on Lulu.com, but it was so painful, I didn&rsquo;t bother.&rdquo;</p>



<p>It was not until she talked with Nathan Ingram, a business coach in the WordPress space, at WordCamp Seattle in 2019 that she decided to give things another go. He introduced her to Kindle Direct Publishing, a driving factor behind her more recent publishing success.</p>



<p>&ldquo;So I took a blog series idea, &lsquo;Dysfunctional Love Songs,&rsquo; and wrote and published that book in April as my COVID project. In October, &lsquo;Keys to Being Social,&rsquo; my life&rsquo;s work was published. &lsquo;The Definitive Guide to Twitter Marketing&rsquo; was written on a Sunday in January. My fourth book, &lsquo;How to Market Your WordPress Plugin&rsquo; is with my editor and will be published this year.&rdquo;</p>



<p>Willard said these writing projects have helped her stay focused on positive things during the Covid-era.</p>



<p>&ldquo;Otherwise, it&rsquo;s easy for things to turn dark &mdash; if we&rsquo;re all going to die, why pay off my credit cards? You know? I can&rsquo;t just sit around watching Netflix. I do, but I need an outlet.&rdquo;</p>



<p>She does not plan on going it alone for all of the premium content packs. She is already in talks with writers in other fields who would be better suited to the specific subject matter. However, Willard will lean on her construction-related expertise to build some of the packs.</p>



<p>&ldquo;The best advice writers give is that you should write what you know,&rdquo; she said. &ldquo;It&rsquo;s the first chapter in Anne Lamott&rsquo;s &lsquo;Bird by Bird.&rsquo; I&rsquo;ve been writing about construction for 20 years. It won&rsquo;t require very much research. I mean, if I can sit down on a Sunday and write 7,000 words on Twitter for that book, I&rsquo;m pretty sure I can write 12 blog posts fairly soon.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 25 Jan 2021 21:57:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"WPTavern: Ask the Bartender: How To Bulk Convert Classic WordPress Posts To Blocks?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110841\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:207:\"https://wptavern.com/ask-the-bartender-how-to-bulk-convert-classic-wordpress-posts-to-blocks?utm_source=rss&utm_medium=rss&utm_campaign=ask-the-bartender-how-to-bulk-convert-classic-wordpress-posts-to-blocks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5513:\"<blockquote class=\"wp-block-quote\"><p>I was wondering if you could help me. I want to convert all of my old posts (about 600) to Gutenberg blocks. Do you know an easy way to do that?</p><p>Philip</p></blockquote>



<p class=\"has-drop-cap\">I often get these short questions via private messages. I always try my best to help other WordPress users whenever I can. This was an easy solution in Philip&rsquo;s case. After a quick chat, he actually learned that he did not need to migrate his posts to the block system. I thought it would be best to open this topic to a wider audience. Maybe it would help someone else along the way.</p>



<p>There is currently an <a href=\"https://github.com/WordPress/gutenberg/issues/18645\">open ticket</a> on the Gutenberg repository for a bulk converter. It has sat dormant until a few days ago. The primary argument for including this feature in the plugin and eventually WordPress itself is that the lack of this option is an obstacle for newcomers to the block editor.</p>



<p>I disagree with the notion that it is any sort of obstacle for block-editor adoption. There does not seem to be a massive call for the feature in the WordPress support forums. Web searches do not pull up too many support queries for it. It seems to be a niche use case. Or, in some cases, there is a simple misunderstanding that end-users need to do any sort of conversion or migration at all.</p>



<p>However, the biggest reason it is a non-obstacle is that posts written in the classic editor are still basic HTML. Regardless of the editor, older content will output just fine on the front end, at least in most cases.</p>



<p>The first question anyone should ask before deciding on bulk converting their old posts to the newer block format is whether they should do it at all. The answer for the majority of users will simply be <em><strong>no</strong></em>. There are few reasons to do so.</p>



<p>Doing a mass conversion like this, especially with hundreds or more posts, is subject to broken sites. I have done enough single-post updates to know that the process does not always go smoothly. Sometimes, I need to touch up something here or do some manual changes there. On a large scale, there really is no way to know what got broken until you test every single post or page on the site. In some cases, everything is OK. In others, it is a nightmare.</p>



<p>If you are thinking of going down the bulk-conversion route, make a backup first. There is a good chance that you will need it. You should also test this on a staging site.</p>



<p>My recommendation for most users is to convert posts on an as-needed basis. I like to make the switch any time I edit an old post. The only reason I convert them is that I prefer working with the block editor over classic.</p>



<p>Posts written in the old editor will be in the Classic block. After selecting the block that houses the content, I hit the &ldquo;Convert to blocks&rdquo; button in the block toolbar. I do a quick check of anything that might need to be fixed before hitting the update button.</p>



<img />&ldquo;Convert to blocks&rdquo; button for the Classic block.



<p>In most cases, there is no reason to convert old posts to blocks except when you are actually editing those posts.</p>



<p>Despite claims that things will &ldquo;just work&rdquo; when switching to the block editor, that is not the day-to-day reality of all WordPress users. Some of the biggest reasons I have seen to bulk convert are around theme design issues. For example, the block system made some fundamental changes to image markup. If your theme handles left and right-aligned images added via the block editor but breaks down on your old posts, bulk converting may be an option. However, the first course of action should be checking in with your theme author about adding support for the classic markup.</p>



<p>There are likely numerous other edge cases. Bulk converting posts is an invasive operation that can only be reverted by restoring a pre-conversion backup. It should be a last resort.</p>



<p>If you are at the point where you know you need to convert all your old posts, there are a few options available.</p>



<p>The <a href=\"https://wordpress.org/plugins/bulk-block-converter/\">Bulk Block Converter</a> plugin is likely the most-used solution at the moment. Organic Themes released it a little over a year ago but has only updated it once. User reviews have been mixed. A few of the problems seemingly stem from WordPress &mdash; the plugin extends the core WordPress block converter used in single posts.</p>



<p>For those with clients who want to find a middle ground between bulk conversion and having the client manually convert their old posts, 10up&rsquo;s <a href=\"https://github.com/10up/convert-to-blocks\">Convert to Blocks</a> plugin might be the right solution. It converts posts on the fly, only making changes when a user opens the post-editing screen.</p>



<p>Fr&auml;nk Klein is also working on a PHP-based bulk converter plugin named <a href=\"https://bulkconverttoblocks.com/\">Bulk Convert to Blocks</a>. It is currently in the development stage and not ready for use on live sites. It offers a screen in the WordPress admin to perform the conversion and will continue working in the background if the user leaves the page. Because it runs via PHP, developers can extend it with custom actions and filters. It also provides a WP CLI command for those who prefer to work from the command line.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 Jan 2021 22:39:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"WPTavern: TasteWP Spins Up Free WordPress Testing Sites in Seconds\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110274\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:177:\"https://wptavern.com/tastewp-spins-up-free-wordpress-testing-sites-in-seconds?utm_source=rss&utm_medium=rss&utm_campaign=tastewp-spins-up-free-wordpress-testing-sites-in-seconds\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5318:\"<p><a href=\"https://tastewp.com/\">TasteWP</a> is a newcomer among online WordPress sandboxing solutions. The site allows users to spin up a new WordPress instance in a matter of seconds. Web-based sandboxes like these have been popular for a long time, since they are convenient to fire up and destroy when performing a quick test on a plugin or theme. It&rsquo;s easier than maintaining a local development environment, which many casual WordPress users have not taken the time to set up. </p>



<p>TasteWP&rsquo;s temporary testing sites are hosted for 48 hours for non-logged-in users and 7 days for those who are logged in. The one-click setup gives you a random site URL and login credentials.</p>



<img />



<p>The free sites are limited to 220MB per instance. A successful set-up notice is displayed in the dashboard with information on when the site will be automatically deleted. TasteWP limits non-logged-in users to creating 2 sites and the limit is 6 for logged-in users. They can be removed or added within the site manager. </p>



<div class=\"wp-block-image\"><img /></div>



<p>When creating a new site, the Advanced Options allows users to set up multisite, select a PHP version, WordPress version, and choose from a number of advanced configuration options and pre-installed extensions. The PHP version can also be changed later within the site manager.</p>



<div class=\"wp-block-image\"><img /></div>



<p>TasteWP is reminiscent of the now defunct <a href=\"https://wptavern.com/poopy-life-lets-you-create-free-unlimited-wordpress-test-installs\">poopy.life</a> service. In addition to the unsavory and unforgettable name, poopy.life was laden with obtrusive upgrade ads that floated across the screen periodically. TasteWP takes a different route for promotion and includes three of its plugins pre-installed on the default testing sites.</p>



<p>TasteWP is run by <a href=\"https://inisev.com/\">Inisev</a>, a 15-person company that has been developing&nbsp;WordPress&nbsp;plugins for four years.</p>



<p>&ldquo;Our key motivator for starting&nbsp;TasteWP&nbsp;was a) scratching our own itch (we needed a platform ourselves to try out new plugin versions on different&nbsp;WP/PHP version combinations) and b) promoting our products,&rdquo; Inisev co-founder Nicolas Ahmann said.</p>



<p>&ldquo;Having said that, if there is enough demand (and there seems to be), we&rsquo;ll also offer very affordable premium plans for non-expiring instances with bumped space soon.&rdquo;</p>



<p>Ahmann said the team is currently funding their projects from their own pockets as well as a few private investors.</p>



<p>&ldquo;We had some VCs knock at our door recently, and while we don&rsquo;t rule out taking them on board at some point in the future, we feel quite comfortable with our current approach where we grow organically (i.e. without too much ad spending),&rdquo; Ahmann said. &ldquo;I&rsquo;m sure, if we had taken on a lot of capital a few years ago, we would have spent a lot of marketing budget on products which weren&rsquo;t ready at the time. Instead, we were forced to make the products better. Limited budgets sharpen your mind immensely.&rdquo;</p>



<p>Ahmann said the company has several enhancements planned for TasteWP, but they don&rsquo;t want to make the product more complicated to use. </p>



<p>&ldquo;We developed a Linux application which copies exactly the same moves as user would do to create a website, except that we&rsquo;re omitting the front-end and graphics rendering parts which makes it much easier to process by the computer,&rdquo; he said. &ldquo;Also we inject anything that is needed into the database directly. That allows us to create those sites so fast without preparing them before (but still fully customized for each user).&rdquo;</p>



<p>The company is planning to enable users to call specific URLs, such as&nbsp;<a rel=\"noreferrer noopener\" href=\"https://tastewp.com/?themeslug=slug-of-theme\" target=\"_blank\">https://tastewp.com?themeslug=slug-of-theme</a>,&nbsp;which would spin up an instance with that theme or plugin already installed. This would allow theme and plugin creators to share the link with their potential users/customers so that they can play around themselves. </p>



<p>Localization is also a high priority for future TasteWP enhancements, since the company is based in Europe where many languages are spoken. </p>



<p>&ldquo;We always felt that it doesn&rsquo;t get the attention as it needs, considering that approximately<a href=\"https://w3techs.com/technologies/overview/content_language\"> 40% of websites are not in English,</a>&rdquo; Ahmann said. &ldquo;It&rsquo;s often just DIY people (not devs) who are trying to create their websites. We always encourage them to learn English (as it&rsquo;s the world&rsquo;s&nbsp;language). But imagine you grew up in Turkey, for example. Nobody around you speaks English &ndash; the teachers in schools only speak it in a broken way. In those cases it&rsquo;s key that people can take their first&nbsp;WordPress&nbsp;steps in their language, and what&rsquo;s easier to&nbsp;do&nbsp;so than spinning up an instance with one click on&nbsp;TasteWP&nbsp;which is in your language? Long story short: we&rsquo;ll keep translating it into (many) more languages.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 Jan 2021 20:47:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:119:\"WPTavern: Gutenberg 9.8 Brings Rounded Borders To the Group Block and Moves the Site Editor Canvas Into an Inline Frame\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110768\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:283:\"https://wptavern.com/gutenberg-9-8-brings-rounded-borders-to-the-group-block-and-moves-the-site-editor-canvas-into-an-inline-frame?utm_source=rss&utm_medium=rss&utm_campaign=gutenberg-9-8-brings-rounded-borders-to-the-group-block-and-moves-the-site-editor-canvas-into-an-inline-frame\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6699:\"<p class=\"has-drop-cap\">Gutenberg 9.8 <a href=\"https://make.wordpress.org/core/2021/01/20/whats-new-in-gutenberg-9-8-20-january/\">launched yesterday</a> with a few minor UI improvements. The development team added an initial implementation for border-radius support for the Group block that theme authors can opt into. They also moved the site editor into an iframe element to remove CSS conflicts from the global admin styles.</p>



<p>Those who have been testing Full Site Editing should be pleased that they will no longer need to deal with the seemingly never-ending creation of auto-drafts for templates and template parts. <em>Good riddance.</em> They would have inevitably caused user confusion in the long run. The change took around a <a href=\"https://github.com/WordPress/gutenberg/pull/27910\">month of discussion and work</a>, but it reduced a complex and fragile process into a more stable system for the long term.</p>



<p>While the previous plugin release saw barely more than a handful of bug fixes, version 9.8 jumped back to over two dozen. A Gutenberg update without at least that many just does not feel right.</p>



<h2>Minor UI Improvements</h2>



<p class=\"has-drop-cap\">The latest version of the plugin improves the UI when working with the Spacer block. When a user selected the block in the past, it appeared as a light gray rectangle. Now, it is <a href=\"https://github.com/WordPress/gutenberg/pull/28103\">semi-transparent. </a>This allows whatever is in the background, such as the Cover block with a background image, to show. This change should help users more easily make size adjustments in cases where viewing the background is necessary.</p>



<img />Semi-transparent Spacer block when selected.



<p>While I hope the Spacer block will eventually die a slow and agonizing death as it is replaced by more appropriate margin and padding block options, this change does help in the interim.</p>



<p>In a follow-up to the UI improvements in Gutenberg 9.7, work on block variations continues. Variations are when one block is used as the foundation to create multiple variations of the same block. The most common example is the Embed block, which has YouTube, Vimeo, and other variations. Before 9.7, these variations shared the same generic icon, name, and description in the block inspector and navigation instead of the variation-specific information.</p>



<p>Gutenberg 9.8 builds on the trend of using the variation&rsquo;s data where it makes sense. The block switcher (transform) button in the editor toolbar now <a href=\"https://github.com/WordPress/gutenberg/pull/27903\">displays the variation&rsquo;s icon</a>.</p>



<img />Variation icon in use in the block switcher.



<p>It is a small change, but it shows the development team&rsquo;s continued devotion to polishing the editor interface.</p>



<h2>Loading the Site Editor Canvas in an iframe</h2>



<p class=\"has-drop-cap\">Gutenberg 9.8 separates the canvas area of the <a href=\"https://github.com/WordPress/gutenberg/pull/25775\">site editor into an iframe</a>. This separation means that global admin styles do not bleed into or override styles within the editor itself. The good news is this is a first step toward doing the same in the post editor too.</p>



<p>This has been a change that I have been waiting for since the inception of the block editor. From a theme development and design standpoint, styling the editor to match the front end is ripe with issues. It has meant nesting CSS selectors when it should have been unnecessary. It has meant adding a few <code>!important</code> rules to overwrite what seems like oddities in the core CSS. While styling the block editor has improved by leaps and bounds in the past couple of years, it can still often be a pain.</p>



<p>WordPress core committer Ella van Durpe <a href=\"https://github.com/WordPress/gutenberg/issues/20797#issue-579381499\">listed the benefits</a> of moving the canvas into an iframe:</p>



<ul><li>There would be no admin CSS bleed at all. This is something we&rsquo;ve been struggling with since the beginning.</li><li>There would be no need to simulate media queries, which is arguably technically more difficult than using an iframe.</li><li>Relative units like <code>(r)em</code> and <code>vw</code>/<code>vh</code> just work.</li><li>For a full site, a theme stylesheet can be just dropped in the editor without any adjustment. I think this is important as it makes the life of theme authors much easier.</li><li>It&rsquo;s possible to have one selection per window, so one in the admin and one in the content. This is useful for e.g. the link UI where the selection in the content can be kept while the selection is also in an input element (for the URL). Maybe be useful in other cases.</li></ul>



<p>While I find it tough to believe that theme stylesheets would just work without a hitch &mdash; <em>does such a world exist?</em> &ndash;, they should work far better than in the past. There are likely items theme authors will need to contend with, but they should be minimal. Developers should keep a close eye on the future development of this.</p>



<h2>Border Radius Support for the Group Block</h2>



<p class=\"has-drop-cap\">As part of Gutenberg&rsquo;s experimental feature set, the Group block now supports a <a href=\"https://github.com/WordPress/gutenberg/pull/27665\">border radius option</a>. However, end-users will not automatically see it in the block inspector. This is an opt-in feature for themes at the moment. Presumably, it will be a part of the default set of options for several blocks in the future.</p>



<img />Setting the border-radius value for the Group block.



<p>For theme authors who want to add support, they will need to drop the following code snippet into their <code>experimental-theme.json</code> file and edit the <code>radius</code> value:</p>



<pre class=\"wp-block-code\"><code>\"core/group\" : {
        \"styles\" : {
                \"border\" : {
                        \"radius\" : \"50px\"
                }
        }
}</code></pre>



<p>This will allow theme authors to set the default border-radius for the group block. However, it will not hand over control to users. For that, themes will need to add the following snippet under the <code>settings</code> section of their <code>experimental-theme.json</code> file:</p>



<pre class=\"wp-block-code\"><code>\"border\" : {
        \"customRadius\" : true
}</code></pre>



<p>I tested this with a modified version of the <a href=\"https://wordpress.org/themes/tt1-blocks/\">TT1 Blocks </a>theme without issue. Mostly, I am looking forward to more styling options like this in future iterations of the plugin.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 21 Jan 2021 22:31:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"WordPress.org blog: People of WordPress: Thelma Mutete\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=9518\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wordpress.org/news/2021/01/people-of-wordpress-thelma-mutete/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8322:\"<p><em>WordPress is open source software, maintained by a global network of contributors. There are many examples of how WordPress has changed people’s lives for the better. In this monthly series, we share some of those lesser-known, amazing stories.</em></p>



<img src=\"https://i1.wp.com/wordpress.org/news/files/2021/01/Thelma-Mutete.jpg?resize=500%2C750&ssl=1\" alt=\"Thelma Mutete at a WordCamp\" class=\"wp-image-9564\" width=\"500\" height=\"750\" />



<p>From a young age Thelma was encouraged by her father to ‘work hard, and dream big’. In High School, she pursued a career in Computer Science. She said: “I did not know what I would be doing or how I would get there but I just knew that I was going to pursue a career in information technology.”</p>



<p>She wrote her first line of code at the age of 16 living in Zimbabwe, Africa. This was to mark the beginning of her enthusiasm for computer programming.</p>



<p>When she joined the school’s computer class, Thelma thought she would learn Excel and Word. Instead, the assignment was to write her first program in C. She said: “It was not easy, but it was very exciting. l remember writing up simple code for a Video Club – a check-in/out for VHS tapes and CDs. Thus began my fascination with computers.”</p>



<p>Seven years later, she went on to university to study for a Bachelors in Business Management and Information Technology. Her third year internship was at a local web design and hosting company. Though she had hoped her placement would be at a local bank or telecommunications company, the chance to discover website design turned out to be the best thing that could have happened.&nbsp;</p>



<p>In 2017, Thelma went on to work for a company designing websites using HTML, CSS, PHP, JavaScript and Joomla. She had heard about WordPress but had not used it. She recalls: “People have this misconception that WordPress is not for real developers and it is not secure and at that time I was one of those people.”</p>



<h2>Finding a local community</h2>



<p>From a discussion with a member of the local WordPress community, <a href=\"https://heropress.com/essays/wordpress-opened-whole-new-world/\">Thabo Tswana</a>, about a striking swag gift from a WordCamp, Thelma’s interest was sparked.&nbsp;</p>



<p>She started to find out more about WordPress and WooCommerce, and visited her local WordCamp Harare website. She was delighted to find that she could learn more about WordPress without needing any pre-existing knowledge, and wanted to be involved. So instead of just attending the camp, she volunteered too!&nbsp;</p>



<p>Her response to her first WordPress event mirrors the experience of many others in the community. She said: “I only started using WordPress because of the awesome people that l had met at that WordCamp. Everyone was so welcoming.”</p>



<p>A week later, with help from Thabo, she designed her first website using WordPress.</p>



<p>She soon became more involved with the community and Meetups. Thelma participated in the first-ever ‘Women Who WordPress’ Meetup in 2018, with lots of women getting involved from bloggers to developers.&nbsp;</p>



<p>She said: “We were free to talk and discuss a lot of things. We had more time to discuss the difference between WordPress.com and WordPress.org, we shared views on how to handle discrimination at work, how to promote your website and a whole lot of other things.”</p>



<h2>Establishing roots in WordPress</h2>



<p>In 2018, WordCamp Harare had its first-ever female Lead Organizer <a href=\"https://tapiwanashe.com/\">Tapiwanashe Manhobo</a>. Thelma was part of the organising team that year and was assigned to handle Harare’s first Kids Camp to take place eight months later. You can read more about her experiences of organizing a <a href=\"https://thelmachido.wordpress.com/2019/11/21/wordpress-juniours-first-edition/\"><strong>Kids Camp</strong></a> on her blog.</p>



<p>She said: “After the first Kids Camp, we had several people in the local Zimbabwean WordPress community who were enthusiastic about encouraging young people to embrace ICT. In 2019, we had not planned to have a Kids Camp because of financial constraints but to our surprise, we had some anonymous donations and we managed to have a WordPress Community outreach to a youth centre, <a href=\"https://cttzim.org/\"><strong>Centre for Total Transformation</strong></a>, a week after our WordCamp. It is a non-formal school that caters for underprivileged and vulnerable children. The group were able to share practical skills about using WordPress, computer hardware and software.</p>



<p>Thelma shares that she became hooked on WordPress because of its community. “I enjoy attending WordCamps, meeting new people and just learning new stuff. I have a huge list of WordCamps I would like to attend. Last year I managed to cross WordCamp Johannesburg off my list. When everything is back to normal my plan to travel to WordCamps will proceed (fingers crossed).”</p>



<h2>Reaping the fruits of ongoing learning</h2>



<p>Thelma is committed to ongoing development training. She said: “Even though I can still cook up code in C and Java, for now, I have also included WordPress PHP functions to the mix. It was not easy to get to this point, daring myself got me to this slightly better stage. I try to do my best where I can and I am happy to say it has paid off so far.”</p>



<p>Thelma has continued her journey working in design and digital marketing last year with Trust Nhokovenzo who works in digital marketing and is active in&nbsp; the WordPress Community. He came across her name as a developer from talking with others involved in WordPress. She went to work with his team at a marketing agency.</p>



<p>Her interest in the development of WordPress continued and she joined the <a href=\"https://wordpress.org/news/2020/12/simone/\">5.6 Release Squad</a> in the mid 2020.&nbsp;At the end of 2020, she moved to become a Happiness Engineer working with WordPress.com. Thelma’s fascination with the platform and the community continues to grow and her contributor story is ongoing.</p>



<p>Find out more about the <a href=\"https://www.meetup.com/Harare-WordPress-Meetup\">Harare WordPress community</a> in Zimbabwe.</p>



<h2>Contributors</h2>



<p>Thanks to Nalini Thakor (<a href=\"https://profiles.wordpress.org/nalininonstopnewsuk/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>nalininonstopnewsuk</a>) and Surendra Thakor (<a href=\"https://profiles.wordpress.org/sthakor/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>sthakor</a>), Yvette Sonneveld (<a href=\"https://profiles.wordpress.org/yvettesonneveld/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>yvettesonneveld</a>), Abha Thakor (<a href=\"https://profiles.wordpress.org/webcommsat/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>webcommsat</a>), Larissa Murillo (<a href=\"https://profiles.wordpress.org/lmurillom/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>lmurillom</a>), Meher Bala (<a href=\"https://profiles.wordpress.org/meher/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>meher</a>), Josepha Haden (<a href=\"https://profiles.wordpress.org/chanthaboune/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>chanthaboune</a>), and Chloé Bringmann (<a href=\"https://profiles.wordpress.org/cbringmann/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>cbringmann</a>). Thank you to Thelma Mutete (<a href=\"https://profiles.wordpress.org/thelmachido/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>thelmachido</a>) for sharing her #ContributorStory.</p>



<img src=\"https://lh4.googleusercontent.com/s24EVZGKbxVeafljPU1ubF1DjIwn98E3-wGx1LD2CWYk7zYQppFhXNpb0aUhGe01TStMdTwXrcYaxBZQHRgZJ10lvW2hsg61Ce37_pBGJuTRQlJ6r9iUxlJtvuDuwLhIvPo1MVEb\" alt=\"HeroPress logo\" />



<p><em>This post is based on </em><a href=\"https://heropress.com/essays/hello-world-discovering-the-world-through-wordpress/\"><em>an article originally published on HeroPress.com</em></a><em>, a community initiative created by </em><a href=\"https://profiles.wordpress.org/topher1kenobe/\"><em>Topher DeRosia</em></a><em>. HeroPress highlights people in the WordPress community</em>.</p>



<p>#ContributorStory #HeroPress</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 21 Jan 2021 16:40:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"webcommsat AbhaNonStopNewsUK\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"WPTavern: Gutenberg Contributors Consider Implementing a Bot to Close Stale Issues\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110562\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:209:\"https://wptavern.com/gutenberg-contributors-consider-implementing-a-bot-to-close-stale-issues?utm_source=rss&utm_medium=rss&utm_campaign=gutenberg-contributors-consider-implementing-a-bot-to-close-stale-issues\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5386:\"<p>Gutenberg project contributors are considering <a href=\"https://make.wordpress.org/core/2021/01/14/stale-issues-in-gutenberg-repository/\">implementing a stale bot</a> to tame the repository&rsquo;s overgrown <a href=\"https://github.com/WordPress/gutenberg/issues\">issues</a> queue, which currently has 2,733 open issues. Stale bots are usually employed to automatically close &ldquo;stale&rdquo; issues and PRs based on a predefined set of parameters for inactivity. </p>



<p>&ldquo;The current recommendation is to set our policy to a 180-day of no activity, so if no comments or commits are on an issue or PR in 180 days, then the bot will post a comment to the issue alerting the user it will be closed in 7-days due to inactivity,&rdquo; Marcus Kazmierczak proposed.</p>



<p>One important concern is getting the tone right for the automatically-generated message. When you&rsquo;re employing bots on a widely used open source project, they had better be friendly. A chilly, indifferent bot can unwittingly turn away potential contributors with the wrong kind of messaging. Kazmierczak proposed the following message:</p>



<blockquote class=\"wp-block-quote\"><p>This is an auto-generated message to let you know that this issue has gone 180 days without any activity and meets the project&rsquo;s definition of stale. This will be auto-closed if there is no new activity over the next 7 days. If the issue is still relevant and active, you can simply comment with a &ldquo;bump&rdquo; to keep it open, or add the &ldquo;[Status] Not Stale&rdquo; label. Thanks for keeping our repository healthy!</p></blockquote>



<p>Participants in the discussion on the proposal are divided on the best approach. Daniel Llewellyn, one of the most vocal opponents to using a stale bot, contends that an automatically closing issues sends the wrong message. </p>



<p>&ldquo;If we care about users and that they trust that we will fix their problem then automatically closing their issue gives them the signal that we don&rsquo;t,&rdquo; Llewellyn said.</p>



<p>&ldquo;If you don&rsquo;t want to fix a problem then it is better for a human to explain why the problem won&rsquo;t be fixed and personally close the issue. Automating this on the assumption that because nobody has commented in a while means it isn&rsquo;t important is bad!&rdquo;</p>



<p>Joy Reynolds agreed with this assessment, noting that closing issues through any means can be discouraging.</p>



<p>&ldquo;I&rsquo;ve had issues closed by humans for being stale, also, and it isn&rsquo;t any better,&rdquo; Reynolds said. &ldquo;I&rsquo;ve had issues closed because someone created a new issue on the same thing. This loses all the history and the watchers.</p>



<p>&ldquo;I&rsquo;ve also had an issue closed at Launchpad for being stale (and their system used only two weeks as a time frame). That served no purpose at all. It only makes people go away, frustrated.&rdquo;</p>



<p>Kazmierczak reiterated in the comments that the bot can be configured to skip issues labeled as bugs and that issues and PRs can be bumped to reset the 6-month clock.</p>



<p>&ldquo;The overall goal of the proposal is to improve feedback and responses to issues by ensuring what&rsquo;s there is relevant,&rdquo; Kazmierczak said.</p>



<p>Auto-closing issues is the most controversial part of the plan. The general consensus in the comments leans towards using the bot for labeling and triaging in order to manually close the issue later.</p>



<p>&ldquo;My preference would be for a bot to alert humans in a&nbsp;slack&nbsp;channel when a&nbsp;ticket&nbsp;is declared stale and become progressively more insistent until a human responds,&rdquo; Peter Wilson said. </p>



<p>Milana Cap suggested using a bot to nudge the ticket author as a compromise between &ldquo;being friendly and thoughtful to contributors while keeping maintainers sane.&rdquo;</p>



<p>Whatever approach contributors land on, excluding tickets marked as bugs is going to be critical for making the stale bot productive. Otherwise, it becomes just a fancy way of kicking the can down the road, delaying the inevitable. </p>



<p>In a recent post titled &ldquo;<a href=\"https://blog.benwinding.com/github-stale-bots/\">Github Stale Bots: A False Economy</a>,&rdquo; software developer Ben Winding wrote about why stale bots don&rsquo;t deliver what maintainers are aiming to achieve. Based on his experience with the <a href=\"https://github.com/angular/angular/issues\">Angular</a> repository&rsquo;s bot, Winding summarized the stale bot&rsquo;s effect on the issues queue: </p>



<ol><li>Reduce the metric of&nbsp;<em>Open Issues</em>&nbsp;in github</li><li>Made duplicate issues far more likely</li><li>Increased friction of users reporting that the issue still exists</li><li>Ultimately decreased the quality of the software, as the issues don&rsquo;t accurately reflect reality</li></ol>



<p>If the Gutenberg repository&rsquo;s stale bot can be configured not to close bugs and used to maximize human involvement, it will be less likely to deter people from reporting issues. Feedback on the <a href=\"https://make.wordpress.org/core/2021/01/14/stale-issues-in-gutenberg-repository/\">proposal</a> is open until January 29, 2021. Kazmierczak is seeking input on the bot&rsquo;s implementation, specifically its time threshold and messaging.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 21 Jan 2021 16:03:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Matt: New WhiteHouse.gov\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=53526\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"https://ma.tt/2021/01/new-whitehouse-gov/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2842:\"<p>After you&#8217;ve watched <a href=\"https://www.npr.org/sections/inauguration-day-live-updates/2021/01/20/958743170/poet-amanda-gorman-reads-the-hill-we-climb\">the amazing poem from Amanda Gorman</a>, check out the <a href=\"https://www.whitehouse.gov/\">new WhiteHouse.gov that re-launched today</a> using WordPress &amp; Gutenberg with a number of cool features including dark mode, text zoom, a totally responsive layout, and a Spanish version of the site. The site is clean, <a href=\"https://twitter.com/wesbos/status/1351957829461155849\">fast</a>, and accessible. It&#8217;s exciting and an honor that the online home for the Executive branch is on Open Source software, and I&#8217;m proud WordPress can carry the torch that <a href=\"https://dri.es/whitehouse-gov-using-drupal\">Drupal lit in 2009</a>.</p>



<p>Besides Gutenberg, poking around I noticed a HTTP header and HTML comment <a href=\"https://usds.gov/apply\">encouraging people to join USDS</a>, and this great #46 easter egg in the theme file:</p>



<img />



<p>Anyone notice any other plugins? I haven&#8217;t spoken to him directly but I&#8217;d be shocked if <a href=\"https://nacin.com/\">Nacin</a> wasn&#8217;t involved with this one. I&#8217;m also curious if any of the WP agencies were involved, it has touches of <a href=\"https://10up.com/\">10up</a> but I don&#8217;t see any mention of it on their site or <a href=\"https://twitter.com/10up\">Twitter</a>. <a href=\"https://twitter.com/HoeflerCo/status/1351984719634771970\">Hoefler&amp;Co  credits</a> <a href=\"https://wideeye.co/\">Wide Eye Creative with the design</a>.</p>



<p>I noticed a few people happy that some previous pages and files on the old site were returning 404 errors, like the <a href=\"https://www.nbcnews.com/news/nbcblk/how-trump-administration-s-1776-report-warps-history-racism-slavery-n1254926\">controversial 1776 report</a>, but on this I think the webmasters of the United States of America should demand better, since <a href=\"https://www.w3.org/Provider/Style/URI\">Cool URIs Don&#8217;t Change</a>. Previous websites are <a href=\"https://www.archives.gov/presidential-libraries/archived-websites\">all saved by the National Archives</a>, but there doesn&#8217;t appear to be any sort of norm for automatically redirecting links that went to any subdirectories or addresses under WhiteHouse.gov. </p>



<p>There are WP plugins that could help, like <a href=\"https://wordpress.org/plugins/redirection/\">Redirection</a>, but also perhaps the root domain itself could always redirect to a subdomain, like 46.whitehouse.gov, so we&#8217;d have a consistent domain and permalinks for everything, and then each new administration would get a new subdomain.</p>



<p><a href=\"https://wptavern.com/biden-white-house-sticks-with-wordpress-for-website-relaunch\">More coverage on WP Tavern</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 21 Jan 2021 01:15:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"WPTavern: Biden White House Sticks with WordPress for Website Relaunch\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110712\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:185:\"https://wptavern.com/biden-white-house-sticks-with-wordpress-for-website-relaunch?utm_source=rss&utm_medium=rss&utm_campaign=biden-white-house-sticks-with-wordpress-for-website-relaunch\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3896:\"<img />



<p>President Joe Biden took office today and unveiled a new <a href=\"https://www.whitehouse.gov/\">whitehouse.gov</a> that has been relaunched on WordPress. The previous administration switched from Drupal to WordPress in 2017, and technologists working with the Biden administration decided to stick with the same CMS. </p>



<p>In keeping with the multilingual and accessibility features implemented on <a href=\"https://wptavern.com/biden-harris-transition-website-launches-on-wordpress\">the Biden-Harris transition team website</a>, whitehouse.gov launched with toggles for contrast and font size, along with a Spanish language switcher. The relaunched site also includes an <a href=\"https://www.whitehouse.gov/accessibility/\">accessibility statement</a> with a commitment from the administration to work towards conforming to the Web Content Accessibility Guidelines (WCAG) version 2.1, level AA criteria.</p>



<p>Much of the content and design from the transition website has been preserved. The transition site now forwards to whitehouse.gov, while links to the previous administration&rsquo;s pages land on a 404 page with a link to <a href=\"https://www.archives.gov/presidential-libraries/archived-websites\">archived presidential websites</a>.</p>



<p>Savvy observers might notice that the typography has been updated from the transition site, flipping the Mercury and Decimal typefaces. Hoefler&amp;Co, the typeface design firm that <a href=\"https://www.typography.com/blog/biden-fonts\">created these typefaces</a> for Biden&rsquo;s 2020 campaign, <a href=\"https://twitter.com/HoeflerCo/status/1351984719634771970\">tweeted</a> about how &ldquo;the serif Mercury felt more like the voice of the institution.&rdquo;  The sans-serif Decimal functions more in a supporting role on the site.</p>



<p>Web professionals kicked the tires a bit and noticed the site is putting up fairly decent Lighthouse scores.  </p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\"><a href=\"https://t.co/hoaioTVqE3\">https://t.co/hoaioTVqE3</a> scoring super well on lighthouse, has dark mode and font size selector<br /><br />h8ers gonna be mad that it\'s wordpress and jQuery tho <a href=\"https://t.co/tyMNjdmnTH\">pic.twitter.com/tyMNjdmnTH</a></p>&mdash; Wes Bos (@wesbos) <a href=\"https://twitter.com/wesbos/status/1351957829461155849?ref_src=twsrc%5Etfw\">January 20, 2021</a></blockquote>
</div>



<p>Under the hood, code snoopers noticed an advertisement for the <a href=\"https://www.usds.gov/\">U.S. Digital Service</a> (USDS), the group of technologists who maintain many of the federal government&rsquo;s public-facing digital services.</p>



<div class=\"wp-block-image\"><img /></div>



<p>In addition to the message from USDS, the site&rsquo;s source code includes a link to the US government&rsquo;s analytics program at <a rel=\"noreferrer noopener\" href=\"https://analytics.usa.gov/\" target=\"_blank\">analytics.usa.gov</a>. Tim Lowden, who manages the federal government&rsquo;s aggregated web analytics initiative, <a href=\"https://twitter.com/tdlowden/status/1351939004342685697\">said</a> this data has been made available for the first time since late 2017.</p>



<div class=\"wp-block-image\"><img /></div>



<p>The analytics service records more than 2.5 billion pageviews across federal government websites each month. The data is available to the public, but it&nbsp;<a href=\"https://www.digitalgov.gov/services/dap/common-questions-about-dap-faq/#part-4\">does not track individuals</a>, and&nbsp;<a href=\"https://support.google.com/analytics/answer/2763052?hl=en\">anonymizes the IP addresses</a>&nbsp;of visitors. It shows information for visitors&rsquo; devices, browsers, operating systems, and location broken down into cities and countries. Many of those visiting the site today are from countries other than the U.S. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 21 Jan 2021 00:20:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"Gary: WordPress Importers: Free (as in Speech)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"https://pento.net/?p=5478\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://pento.net/2021/01/21/wordpress-importers-free-as-in-speech/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8227:\"<p>Back at<a href=\"https://pento.net/2021/01/18/wordpress-importers-stating-the-problem/\"> the start of this series</a>, I listed four problems within the scope of the WordPress Importers that we needed to address. Three of them are largely technical problems, which I covered in previous posts. In wrapping up this series, I want to focus exclusively on the fourth problem, which has a philosophical side as well as a technical one — but that does not mean we cannot tackle it!</p>



<div class=\"wp-block-group alignwide is-style-twentytwentyone-border\"><div class=\"wp-block-group__inner-container\">
<p class=\"has-text-align-center\">Problem Number 4</p>



<p class=\"alignwide has-extra-large-font-size\"><strong>Some services work against their customers, and actively prevent site owners from controlling their own content.</strong></p>
</div></div>



<p>Some services are merely inconvenient: they provide exports, but it often involves downloading a bunch of different files. Your CMS content is in one export, your store products are in another, your orders are in another, and your mailing list is in yet another. It&#8217;s not ideal, but they at least let you get a copy of your data.</p>



<p>However, there&#8217;s another class of services that actively work against their customers. It&#8217;s these services I want to focus on: the services that don&#8217;t provide any ability to export your content — effectively locking people in to using their platform. We could offer these folks an escape! The aim isn’t to necessarily make them use WordPress, it’s to give them a way out, if they want it. Whether they choose to use WordPress or not after that is immaterial (though I certainly hope they would, of course). The important part is freedom of choice.</p>



<p>It&#8217;s worth acknowledging that this is a different approach to how WordPress has historically operated in relation to other CMSes. We provide <em>importers</em> for many CMSes, but we previously haven&#8217;t written <em>exporters</em>. However, I don&#8217;t think this is a particularly large step: for CMSes that already provide exports, we&#8217;d continue to use those export files. This is focussed on the few services that try to lock their customers in.</p>



<h2>Why Should WordPress Take This On?</h2>



<p>There are several aspects to <em>why</em> we should focus on this.</p>



<p>First of all, it&#8217;s the <a href=\"https://wordpress.org/about/\">the WordPress mission</a>. Underpinning every part of WordPress is the simplest of statements: </p>



<p class=\"has-text-align-center\"><strong>Democratise Publishing</strong></p>



<p class=\"has-text-align-center\"><em>The freedom to build. The freedom to change. The freedom to share.</em></p>



<p>These freedoms are the pillars of a Free and Open Web, but they’re not invulnerable: at times, they need to be defended, and that needs people with the time and resources to offer a defence.</p>



<p>Which brings me to my second point: WordPress has the people who can offer that defence! The WordPress project has so many individuals working on it, from such a wide variety of backgrounds, we&#8217;re able to take on a vast array of projects that a smaller CMS just wouldn&#8217;t have the bandwidth for. That&#8217;s not to say that we can do <em>everything</em>, but when there&#8217;s a need to defend the entire ecosystem, we&#8217;re able to devote people to the cause.</p>



<p>Finally, it’s important to remember that WordPress doesn’t exist in a vacuum, we’re part of a broad ecosystem which can only exist through the web remaining open and free. By encouraging all CMSes to provide proper exports, and implementing them for those that don’t, we help keep our ecosystem healthy.</p>



<p>We have the ability to take on these challenges, but we have a responsibility that goes alongside. We can&#8217;t do it solely to benefit WordPress, we need to make that benefit available to the entire ecosystem. This is why it&#8217;s important to<a href=\"https://pento.net/2021/01/20/wordpress-importers-defining-a-schema/\"> define a WordPress export schema</a>, so that any CMS can make use of the export we produce, not just WordPress. If you’ll excuse the imagery for a moment, we can be the knight in shining armour that frees people — then gives them the choice of what they do with that freedom, without obligation.</p>



<h2>How Can We Do It?</h2>



<p>Moving on to the technical side of this problem, I can give you some good news: the answer is definitely <em>not</em> screen scraping. <img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/1f604.png\" alt=\"😄\" class=\"wp-smiley\" /> Scraping a site is fragile, impossible to transform into the full content, and provides an incomplete export of the site: anything that&#8217;s only available in the site dashboard can&#8217;t be obtained through scraping.</p>



<p>I&#8217;ve recently been experimenting with an alternative approach to solving this problem. Rather than trying to create something resembling a traditional exporter, it turns out that modern CMSes provide the tools we need, in the form of REST APIs. All we need to do is call the appropriate APIs, and collate the results. The fun part is that we can authenticate with these APIs as the site owner, by calling them from a browser extension! So, that’s what I’ve been experimenting with, and it’s showing a lot of promise.</p>



<p>If you&#8217;re interested in playing around with it, <a href=\"https://github.com/pento/free-as-in-speech\">the experimental code is living in this repository</a>. It&#8217;s a simple proof of concept, capable of exporting the text content of a blog on a Wix site, showing that we can make a smooth, comprehensive, easy-to-use exporter for any Wix site owner.</p>



<img width=\"904\" height=\"446\" src=\"https://pento.net/wp-content/uploads/2021/01/Screen-Shot-2021-01-20-at-5.26.38-pm.png\" alt=\"Screenshot of the \" />



<p>Clicking the export button starts a background script, which calls Wix&#8217;s REST APIs <em>as the site owner</em>, to get the original copy of the content. It then packages it up, and presents it as a WXR file to download.</p>



<img width=\"972\" height=\"948\" src=\"https://pento.net/wp-content/uploads/2021/01/Screen-Shot-2021-01-20-at-5.27.38-pm.png\" alt=\"Screenshot of a Firefox download dialog, showing a Wix site packaged up as a WXR file.\" class=\"wp-image-5528\" />



<p>I&#8217;m really excited about how promising this experiment is. It can ultimately provide a full export of any Wix site, and we can add support for other CMS services that choose to artificially lock their customers in.</p>



<h2>Where Can I Help?</h2>



<p>If you’re a designer or developer who’s excited about working on something new, head on over to the repository and <a href=\"https://github.com/pento/free-as-in-speech/issues\">check out the open issues</a>: if there’s something that isn’t already covered, feel free to open a new issue.</p>



<p>Since this is new ground for a WordPress project, both technically and philosophically, I&#8217;d love to hear more points of view. It’s being discussed in <a href=\"https://make.wordpress.org/core/2021/01/19/dev-chat-agenda-for-january-20-2021-january-21-2021/#comment-40563\">the WordPress Core Dev Chat this week</a>, and you can also let me know what you think in the comments!</p>



<div class=\"wp-block-group is-style-twentytwentyone-border\"><div class=\"wp-block-group__inner-container\">
<p><em>This post is part of a series, talking about the WordPress Importers, their history, where they are now, and where they could go in the future.</em></p>



<ul><li><em><a href=\"https://pento.net/2021/01/18/wordpress-importers-stating-the-problem/\">Part 1: Stating the Problem</a></em></li><li><em><a href=\"https://pento.net/2021/01/19/wordpress-importers-getting-our-house-in-order/\">Part 2: Getting Our House in Order</a></em></li><li><em><a href=\"https://pento.net/2021/01/20/wordpress-importers-defining-a-schema/\">Part 3: Defining a Schema</a></em></li><li><a href=\"https://pento.net/2021/01/21/wordpress-importers-free-as-in-speech/\"><em>Part 4: Free (as in Speech)</em></a></li></ul>



<p></p>
</div></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 21 Jan 2021 00:14:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Gary\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"WPTavern: First Round of the FSE Outreach Program Concludes, Identifies Template-Editing Mode Problems\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110638\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:247:\"https://wptavern.com/first-round-of-the-fse-outreach-program-concludes-identifies-template-editing-mode-problems?utm_source=rss&utm_medium=rss&utm_campaign=first-round-of-the-fse-outreach-program-concludes-identifies-template-editing-mode-problems\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5309:\"<p class=\"has-drop-cap\">The Full Site Editing (FSE) <a href=\"https://wptavern.com/help-steer-the-future-of-wordpress-via-the-fse-outreach-program\">Outreach Program</a> has now concluded its <a href=\"https://make.wordpress.org/test/2021/01/15/fse-program-template-editing-testing-summary/\">first round of testing</a>. Its first focus area was centered on the template-editing mode introduced in <a href=\"https://make.wordpress.org/core/2020/12/23/whats-new-in-gutenberg-23-december/\">Gutenberg 9.6</a>. The volunteers involved with the project identified several pain points.</p>



<p>Gutenberg 9.6 added a new button that allows end-users, provided they are using a block-based theme, to switch between editing their post and the template that displays the post. As Josepha Haden <a href=\"https://wptavern.com/gutenberg-9-3-provides-indicator-of-where-full-site-editing-is-going-a-future-without-widgets-and-customizer-screens\">said last year</a>, the ultimate goal is to &ldquo;consolidate down to just one beautiful, intuitive interface.&rdquo; Essentially, this new feature merges content and design in a way we have not seen in core WordPress before. It is a step toward that lofty goal.</p>



<p>Traditionally, WordPress has always separated content from design. However, these two aspects of websites are continually merging together. There is a desire for this. The adoption of page builders over the last half-decade or so has made it abundantly clear.</p>



<p>The biggest issue with this new template mode is that users need a working knowledge of the WordPress template system to understand the ramifications of their edits. One of the primary questions of the focus area was whether it was clear that the user was making large-scale changes to all posts when switching to the template-editing mode.</p>



<p>&ldquo;I believe it was not clear enough how those changes could impact the site,&rdquo; <a href=\"https://make.wordpress.org/test/2020/12/23/fse-program-testing-call-1-template-editing/#comment-1307\">wrote H&eacute;ctor Prieto in response</a>. &ldquo;If you don&rsquo;t already know how templates, template parts, and global blocks like Site Title work, you might not understand how your editing will affect the rest of the site.&rdquo;</p>



<p>Switching modes does create a quick popup at the bottom left of the screen that reads:</p>



<blockquote class=\"wp-block-quote\"><p>Editing template. Changes made here affect all posts and pages that use the template.</p></blockquote>



<p>It is easy to miss before it fades away. There is a ticket to <a href=\"https://github.com/WordPress/gutenberg/issues/28175\">stick this message</a> on the screen and allow the user to dismiss it. There is also another ticket for clarifying when a user is <a href=\"https://github.com/WordPress/gutenberg/issues/27849\">editing a template vs. content</a>.</p>



<img />Entering template-editing mode from the post editor.



<p>Gutenberg&rsquo;s current method is different than what you might see in a typical page builder. When switching to template-editing mode, the user is no longer editing that single post&rsquo;s front-end output. Instead, they are making global edits. A page builder would generally save any customizations to that page alone. If this remains the same, it could be a hurdle for the average user to clear.</p>



<p>A template creation feature needs to be a part of this new mode. Users should be able to fork or clone their existing single post template and save it as a new template specific to that post. Or, maybe hand them a way to save it as a reusable template (i.e., &ldquo;page&rdquo; template). Paal Joachim Romdahl <a href=\"https://make.wordpress.org/test/2020/12/23/fse-program-testing-call-1-template-editing/#comment-1303\">shared a similar thought</a>, likening it to the &ldquo;Save As&hellip;&rdquo; feature commonly found in computer programs.</p>



<p>I do question whether users should be able to edit global templates while editing a single post. The two are only related insofar as the template displays the post content on the front end. WordPress should explore any type of design work from the post-editing screen as, first and foremost, specific to that post.</p>



<p>The volunteers also identified other issues. Applying changes to the template and saving drops the user back into the post editor. The &ldquo;cancel&rdquo; button is tough to find &mdash; it is in a different location than where the user clicked to go into template-editing mode.</p>



<p>Switching between post and template editing feels like an FSE 2.0 type of thing. The development team has enough issues on its plate with the normal site editor. It is a far cry from being a viable, production-ready product. The team&rsquo;s focus should be on working the kinks out of that system before merging it with the post editor. Crawl before you walk. Walk before you run.</p>



<p>However, I am willing to be pleasantly surprised. In the long run, it will probably be a good thing that we are getting an early look at what these two different pieces of WordPress will look like working in conjunction.</p>



<p>This is also why participation in the FSE Outreach Program is vital. The community needs this more formal type of process to identify areas that need improvement.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 20 Jan 2021 23:17:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"HeroPress: Changing Careers Into WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=3454\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:136:\"https://heropress.com/essays/changing-careers-into-wordpress/#utm_source=rss&utm_medium=rss&utm_campaign=changing-careers-into-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6844:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2022/01/012021-min.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: With WordPress skills, you have more concrete skills to offer.\" /><p>If you’re looking to change careers into technology, WordPress is a great way to do it.</p>
<p>In 2013, I was in a career counselor’s office. Just realizing that I needed to change careers out of music, almost the only thing I had known for the last 20 years:</p>
<a href=\"https://s20094.pcdn.co/wp-content/uploads/2022/01/trombone-namm.jpg\"><img /></a>At NAMM in Anaheim, California
<p>Aside from feeling like a huge failure, I knew I’d need a lot of luck to get a job.</p>
<p>Someone would have to take a big chance on me.</p>
<p>But there were a few problems.</p>
<p>I was terrified of talking to strangers, much less asking them big favors. And I had almost no traditionally useful skills.</p>
<p>Enter WordPress.</p>
<h2>Lots Of Options</h2>
<p>When you’re changing careers, you’ll want skills that will help no matter what you end up doing.</p>
<p>You don’t want to deep-dive into calculus and find out that it won’t help.</p>
<p>Learning WordPress is perfect.</p>
<p>If you get really interested in the technical side, you can be a JS or PHP developer.</p>
<p>If you really like content creation, that’s also great. You can start a blog or work in marketing.</p>
<p>If none of it interests you, at least you can help people set up a website as you look for another career.</p>
<p>So soon after meeting with the career counselor, I took Zac Gordon’s course on WordPress Theme Development.</p>
<p>I wrote a theme based on his course, and really liked how WordPress worked.</p>
<p>He taught me to build sites, and later write plugins.</p>
<a href=\"https://s20094.pcdn.co/wp-content/uploads/2022/01/with-zac-gordon.jpg\"><img /></a>Zac Gordon with XWP
<h2>Invite Yourself To The Party</h2>
<p>The great thing about WordPress is that you can contribute right away.</p>
<p>With some careers, you need somebody to take a chance on you before you can do much.</p>
<p>To get experience as an investment banker or business consultant, you probably need to actually have the job.</p>
<p>But with WordPress, you can invite yourself.</p>
<p>You can open pull requests to Core or Gutenberg without anyone asking.</p>
<p>You can deploy plugins to wp.org that real people use, without having a college degree.</p>
<p>With this growing experience, I applied online to <a href=\"https://xwp.co/\">XWP</a>.</p>
<p>Weston Ruter responded right away, and was really helpful.</p>
<p>I started opening simple PRs to “help” with the Customizer work.</p>
<p>In reality, my work might have slowed things down, and was really simple.</p>
<p>But I didn’t have to wait to be invited. I invited myself to the party, and one of the PRs was merged into Core.</p>
<p>Later, when I interviewed with <a href=\"https://xwp.co/\">XWP</a> and got the job, I could show that I had a little experience working with other developers.</p>
<a href=\"https://s20094.pcdn.co/wp-content/uploads/2022/01/with-xwp-1.jpg\"><img /></a>XWP At WordCamp US Contributor Day, 2017
<p>It’s still embarrassing looking back at the work I did. But WordPress allows you to contribute, regardless of your experience level.</p>
<p>Years later, when I lived in Mexico City, one of my friends got interested in technology.</p>
<p>He was like me. He had a degree in an unrelated field, and wanted a great career.</p>
<p>So I showed him how much opportunity WordPress has.</p>
<p>He did something similar to what I did.</p>
<p>He opened PRs to an agency’s repos, and the agency asked him if he wanted to talk about a job, without him needing to apply. Years later, he’s still doing really well at his job.</p>
<p>I did very little, other than point him to a huge opportunity: WordPress.</p>
<h2>Concrete Skills</h2>
<p>Changing careers is really awkward.</p>
<p>You read about networking, which seems like you’re asking strangers for favors and sending spam DMs.</p>
<p>You also learn to reframe things as transferable skills.</p>
<p>So if you’ve done hard things, you can say you’re “comfortable with ambiguity.”</p>
<p>But with WordPress skills, you have more concrete skills to offer.</p>
<p>It’s less awkward explaining to someone why they should take a chance on you.</p>
<p>You’ve shown you’re committed to your career path by your portfolio of plugins.</p>
<p>And you don’t have to send spam DMs on LinkedIn.</p>
<p>In 2014, I went to my first WordPress meetup, <a href=\"https://www.meetup.com/WPLosAngeles\">WordPress Los Angeles</a>. I was nervous, but I wasn’t trying to take any value.</p>
<p>I could even answer a few questions.</p>
<p>Renee Johnson and I met there. We even reunited in WordCamp Europe and Mexico City several years later when I lived there:</p>
<a href=\"https://s20094.pcdn.co/wp-content/uploads/2022/01/with-renee.jpg\"><img /></a>Yani Jimenez and Renee Johnson, Mexico City
<p>With WordPress skills, you can flip from taking to giving value. Everything is much less awkward.</p>
<p>As you probably know, there are many self-taught developers in WordPress.</p>
<p>College degrees rarely come up in hiring conversations, at least in my experience.</p>
<p>And I’ve found WordPress very accepting of different career backgrounds. Matt Mullenweg was a musician, famously naming every release after a jazz musician.</p>
<p>People in WordPress are very understanding about changing careers.</p>
<p>Now, I don’t hide it, and it’s rarely more than a footnote in conversations.</p>
<h2>Mentorship</h2>
<p>Don’t go it alone.</p>
<p>It’s easy to think that you can just take online courses and eventually be ready for a job.</p>
<p>But code reviews are one of the main ways you’ll learn. And people in WP want to help.</p>
<p>If you contribute a few PRs to someone’s GitHub repo, they’ll probably do a quick code review of your own plugin or theme.</p>
<p>Weston was really helpful in doing a detailed review of my theme.</p>
<p>You also can learn a lot contributing to Gutenberg or other plugins.</p>
<p>They’ll give you detailed reviews. And you’ll basically get the same experience as if you were getting paid.</p>
<p>But if I were to do this again, I’d also look for more formal mentorship.</p>
<p>Hiring someone to review your plugins and themes would probably help.</p>
<h2>Nothing To Fix</h2>
<p>There’s a saying in marketing “what you can’t fix, you feature.”</p>
<p>In WordPress, you don’t have to fix your non-traditional career background.</p>
<p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/changing-careers-into-wordpress/\">Changing Careers Into WordPress</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 20 Jan 2021 17:50:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Ryan Kienstra\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"Gary: WordPress Importers: Defining a Schema\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"https://pento.net/?p=5495\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://pento.net/2021/01/20/wordpress-importers-defining-a-schema/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8792:\"<p>While schemata are usually implemented using language-specific tools (eg, XML uses <a href=\"https://www.w3.org/standards/xml/schema\">XML Schema</a>, JSON uses <a href=\"https://json-schema.org/\">JSON Schema</a>), they largely use the same concepts when talking about data. This is rather helpful, we don&#8217;t need to make a decision on <a href=\"https://pento.net/2021/01/19/wordpress-importers-getting-our-house-in-order/\">data formats</a> before we can start thinking about how the data should be arranged.</p>



<p><em>Note: Since these concepts apply equally to all data formats, I&#8217;m using &#8220;WXR&#8221; in this post as shorthand for &#8220;the structured data section of whichever file format we ultimately use&#8221;, rather than specifically referring to the existing WXR format.</em> <img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" /></p>



<h2>Why is a Schema Important?</h2>



<p>It&#8217;s fair to ask why, if the WordPress Importers have survived this entire time <em>without</em> a formal schema, why would we need one now?</p>



<p>There are two major reasons why we haven&#8217;t needed one in the past:</p>



<ul><li>WXR has remained largely unchanged in the last 10 years: there have been small additions or tweaks, but nothing significant. There&#8217;s been no need to keep track of changes.</li><li>WXR is currently very simple, with just a handful of basic elements. In a recent experiment, I was able to implement a JavaScript-based WXR generator in just a few days, entirely by referencing <a href=\"https://core.trac.wordpress.org/browser/trunk/src/wp-admin/includes/export.php\">the Core implementation</a>.</li></ul>



<p>These reasons are also why it would help to implement a schema for the future:</p>



<ul><li>As work on WXR proceeds, there will likely need to be substantial changes to what data is included: adding new fields, modifying existing fields, and removing redundant fields. Tracking these changes helps ensure any WXR implementations can stay in sync.</li><li>These changes will result in a more complex schema: relying on the source to re-implement it will become increasingly difficult and error-prone. Following Gutenberg&#8217;s lead, it&#8217;s likely that we&#8217;d want to provide official libraries in both PHP and JavaScript: keeping them in sync is best done from a source schema, rather than having one implementation copy the other.</li></ul>



<p>Taking the time to plan out a schema now gives us a solid base to work from, and it allows for future changes to happen in a reliable fashion.</p>



<h2>WXR for all of WordPress</h2>



<p>With a well defined schema, we can start to expand what data will be included in a WXR file.</p>



<h3>Media</h3>



<p>Interestingly, many of the challenges around media files are less to do with WXR, and more to do with importer capabilities. The biggest headache is retrieving the actual files, which the importer currently handles by trying to retrieve the file from the remote server, as defined in the <code>wp:attachment_url</code> node. In context, this behaviour is understandable: 10+ years ago, personal internet connections were too slow to be moving media around, it was better to have the servers talk to each other. It&#8217;s a useful mechanism that we should keep as a fallback, but the more reliable solution is to include the media file with the export.</p>



<h3>Plugins and Themes</h3>



<p>There are two parts to plugins and themes: the code, and the content. Modern WordPress sites <em>require</em> plugins to function, and most are customised to suit their particular theme.</p>



<p>For exporting the code, I wonder if a tiered solution could be applied:</p>



<ul><li>Anything from WordPress.org would just need their slug, since they can be re-downloaded during import. Particularly as WordPress continues to move towards an auto-updated future, modified versions of plugins and themes are explicitly not supported.</li><li>Third party plugins and themes would be given a filter to use, where they can provide a download URL that can be included in the export file.</li><li>Third party plugins/themes that don’t provide a download URL would either need to be skipped, or zipped up and included in the export file.</li></ul>



<p>For exporting the content, WXR already includes custom post types, but doesn&#8217;t include custom settings, or custom tables. The former should be included automatically, and the latter would likely be handled by an appropriate action for the plugin to hook into.</p>



<h3>Settings</h3>



<p>There are a currently handful of special settings that are exported, but (as I just noted, particularly with plugins and themes being exported) this would likely need to be expanded to included most items in&nbsp;<code>wp_options</code>.</p>



<h3>Users</h3>



<p>Currently, the bare minimum information about users who’ve authored a post is included in the export. This would need to be expanded to include more user information, as well as users who aren’t post authors.</p>



<h2>WXR for <em>parts</em> of WordPress</h2>



<p>The modern use case for importers isn&#8217;t just to handle a full site, but to handle keeping sites in sync. For example, most news organisations will have a staging site (or even several layers of staging!) which is synchronised to production.</p>



<p>While it&#8217;s well outside the scope of this project to directly handle every one of these use cases, we should be able to provide the framework for organisations to build reliable platforms on. Exports should be repeatable, objects in the export should have unique identifiers, and the importer should be able to handle any subset of WXR.</p>



<h2>WXR Beyond WordPress</h2>



<p>Up until this point, we&#8217;ve really been talking about&nbsp;WordPress→WordPress migrations, but I think WXR is a useful format beyond that. Instead of just containing direct exports of the data from particular plugins, we could also allow it to contain &#8220;types&#8221; of data. This turns WXR into an intermediary language, exports can be created from any source, and imported into WordPress.</p>



<p>Let&#8217;s consider an example. Say we create a tool that can export a Shopify, Wix, or GoDaddy site to WXR, how would we represent an online store in the WXR file? We don&#8217;t want to export in the format that any particular plugin would use, since a WordPress Core tool shouldn&#8217;t be advantaging one plugin over others.</p>



<p>Instead, it would be better if we could format the data in a platform-agnostic way, which plugins could then implement support for. As luck would have it, <a href=\"https://schema.org/\">Schema.org</a> provides exactly the kind of data structure we could use here. It&#8217;s been <a href=\"https://schema.org/docs/releases.html\">actively maintained for nearly nine years</a>, it supports a <a href=\"https://schema.org/docs/schemas.html\">wide variety of data types</a>, and is intentionally platform-agnostic.</p>



<p>Gazing into my crystal ball for a moment, I can certainly imagine a future where plugins could implement and declare support for importing certain data types. When handling such an import (assuming one of those plugins wasn&#8217;t already installed), the WordPress Importer could offer them as options during the import process. This kind of seamless integration allows WordPress to show that it offers the same kind of fully-featured site building experience that modern CMS services do.</p>



<p>Of course, reality is never quite as simple as crystal balls and magic wands make them out to be. We have to contend with services that provide incomplete or fragmented exports, and there are even services that deliberately don&#8217;t provide exports at all. In the next post, I&#8217;ll be writing about why we should address this problem, and how we might be able to go about it.</p>



<div class=\"wp-block-group is-style-twentytwentyone-border\"><div class=\"wp-block-group__inner-container\">
<p><em>This post is part of a series, talking about the WordPress Importers, their history, where they are now, and where they could go in the future.</em></p>



<ul><li><em><a href=\"https://pento.net/2021/01/18/wordpress-importers-stating-the-problem/\">Part 1: Stating the Problem</a></em></li><li><em><a href=\"https://pento.net/2021/01/19/wordpress-importers-getting-our-house-in-order/\">Part 2: Getting Our House in Order</a></em></li><li><em><a href=\"https://pento.net/2021/01/20/wordpress-importers-defining-a-schema/\">Part 3: Defining a Schema</a></em></li><li><a href=\"https://pento.net/2021/01/21/wordpress-importers-free-as-in-speech/\"><em>Part 4: Free (as in Speech)</em></a></li></ul>



<p></p>
</div></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 19 Jan 2021 23:13:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Gary\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"WPTavern: Custom Layouts Plugin Creates a Posts Display System for Both the Classic and Block Editors\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110409\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:247:\"https://wptavern.com/custom-layouts-plugin-creates-a-posts-display-system-for-both-the-classic-and-block-editors?utm_source=rss&utm_medium=rss&utm_campaign=custom-layouts-plugin-creates-a-posts-display-system-for-both-the-classic-and-block-editors\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5383:\"<p class=\"has-drop-cap\">Ross Morsali, via his brand Code Amp, released the <a href=\"https://wordpress.org/plugins/custom-layouts/\">Custom Layouts</a> plugin last week. The plugin&rsquo;s goal is to provide a visual post layout builder for users of both the block and classic editors.</p>



<p>For end-users, this is yet another choice between the multitude of plugins for displaying posts. After years of new plugins launching in this space, it would seem that there would be a clear front-runner, but developers are still trying to tame this wild and complex feature. The Custom Layouts plugin has its own approach, and it is worth giving it a quick spin to see if it suits you.</p>



<p>I have written extensively about the <a href=\"https://wptavern.com/gutenberg-9-6-introduces-drag-and-drop-blocks-and-global-inheritance-for-the-query-block\">upcoming Query block</a> and its role in the <a href=\"https://wptavern.com/understanding-the-query-block-and-its-importance-in-site-editing\">future of WordPress</a>. However, it is necessary to look at alternative solutions for displaying posts via the block editor. The Gutenberg development team should take note of the things that work and those that do not.</p>



<p>For developers, the plugin is a noteworthy experiment that uses the block editor component system outside of the actual editor. Custom Layouts uses these various components on its custom Layout and Template Editor screens.</p>



<p>The plugin is a product of Morsali learning React and the block system in the last year and a half. &ldquo;Working with Gutenberg and the Block Editor as a developer is a far superior experience to the old paradigm (the classic editor) &mdash; the learning curve is definitely greater, but once you get over the hump it seems the future is bright,&rdquo; he wrote in the <a href=\"https://codeamp.com/creating-the-custom-layouts-plugin/\">plugin&rsquo;s announcement post</a>. &ldquo;I also love the fact that we don&rsquo;t actually need to be using the Block Editor to use Gutenberg components &mdash; that means we can still build what we want and how we want it (providing we&rsquo;re using React), whilst keeping the UI in tune with the rest of WordPress.&rdquo;</p>



<h2>How the Plugin Works</h2>



<img />Template editor screen.



<p class=\"has-drop-cap\">Custom Layouts takes a different route than similar plugins, splitting its components into different screens. The terminology can be confusing to the uninitiated. The plugin introduces two parts that serve as the foundation of its system:</p>



<ul><li><strong>Templates:</strong> Handles the design of individual posts.</li><li><strong>Layouts:</strong> Controls queried posts and their layout.</li></ul>



<p>I have had a beta version of the plugin since late December. This has given me three weeks to decide whether I like the approach. On the one hand, the plugin caters to two different user bases. One set can implement their layouts via the Custom Layouts block. Those on the classic editor can use the Layout Editor screen. Both share the Template Editor.</p>



<img />Creating a three-column grid layout.



<p>The plugin&rsquo;s system is a good option for users of the classic editor. It comes with a visual interface they would otherwise not have. It also provides a shortcode for easy copying/pasting into the post editor.</p>



<p>For users of the block editor, having a separate screen for the template builder will likely feel unnatural. Because the block editor is a visual interface itself, the multiple screens create a disjointed atmosphere that never feels <em>right</em>.</p>



<p>However, there is a solution for that in the plugin. I recommend users skip the Template Editor and Layout Editor screens altogether. The Custom Layouts block serves as an alternative layout builder in the block editor. Plus, users can edit existing templates via a popup overlay or even create new ones without ever leaving the post-editing screen. </p>



<img />Overlay for editing a template.



<p>Building everything from the post editor feels like it should feel. Users get more of that instant feedback that they are accustomed to through the block editor.</p>



<p>There are benefits to the multi-component system. Separating the template builder means that users can build and reuse a specific design from a single source. They can also update individual templates, which will subsequently apply to all uses of those templates across the site.</p>



<p>The other benefit is that end-users are not overloaded with choices. Building a query-related block, widget, shortcode, or similar component is fraught with complexity. This is because there are three pieces of laying out a list of posts: the query to load them, the overall layout, and the design of the individual posts. Putting options for each of these pieces into the block inspector, for example, means creating a balance between sacrificing some choices and providing every possible setting to the user. This balancing act is what drove Morsali toward separating the components of the plugin.</p>



<p>On the whole, Custom Layouts is a solid plugin. The downside is that there is a little bit of a learning curve because it serves two audiences. Users will need to figure out which workflow best suits them first. Once they figure that out, the plugin is pretty nice to work with.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 19 Jan 2021 21:48:33 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"WPTavern: WordPress for Android Previews New Story Posts Feature, Now in Public Beta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110474\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:211:\"https://wptavern.com/wordpress-for-android-previews-new-story-posts-feature-now-in-public-beta?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-for-android-previews-new-story-posts-feature-now-in-public-beta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3697:\"<p>WordPress users on Android may have noticed a new prompt in the mobile app for publishing Story posts. This feature is now in public beta in the Android app, ahead of an upcoming launch on the WordPress iOS app. Stories will also coming to the Block editor on WordPress.com in early 2021. </p>



<p>Early access to Story posts is available in version 16.3+ of the app, released in mid-December. The prompt appears at the bottom of the site management screen. Selecting a Story post immediately takes you to your phone&rsquo;s media where you can add photos or a video.</p>



<ul><li class=\"blocks-gallery-item\"><img /></li><li class=\"blocks-gallery-item\"><img /></li></ul>



<p><br />The mobile app&rsquo;s implementation of the Stories feature is different from other platforms, like Instagram and Facebook, in several key ways. Most importantly, WordPress stories are not ephemeral. They live permanently on your site and anyone can view them after they are published. WordPress.com&rsquo;s <a href=\"https://wordpress.com/support/story-block/\">documentation</a> for the block highlights a few differences: </p>



<ul><li>Posts with Stories won&rsquo;t disappear after 24 hours.&nbsp;</li><li>The Story content can be added to and edited after publishing.&nbsp;</li><li>Anyone visiting your site can view the Story.&nbsp;</li><li>You can share your Story on any platform using the post&nbsp;<a href=\"https://wordpress.com/support/permalinks-and-slugs/\">permalink</a>.</li></ul>



<p>After testing the feature, I can confirm a few more differences. While the WordPress app&rsquo;s implementation transcends other platforms&rsquo; limitations on the duration of the story&rsquo;s visibility, it lacks basic features that users have come to expect from other apps. It doesn&rsquo;t support animated gifs, effects, location, stickers, music, and other embellishments that make stories such a creative social medium. At the moment, the only thing you can do is add colored text with a background.</p>



<ul><li class=\"blocks-gallery-item\"><img /></li><li class=\"blocks-gallery-item\"><img /></li></ul>



<p>Videos work as Stories, too, but they don&rsquo;t seem to have the same preview with a thumbnail image. It&rsquo;s just a generic placeholder for now. That may be something the team is still working on, but I logged an <a href=\"https://github.com/wordpress-mobile/WordPress-Android/issues/13809\">issue</a> on GitHub for it, in case it&rsquo;s a bug. </p>



<ul><li class=\"blocks-gallery-item\"><img /></li><li class=\"blocks-gallery-item\"><img /></li></ul>



<p>In the interest of owning your own content, I can see it being useful to create stories on your own website and share them to other networks. The current implementation is basically a fullscreen slideshow. It is not yet more compelling than what social networks offer, but it looks like WordPress for iOS <a href=\"https://github.com/tumblr/kanvas-ios/projects/1\">plans to expand on these features</a> using the open source <a href=\"https://github.com/tumblr/kanvas-ios\">Kanvas library</a> from Tumblr.</p>



<p>Kanvas makes it possible to add&nbsp;effects, drawings, text, stickers, and make GIFs from existing media or the camera. If you have ever used the&nbsp;<a href=\"https://apps.apple.com/us/app/tumblr/id305343404\">Tumblr iOS app</a> then you have seen Kanvas in action in the camera, media editor, GIF maker, and media posting tool. It should make for a more exciting Stories implementation on iOS, with features on par with what users have come to expect from other platforms. Something similar for Android may be in the works and this post will be updated as soon as we receive comments from the mobile team.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 18 Jan 2021 23:55:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"Gary: WordPress Importers: Getting Our House in Order\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"https://pento.net/?p=5465\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://pento.net/2021/01/19/wordpress-importers-getting-our-house-in-order/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:15440:\"<p>The <a href=\"https://pento.net/2021/01/18/wordpress-importers-stating-the-problem/\">previous post</a> talked about the broad problems we need to tackle to bring our importers up to speed, making them available for everyone to use.</p>



<p>In this post, I&#8217;m going to focus on what we could do with the existing technology, in order to give us the best possible framework going forward.</p>



<h2>A Reliable Base</h2>



<p>Importers are an interesting technical problem. Much like you&#8217;d expect from any backup/restore code, importers need to be extremely reliable. They need to comfortable handle all sorts of unusual data, and they need to keep it all safe. Particularly considering their age, the WordPress Importers do a remarkably good job of handling most content you can throw at it.</p>



<p>However, modern development practices have evolved and improved since the importers were first written, and we should certainly be making use of such practices, when they fit with our requirements.</p>



<p>For building reliable software that we expect to largely run by itself, a variety of comprehensive automated testing is critical. This ensures we can confidently take on the broader issues, safe in the knowledge that we have a reliable base to work from.</p>



<p>Testing <em>must</em> be the first item on this list. A variety of automated testing gives us confidence that changes are safe, and that the code can continue to be maintained in the future.</p>



<p>Data formats must be well defined. While this is useful for ensuring data can be handled in a predictable fashion, it&#8217;s also a very clear demonstration of our commitment to data freedom.</p>



<p>APIs for creating or extending importers should be straightforward for hooking into.</p>



<h3>Performance Isn&#8217;t an Optional Extra</h3>



<p>With sites constantly growing in size (and with the export files potentially gaining a heap of extra data), we need to care about the performance of the importers.</p>



<p>Luckily, there&#8217;s already been some substantial work done on this front:</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"wp-embedded-content\"><a href=\"https://make.wordpress.org/core/2015/11/18/wordpress-importer-redux/\">WordPress Importer Redux</a></blockquote>
</div>



<p>There are other groups in the WordPress world who&#8217;ve made performance improvements in their own tools: gathering all of that experience is a relatively quick way to bring in production-tested improvements.</p>



<h2>The WXR Format</h2>



<p>It&#8217;s worth talking about the WXR format itself, and determining whether it&#8217;s the best option for handling exports into the future. XML-based formats are largely viewed as a relic of days gone past, so (if we were to completely ignore backwards compatibility for a moment) is there a modern data format that would work better?</p>



<p>The short answer&#8230; kind of. <img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" /></p>



<p>XML is actually well suited to this use case, and (particularly when looking at performance improvements) is the only data format for which PHP comes with a built-in streaming parser.</p>



<p>That said, WXR is basically an extension of the RSS format: as we add more data to the file that clearly doesn&#8217;t belong in RSS, there is likely an argument for defining an entirely WordPress-focused schema.</p>



<h3>Alternative Formats</h3>



<p>It&#8217;s important to consider what the priorities are for our export format, which will help guide any decision we make. So, I&#8217;d like to suggest the following priorities (in approximate priority order):</p>



<ul><li><strong>PHP Support</strong>: The format should be natively supported in PHP, thought it is still workable if we need to ship an additional library.</li><li><strong>Performant</strong>: Particularly when looking at very large exports, it should be processed as quickly as possible, using minimal RAM.</li><li><strong>Supports Binary Files</strong>: <a href=\"https://pento.net/2021/01/18/wordpress-importers-stating-the-problem/#comment-37926\">The first comments on my previous post</a> asked about media support, we clearly should be treating it as a first-class citizen.</li><li><strong>Standards Based</strong>: Is the format based on a documented standard? (Another way to ask this: are there multiple different implementations of the format? Do those implementations all function the same?</li><li><strong>Backward Compatible</strong>: Can the format be used by existing tools with no changes, or minimal changes?</li><li><strong>Self Descriptive</strong>: Does the format include information about what data you&#8217;re currently looking at, or do you need to refer to a schema?</li><li><strong>Human Readable</strong>: Can the file be opened and read in a text editor?</li></ul>



<p>Given these priorities, what are some options?</p>



<h4>WXR (XML-based)</h4>



<p>Either the RSS-based schema that we already use, or a custom-defined XML schema, the arguments for this format are pretty well known.</p>



<p>One argument that hasn&#8217;t been well covered is how there&#8217;s a definite trade-off when it comes to supporting binary files. Currently, the importer tries to scrape the media file from the original source, which is not particularly reliable. So, if we were to look at including media files in the WXR file, the best option for storing them is to base64 encode them. Unfortunately, that would have a serious effect on performance, as well as readability: adding huge base64 strings would make even the smallest exports impossible to read.</p>



<p>Either way, this option would be mostly backwards compatible, though some tools may require a bit of reworking if we were to substantial change the schema.</p>



<h4>WXR (ZIP-based)</h4>



<p>To address the issues with media files, an alternative option might be to follow the path that Microsoft Word and OpenOffice use: put the text content in an XML file, put the binary content into folders, and compress the whole thing. </p>



<p>This addresses the performance and binary support problems, but is initially worse for readability: if you don&#8217;t know that it&#8217;s a ZIP file, you can&#8217;t read it in a text editor. Once you unzip it, however, it does become quite readable, and has the same level of backwards compatibility as the XML-based format.</p>



<h4>JSON</h4>



<p>JSON could work as a replacement for XML in both of the above formats, with one additional caveat: there is no streaming JSON parser built in to PHP. There are 3rd party libraries available, but given <a href=\"http://seriot.ch/parsing_json.php\">the documented differences between JSON parsers</a>, I would be wary about using one library to produce the JSON, and another to parse it.</p>



<p>This format largely wouldn&#8217;t be backwards compatible, though tools which rely on the export file being plain text (eg, command line tools to do broad search-and-replaces on the file) can be modified relatively easily.</p>



<p>There are additional subjective arguments (both for and against) the readability of JSON vs XML, but I&#8217;m not sure there&#8217;s anything to them beyond personal preference.</p>



<h4>SQLite</h4>



<p>The <a href=\"https://sqlite.org/index.html\">SQLite</a> team wrote <a href=\"https://www.sqlite.org/affcase1.html\">an interesting (indirect) argument</a> on this topic: OpenOffice uses a ZIP-based format for storing documents, the SQLite team argued that there would be benefits (particularly around performance and reliability) for OpenOffice to switch to SQLite.</p>



<p>They key issues that I see are:</p>



<ul><li>SQLite is included in PHP, but <a href=\"https://www.php.net/manual/en/sqlite3.installation.php\">not enabled by default on Windows</a>.</li><li>While the SQLite team have a strong commitment to providing long-term support, SQLite is not a standard, and the only implementation is the one provided by the SQLite team.</li><li>This option is not backwards compatible at all.</li></ul>



<h4>FlatBuffers</h4>



<p><a href=\"http://google.github.io/flatbuffers/\">FlatBuffers</a> is an interesting comparison, since it&#8217;s a data format focussed entirely on speed. The down side of this focus is that it <em>requires</em> a defined schema to read the data. Much like SQLite, the only standard for FlatBuffers is the implementation. Unlike SQLite, FlatBuffers has made no commitments to providing long-term support.</p>



<table class=\"has-fixed-layout\"><thead><tr><th></th><th class=\"has-text-align-center\">WXR (XML-based)</th><th class=\"has-text-align-center\">WXR (ZIP-based)</th><th class=\"has-text-align-center\">JSON</th><th class=\"has-text-align-center\">SQLite</th><th class=\"has-text-align-center\">FlatBuffers</th></tr></thead><tbody><tr><td>Works in PHP?</td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/2705.png\" alt=\"✅\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/2705.png\" alt=\"✅\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/26a0.png\" alt=\"⚠\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/26a0.png\" alt=\"⚠\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/26a0.png\" alt=\"⚠\" class=\"wp-smiley\" /></td></tr><tr><td>Performant?</td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/26a0.png\" alt=\"⚠\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/2705.png\" alt=\"✅\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/26a0.png\" alt=\"⚠\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/2705.png\" alt=\"✅\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/2705.png\" alt=\"✅\" class=\"wp-smiley\" /></td></tr><tr><td>Supports Binary Files?</td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/26a0.png\" alt=\"⚠\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/2705.png\" alt=\"✅\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/26a0.png\" alt=\"⚠\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/2705.png\" alt=\"✅\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/2705.png\" alt=\"✅\" class=\"wp-smiley\" /></td></tr><tr><td>Standards Based?</td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/2705.png\" alt=\"✅\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/2705.png\" alt=\"✅\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/2705.png\" alt=\"✅\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/26a0.png\" alt=\"⚠\" class=\"wp-smiley\" /> / <img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/274c.png\" alt=\"❌\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/274c.png\" alt=\"❌\" class=\"wp-smiley\" /></td></tr><tr><td>Backwards Compatible?</td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/26a0.png\" alt=\"⚠\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/26a0.png\" alt=\"⚠\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/274c.png\" alt=\"❌\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/274c.png\" alt=\"❌\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/274c.png\" alt=\"❌\" class=\"wp-smiley\" /></td></tr><tr><td>Self Descriptive?</td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/2705.png\" alt=\"✅\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/2705.png\" alt=\"✅\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/2705.png\" alt=\"✅\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/2705.png\" alt=\"✅\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/274c.png\" alt=\"❌\" class=\"wp-smiley\" /></td></tr><tr><td>Readable?</td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/2705.png\" alt=\"✅\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/26a0.png\" alt=\"⚠\" class=\"wp-smiley\" /> / <img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/274c.png\" alt=\"❌\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/2705.png\" alt=\"✅\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/274c.png\" alt=\"❌\" class=\"wp-smiley\" /></td><td class=\"has-text-align-center\"><img src=\"https://s.w.org/images/core/emoji/13.0.1/72x72/274c.png\" alt=\"❌\" class=\"wp-smiley\" /></td></tr></tbody></table>



<p>As with any decision, this is a matter of trade-offs. I&#8217;m certainly interested in hearing additional perspectives on these options, or thoughts on options that I haven&#8217;t considered.</p>



<p>Regardless of which particular format we choose for storing WordPress exports, every format should have (or in the case of FlatBuffers, <em>requires</em>) a schema. We can talk about schemata without going into implementation details, so I&#8217;ll be writing about that in the next post.</p>



<div class=\"wp-block-group is-style-twentytwentyone-border\"><div class=\"wp-block-group__inner-container\">
<p><em>This post is part of a series, talking about the WordPress Importers, their history, where they are now, and where they could go in the future.</em></p>



<ul><li><em><a href=\"https://pento.net/2021/01/18/wordpress-importers-stating-the-problem/\">Part 1: Stating the Problem</a></em></li><li><em><a href=\"https://pento.net/2021/01/19/wordpress-importers-getting-our-house-in-order/\">Part 2: Getting Our House in Order</a></em></li><li><em><a href=\"https://pento.net/2021/01/20/wordpress-importers-defining-a-schema/\">Part 3: Defining a Schema</a></em></li><li><a href=\"https://pento.net/2021/01/21/wordpress-importers-free-as-in-speech/\"><em>Part 4: Free (as in Speech)</em></a></li></ul>



<p></p>
</div></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 18 Jan 2021 22:50:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Gary\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"WPTavern: Kinsta Launches Free Local WordPress Development Tool\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110351\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:171:\"https://wptavern.com/kinsta-launches-free-local-wordpress-development-tool?utm_source=rss&utm_medium=rss&utm_campaign=kinsta-launches-free-local-wordpress-development-tool\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5961:\"<p class=\"has-drop-cap\">Kinsta, a managed WordPress hosting company, announced its local development tool named <a href=\"https://kinsta.com/devkinsta/\">DevKinsta</a> earlier today. The tool allows developers to spin up new WordPress sites, including multisite support, in moments. Each site is automatically configured with Nginx, PHP, and MySQL.</p>



<p>DevKinsta packages Adminer, an open-source database manager. The system also includes an SMTP server and email inbox for testing outgoing emails locally.</p>



<p>&ldquo;This is the first version of the tool, let&rsquo;s say the MVP, but we have a dedicated development team supporting and adding a lot of new features to it,&rdquo; said Tom Zsomborgi, Kinsta&rsquo;s Chief Business Officer.</p>



<p>Developers can run and test HTTPS support and enable <code>WP_DEBUG</code> at the flip of a switch. Kinsta web hosting customers can also deploy their sites directly from the interface.</p>



<p>It took me around an hour to get the system set up and running. To be more exact, I spent 53 minutes. Close enough. Between having to sign out, restart my laptop, and waiting for various pieces to install, I at least managed to get a little laundry done in those dull, in-between moments.</p>



<img />Installing DevKinsta on Windows.



<p>The setup process was not a completely pain-free affair. However, the price of admission to use this tool &mdash; a little bit of my time &mdash; was well worth it.</p>



<p>Let me be clear. I have tested far worse systems. Even with over 15 years of development experience under my belt, I have utterly failed at setting up other local dev environments. For DevKinsta to simply get me to the finish line is a success.</p>



<p>However, I like simple things, and I prefer them to move along relatively quickly. I am accustomed to a 20-minute XAMPP setup. While it may not be as fancy or have the bells and whistles of more sophisticated development tools, it gets the job done and rarely doles out headaches.</p>



<p>The holdup was setting up Windows Subsystem for Linux (WSL 2) and Docker, which are both requirements. Jump-starting DevKinsta itself was a breeze. And, as an old-school XAMPP user, DevKinsta&rsquo;s ease of use has pulled me in enough to do more than just give it a passing glance. I could actually see myself using this on a day-to-day basis.</p>



<p>In short, I am sold. DevKinsta is a tool all WordPress developers should at least spin up once.</p>



<p>Thus far, the <a href=\"https://twitter.com/kinsta/status/1351177344740941829\">feedback on Twitter</a> has been generally positive. However, Linux users may have to wait a bit because the tool is only available for macOS and Windows at the moment.</p>



<p>&ldquo;I love seeing companies releasing local development tools but I wish more would offer their services to Linux users,&rdquo; <a href=\"https://twitter.com/chadmccullough/status/1351195217483988998\">tweeted</a> WordPress developer Chad McCullough. &ldquo;There are a lot of us developers out there running Linux.&rdquo; The Kinsta team responded that the tool will eventually support Linux and that news is forthcoming.</p>



<img />Spinning up a new WordPress site.



<p>The simple and straightforward UI is what makes this tool useful. Most developers do not need overly complicated configurations and options. They simply need to launch an environment that lets them work on their own projects. Anything beyond the basics far too often gets in the way.</p>



<p>DevKinsta makes it easy to launch and manage multiple development installs. Developers can also switch PHP versions via a simple dropdown &mdash; versions 7.2 &ndash; 8.0 are currently supported.</p>



<img />Site management screen.



<p>The obvious comparison for DevKinsta will be against <a href=\"https://localwp.com/\">Local by Flywheel</a>, which has increasingly become a primary tool for many WordPress developers.</p>



<p>Zsomborgi explained why the company thinks DevKinsta is a better option. &ldquo;In our case, Docker is an important part here. Local doesn&rsquo;t use virtualization in the background. Local has to install every piece of the environment to the host machine (NGINX, apache, different PHP versions, etc.). DevKinsta encapsulates these technologies into containers. Containers do make things easier for maintaining different applications without interrupting the host OS or installing many of the dependencies that are not required. We pretty much don&rsquo;t touch the host OS, but have Docker as our main dependency to run the applications on their own environments.&rdquo;</p>



<p>He said this speeds up the upgrade process and makes it easier to maintain bug fixes and send out security patches. He also said that because each application runs on its own Kernel namespace, any security issues should not affect the host OS.</p>



<p>&ldquo;If the user is comfortable enough with Docker, he can extend DevKinsta features,&rdquo; said Zsomborgi. &ldquo;For example, he can monitor the usage of the container, or the PHP usage specifically as an example with docker monitoring tools that comes out of the box with Docker installation. The user can install any utility inside DevKinsta containers without touching the host OS and use applications that are not supported on Windows, for example.&rdquo;</p>



<p>One of the use cases he mentioned was installing a benchmark tool to get statistics about site performance. This can be installed inside the Nginx container as a sidecar or separate container.</p>



<p>&ldquo;In the past, Local didn&rsquo;t use exactly Docker,&rdquo; said Zsomborgi. &ldquo;They used VirtualBox + DockerMachine. We tried it, and it was a bit painful. But without VirtualBox, DevKinsta can be more stable and scalable. So we use Docker without VirtualBox. It also needs virtualization, but nowadays, there are fewer Windows computers that have disabled virtualization by default.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 18 Jan 2021 21:07:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"Gary: WordPress Importers: Stating the Problem\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"https://pento.net/?p=5449\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://pento.net/2021/01/18/wordpress-importers-stating-the-problem/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8838:\"<p>It&#8217;s time to focus on the WordPress Importers.</p>



<p>I&#8217;m not talking about tidying them up, or improve performance, or fixing some bugs, though these are certainly things that should happen. Instead, we need to consider their purpose, how they fit as a driver of WordPress&#8217; commitment to Open Source, and how they can be a key element in helping to keep the Internet Open and Free.</p>



<h2>The History</h2>



<p>The WordPress Importers are arguably <em>the</em> key driver to WordPress&#8217; early success. Before the importer plugins existed (before WordPress even supported plugins!) there were a handful of <code>import-*.php</code> scripts in the <a href=\"https://core.trac.wordpress.org/browser/trunk/wp-admin?rev=688\"><code>wp-admin</code> directory</a> that could be used to import blogs from other blogging platforms. When other platforms fell out of favour, WordPress already had an importer ready for people to move their site over. One of the most notable instances was in 2004, <a href=\"https://github.com/WordPress/book/blob/trunk/Content/Part%202/9-freedom-zero.md\">when Moveable Type changed their license and prices</a>, suddenly requiring personal blog authors to pay for something that had previously been free. WordPress was fortunate enough to be in the right place at the right time: many of WordPress&#8217; earliest users came from Moveable Type.</p>



<p>As time went on, WordPress became well known in its own right. Growth relied less on people wanting to switch from another provider, and more on people choosing to start their site with WordPress. For <a href=\"https://core.trac.wordpress.org/ticket/13307\">practical reasons</a>, the importers were moved out of WordPress Core, and into their own plugins. Since then, they&#8217;ve largely been in maintenance mode: bugs are fixed when they come up, but since export formats rarely change, they&#8217;ve just continued to work for all these years.</p>



<p>An unfortunate side effect of this, however, is that new importers are rarely written. While a new breed of services have sprung up over the years, the WordPress importers haven&#8217;t kept up.</p>



<h2>The New Services</h2>



<p>There are many new CMS services that have cropped up in recent years, and we don&#8217;t have importers for any of them. WordPress.com has a few extra ones written, but they&#8217;ve been built on the WordPress.com infrastructure out of necessity.</p>



<p>You see, we&#8217;ve always assumed that other CMSes will provide some sort of export file that we can use to import into WordPress. That isn&#8217;t always the case, however. Some services (notable, <a href=\"https://support.wix.com/en/article/exporting-or-embedding-your-wix-site-elsewhere\">Wix</a> and <a href=\"https://godaddy.com/community/Websites-Marketing-Website/Exporting-Website-Builder-Site-to-Word-Press/td-p/124526\">GoDaddy Website Builder</a>) deliberately don&#8217;t allow you to export your own content. Other services provide incomplete or fragmented exports, needlessly forcing stress upon site owners who want to use their own content outside of that service.</p>



<p>To work around this, WordPress.com has implemented importers that effectively scrape the site: while this has worked to some degree, it does require regular maintenance, and the importer has to do a lot of guessing about how the content should be transformed. This is clearly not a solution that would be maintainable as a plugin.</p>



<div class=\"wp-block-group alignwide is-style-twentytwentyone-border\"><div class=\"wp-block-group__inner-container\">
<p class=\"has-text-align-center\">Problem Number 4</p>



<p class=\"alignwide has-extra-large-font-size\"><strong>Some services work against their customers, and actively prevent site owners from controlling their own content.</strong></p>
</div></div>



<p>This strikes at the heart of the <a href=\"https://wordpress.org/about/#bill-of-rights\">WordPress Bill of Rights</a>. WordPress is built with fundamental freedoms in mind: all of those freedoms point to owning your content, and being able to make use of it in any form you like. When a CMS actively works against providing such freedom to their community, I would argue that we have an obligation to help that community out.</p>



<h2>A Variety of Content</h2>



<p>It&#8217;s worth discussing how, when starting a modern CMS service, the bar for success is very high. You can&#8217;t get away with just providing a basic CMS: you need to provide all the options. Blogs, eCommerce, mailing lists, forums, themes, polls, statistics, contact forms, integrations, embeds, the list goes on. The closest comparison to modern CMS services is&#8230; the <em>entire</em> WordPress ecosystem: built on WordPress core, but with the myriad of plugins and themes available, along with the variety of services offered by a huge array of companies.</p>



<p>So, when we talk about the importers, we need to consider how they&#8217;ll be used.</p>



<div class=\"wp-block-group alignwide is-style-twentytwentyone-border\"><div class=\"wp-block-group__inner-container\">
<p class=\"has-text-align-center\">Problem Number 3</p>



<p class=\"alignwide has-extra-large-font-size\"><strong>To import from a modern CMS service into WordPress, your importer needs to map from service features to WordPress plugins.</strong></p>
</div></div>



<h2>Getting Our Own House In Order</h2>



<p>Some of these problems don&#8217;t just apply to new services, however.</p>



<p>Out of the box, WordPress exports to WXR (WordPress eXtended RSS) files: an XML file that contains the <em>content</em> of the site. Back when WXR was first created, this was all you really needed, but much like the rest of the WordPress importers, it hasn&#8217;t kept up with the times. A modern WordPress site isn&#8217;t just the sum of its content: a WordPress site has plugins and themes. It has various options configured, it has huge quantities of media, it has masses of text content, far more than the first WordPress sites ever had.  </p>



<div class=\"wp-block-group alignwide is-style-twentytwentyone-border\"><div class=\"wp-block-group__inner-container\">
<p class=\"has-text-align-center\">Problem Number 2</p>



<p class=\"alignwide has-extra-large-font-size\"><strong>WXR doesn&#8217;t contain a full export of a WordPress site.</strong></p>
</div></div>



<p>In my view, WXR is a solid format for handling exports. An XML-based system is quite capable of containing all forms of content, so it&#8217;s reasonable that we could expand the WXR format to contain the entire site.</p>



<h2>Built for the Future</h2>



<p>If there&#8217;s one thing we can learn from the history of the WordPress importers, it&#8217;s that maintenance will potentially be sporadic. Importers are unlikely to receive the same attention that the broader WordPress Core project does, owners may come and go. An importer will get attention if it breaks, of course, but it otherwise may go months or years without changing.</p>



<div class=\"wp-block-group alignwide is-style-twentytwentyone-border\"><div class=\"wp-block-group__inner-container\">
<p class=\"has-text-align-center\">Problem Number 1</p>



<p class=\"alignwide has-extra-large-font-size\"><strong>We can&#8217;t depend on regular importer maintenance in the future.</strong></p>
</div></div>



<p>It&#8217;s quite possible to build code that will be running in 10+ years: we see examples all across the WordPress ecosystem. Doing it in a reliable fashion needs to be a deliberate choice, however.</p>



<h2>What&#8217;s Next?</h2>



<p>Having worked our way down from the larger philosophical reasons for the importers, to some of the more technically-oriented implementation problems; I&#8217;d like to work our way back out again, focussing on each problem individually. In the following posts, I&#8217;ll start laying out how I think we can bring our importers up to speed, prepare them for the future, and make them available for everyone.</p>



<div class=\"wp-block-group is-style-twentytwentyone-border\"><div class=\"wp-block-group__inner-container\">
<p><em>This post is part of a series, talking about the WordPress Importers, their history, where they are now, and where they could go in the future.</em></p>



<ul><li><em><a href=\"https://pento.net/2021/01/18/wordpress-importers-stating-the-problem/\">Part 1: Stating the Problem</a></em></li><li><em><a href=\"https://pento.net/2021/01/19/wordpress-importers-getting-our-house-in-order/\">Part 2: Getting Our House in Order</a></em></li><li><em><a href=\"https://pento.net/2021/01/20/wordpress-importers-defining-a-schema/\">Part 3: Defining a Schema</a></em></li><li><a href=\"https://pento.net/2021/01/21/wordpress-importers-free-as-in-speech/\"><em>Part 4: Free (as in Speech)</em></a></li></ul>



<p></p>
</div></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 18 Jan 2021 00:25:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Gary\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WPTavern: MapLibre Launches as Official Open Source Successor to Mapbox GL JS\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110489\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:199:\"https://wptavern.com/maplibre-launches-as-official-open-source-successor-to-mapbox-gl-js?utm_source=rss&utm_medium=rss&utm_campaign=maplibre-launches-as-official-open-source-successor-to-mapbox-gl-js\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2864:\"<p>In December, Mapbox shocked its open source contributor community with the news that <a href=\"https://wptavern.com/mapbox-gl-js-is-no-longer-open-source\">Mapbox GL JS version 2.0 would be released under a proprietary license</a>. The JavaScript library powers interactive, customizable vector maps on many high profile websites like CNN, The New York Times, Ancestry, Strava, Shopify, Facebook, and more. Older versions remain open source but Mapbox will only be investing in developing new features for the proprietary version going forward.</p>



<p>Multiple parties started their own forks immediately following Mapbox&rsquo;s announcement. In an effort to avoid fragmentation, the community worked together to merge their ideas under one project. One month later, <a href=\"https://github.com/maplibre/maplibre-gl-js\">MapLibre GL</a> is now the official open source successor to Mapbox GL JS. The project&rsquo;s founders represent a diverse group of companies who relied on the open source software, including MapTiler, Elastic, StadiaMaps, Microsoft, Ceres Imaging, WhereGroup, Jawg, Stamen Design, and more.</p>



<p>&ldquo;In December 2020, Mapbox released the second version of their JavaScript library for publishing maps online,&rdquo; MapTiler founder and CEO Petr Pridal said. &ldquo;However, this time all the new features were overshadowed by a change in the license: previously free as in freedom, it became closed for external contributors and usage was restricted to people with active Mapbox subscriptions. One has to pay even for loading this JavaScript library.&rdquo;</p>



<p>Pridal said the MapLibre project name is a shortened form of &ldquo;Map library restarted (or reinvented),&rdquo; with <em>libre</em> referring to freedom and independence. Its founders agreed that MapLibre should be provider-independent, so developers can load maps from their preferred providers or self-hosted maps.</p>



<p> The community-led fork may also become home to <a href=\"https://github.com/maptiler/maplibre-gl-native\">MapLibre GL Native</a>, as contributors are considering a proposal to put MapTiler&rsquo;s open source fork of Mapbox&rsquo;s mobile map SDKs for Android and iOS under the MapLibre umbrella.</p>



<p>Mapbox is used by <a href=\"https://jetpack.com/support/jetpack-blocks/map-block/\">WordPress.com</a> as well as in Jetpack for the <a href=\"https://jetpack.com/support/jetpack-blocks/map-block/\">Map block</a>. The library is also used in many&nbsp;<a href=\"https://wordpress.org/plugins/search/mapbox/\">plugins</a>&nbsp;on WordPress.org, some with tens of thousands of users. Plugin developers who have integrated Mapbox GL JS version 1.13 or older will want to check out the <a href=\"https://github.com/maplibre/maplibre-gl-js\">MapLibre</a> project as an open source alternative to Mapbox&rsquo;s proprietary 2.0 update. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 15 Jan 2021 23:51:33 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"WPTavern: A Multi-Theme System, the Decade-Long Wait for Grandchild Themes, and Themeless Templates\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110476\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:239:\"https://wptavern.com/a-multi-theme-system-the-decade-long-wait-for-grandchild-themes-and-themeless-templates?utm_source=rss&utm_medium=rss&utm_campaign=a-multi-theme-system-the-decade-long-wait-for-grandchild-themes-and-themeless-templates\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5994:\"<p class=\"has-drop-cap\">Around 2010, child theming had finally caught its stride. Bigger theme shops were starting to take note, and some were implementing advanced parent themes that were meant to serve as a &ldquo;framework&rdquo; for creating child themes. The theme development community hit a bit of a brick wall amid this explosion of child theming. Grandchild themes became a topic of debate.</p>



<p>One of the use cases for child themes was to protect customizations made by end-users. When the parent theme was updated, those changes remained intact within the child theme. Users could get bug fixes and enhancements without worry. It was an ingenious system.</p>



<p>However, another use case for child themes was to create vast customizations of the parent theme. Many of these child themes were marketed and sold to end-users. <em>The problem?</em> There was no way for users to protect their customizations if and when the developer updated the child theme. WordPress had no grandchild theme concept or any other sort of cascading theme system beyond the parent-child relationship.</p>



<p>So, the problem remained. Unsolved.</p>



<p>Some businesses such as StudioPress and its Genesis parent theme thrived over the years with this system. Others moved along. In reality, child theming became a niche feature that WordPress never expanded upon in any meaningful way. Theme authors were left to their own devices. With the arrival of the customizer and the expansion of page builders, code customizations almost disappeared. Most modifications were handled via an interface launched from the WordPress admin. The average user had little need to DIY their way through custom templates. Thus began child theming&rsquo;s drizzle into near obscurity.</p>



<p>Gutenberg&rsquo;s site editor, which will likely land in WordPress this year, had seemed to be the upcoming final blow to the child theming paradigm. Everyone from developers to end-users will be able to roll out custom templates directly from the WordPress admin.</p>



<p>However, should we be rethinking the role of a hierarchical theming system?</p>



<p>Full Site Editing is already introducing an extra level to the hierarchy. Traditionally, WordPress theming had a two-tier template hierarchy. In the future, it will add a tier for user-created templates. If that is possible, why not go ahead and throw in grandchild themes? Or, simply do away with such arbitrary limitations altogether?</p>



<p>A new pull request to the Gutenberg repository essentially <a href=\"https://github.com/WordPress/gutenberg/pull/28131\">creates a multi-theme system</a>. Or, rather, it creates a multi-theme templating system. Aside from the <code>style.css</code>, <code>functions.php</code>, and <code>theme.json</code> files, block-based themes are essentially a collection of templates.</p>



<p>The patch is proposing that users should be able to opt into this multi-template system. They would have the option to keep templates from an old theme around when they switch to a new one. While not currently implemented in the pull request, he also proposes allowing users to clone templates from their old theme.</p>



<p>&ldquo;In recent months, there have been whispers around the future possibility of multiple themes being active, templates being &lsquo;themeless,&rsquo; etc.,&rdquo; wrote the patch creator. &ldquo;This branch is an implementation of that. The idea behind this implementation is there can only be one active theme at a time, but the <code>wp_theme</code> taxonomy can be used to link up individual templates / template parts with one or more themes at a time.&rdquo;</p>



<p>It does not fulfill the dreams of a decade-old grandchild theme system. However, it could provide some precedent for exploring a full hierarchical theme system.</p>



<p>With the simplification and further standardization of how themes work, we should be dusting off old ideas and shoving them into a new light.</p>



<p>Full Site Editing will eventually solve the grandchild theme problem regardless of whether it had intended to. With the new tier of custom user templates, the upgradability problem created years ago will simply disappear. Users will be able to readily update their parent and child themes without fear of losing customizations. WordPress will safely store their custom templates in the database. It will even keep their design changes via the Global Styles system. Maybe, just maybe, child themes will begin to reach their initial height of popularity.</p>



<p>With the proposed system, users could mix and match templates from unrelated themes. If this happens, it begs the question of whether <em>theme</em> templates are even necessary.</p>



<p>Last year, Rich Tabor opened a discussion on the possibility of a <a href=\"https://richtabor.com/the-future-of-wordpress-themes/\">single master theme</a> for WordPress. In that system, WordPress would create a set of base templates. Theme authors could simply override the pieces that they wanted. They could even pare themes down to simple <code>style.css</code> and <code>theme.json</code> files.</p>



<p>That almost seems to be a recipe for bland and boring themes. However, if you couple it with a template directory on WordPress.org similar to what GutenbergHub has <a href=\"https://wptavern.com/gutenberg-hub-launches-landing-page-templates-directory\">already introduced</a>, users could pick and choose the templates they want. It could be both wondrous and disastrous, but I would not mind exploring the idea.</p>



<p>WordPress and its Gutenberg project have a lot of options on the table. Theme building could become interesting in the next year or two.</p>



<p class=\"is-style-highlight\"><strong>Update:</strong><em> some names have been removed from this post at the request of the people in question.  While this is not standard procedure, they were removed because they were not integral to the story in this instance.</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 15 Jan 2021 21:04:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"WPTavern: New Local Blueprint Enables One-Click Setup for Testing Full Site Editing\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110252\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:211:\"https://wptavern.com/new-local-blueprint-enables-one-click-setup-for-testing-full-site-editing?utm_source=rss&utm_medium=rss&utm_campaign=new-local-blueprint-enables-one-click-setup-for-testing-full-site-editing\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5484:\"<p>If you haven&rsquo;t yet tested the Gutenberg team&rsquo;s progress on the full site editing (FSE) project, WordPress developer Carrie Dils has created a <a href=\"https://carriedils.com/full-site-editing-blueprint-for-local/\">blueprint for Local</a> that makes it easy to jump right in. Full site editing is phase 2 on the Gutenberg roadmap and is one of the <a href=\"https://wptavern.com/wordpress-5-7-development-kicks-off-with-focus-on-full-site-editing\">main focuses</a> for WordPress core development in 2021. (Check out <a href=\"https://wptavern.com/what-is-full-site-editing-and-what-does-it-mean-for-the-future-of-wordpress\">What Is Full Site Editing and What Does It Mean for the Future of WordPress</a> for a more in-depth look at why it is critical for end users to provide feedback during its development.)</p>



<p><a href=\"https://localwp.com/\">Local</a> is one of the most popular free development tools for WordPress that allows users to set up new testing sites with one click, along with a host of more advanced features. Blueprints make it possible for users to save any site as a Blueprint so that it can be used as a quick start setup option later. The blueprint includes all files, databases, config files, and Local settings. Dils&rsquo; <a href=\"https://carriedils.com/full-site-editing-blueprint-for-local/\">full site editing blueprint</a> includes the following: </p>



<ul><li><a href=\"https://wordpress.org/plugins/gutenberg/\">Gutenberg</a>&nbsp;plugin (with &ldquo;Full Site Editing&rdquo; experiment enabled)</li><li><a href=\"https://github.com/WordPress/theme-experiments\">WordPress theme experiments</a>&nbsp;(these are themes with support for full site editing) with the Twenty Twenty-One Blocks theme enabled</li><li><a href=\"https://github.com/Automattic/theme-tools/tree/master/gutenberg-test-data\">Gutenberg test data</a>&nbsp;(demo blog posts that use the most common Gutenberg blocks)</li></ul>



<p>Follow Dils&rsquo; instructions for downloading and installing the FSE blueprint on MacOS or Windows. Local does not yet have an easy way for installing and sharing blueprints to other Local users, so you will need to add it to the right place within the application&rsquo;s files. If you find that you don&rsquo;t have a Blueprints folder, it may be because it is hidden or because you have never created a blueprint before. Once the zip file is in the right location, you will see the full site editing blueprint among the advanced options when you set up a new site: </p>



<div class=\"wp-block-image\"><img /></div>



<p>Once your site is set up, you can start exploring the brave new world of full site editing. (Be prepared &ndash; it is far from production ready but FSE is at a critical time in its development where it needs testing from real users to be a success.) The Gutenberg plugin may need to be updated to the latest. Your new site editing playground can be launched from the Site Editor menu item. </p>



<div class=\"wp-block-image\"><img /></div>



<p>On the frontend you will find the Twenty Twenty Blocks theme activated. You can also test using the <a href=\"https://wordpress.org/themes/tt1-blocks/\">Twenty Twenty-One (TT1) Blocks theme</a>, which was added to the WordPress.org Themes directory today, or any of the other experimental block based themes included in the blueprint. Click around, explore the template browser, try editing the template parts, change the global styles, and see how it&rsquo;s coming along. </p>



<div class=\"wp-block-image\"><img /></div>



<p>The current state of full site editing is rough. It&rsquo;s hard to tell a feature from a bug at times, but once you get familiar with navigating it you might consider joining the <a href=\"https://make.wordpress.org/core/2020/12/11/the-fse-outreach-program-is-officially-starting/\">FSE Outreach Experiment</a>. This is an effort to test different aspects of site editing in order to ground the interface in real world feedback as it is developed. For the past few weeks, contributors have been testing the interaction between editing a post versus editing templates. </p>



<p>Anne McCarthy posted the <a href=\"https://make.wordpress.org/test/2020/12/23/fse-program-testing-call-1-template-editing/\">first call for testing</a> to the&nbsp;<a href=\"https://make.wordpress.org/test/\">Make Test</a>&nbsp;blog with instructions for participants. </p>



<blockquote class=\"wp-block-quote\"><p>This call for testing is designed to explore the interaction between the two editing experiences (post vs. template editing) to make sure it&rsquo;s clear when you&rsquo;re editing each, granular saving works properly, etc. Ultimately, being able to edit templates like index, single, or archive directly is a huge leap forward compared to what&rsquo;s been possible in the past! Unlocking this level of customization gives you far more control to build the site you want and this call for testing is to help ensure it&rsquo;s as intuitive as possible.</p></blockquote>



<p>The second testing challenge should be published soon. Anyone can contribute by following along with the test script and leaving comments on the post or <a href=\"https://github.com/WordPress/gutenberg/issues\">logging them as issues on GitHub</a>. Participants are also invited to join the&nbsp;<a href=\"https://make.wordpress.org/core/tag/fse-outreach-experiment/\">#fse-outreach-experiment</a>&nbsp;channel on WordPress Slack for updates or questions regarding testing.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 15 Jan 2021 08:21:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"WPTavern: Show and Hide Content via the Block Visibility WordPress Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110411\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:191:\"https://wptavern.com/show-and-hide-content-via-the-block-visibility-wordpress-plugin?utm_source=rss&utm_medium=rss&utm_campaign=show-and-hide-content-via-the-block-visibility-wordpress-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5736:\"<p class=\"has-drop-cap\">Nick Diego&rsquo;s <a href=\"https://wordpress.org/plugins/block-visibility/\">Block Visibility</a> is not the only plugin to take on the challenge of controlling when blocks are visible on the front end. Other plugins like EditorsKit do a fine job of it. However, Block Visibility is a solution users should not overlook, even if they have already begun testing other options.</p>



<p>Diego first released the plugin in August 2020. Since then, he has added routine updates that have added value without shifting its focus.</p>



<p>One of the biggest reasons to use this plugin is that it is a standalone project. It is purely about doing one thing and doing it well. Its settings are all about giving users complete control over how they want to manage block visibility. From my experience with it, the plugin does its job better than alternatives.</p>



<p>It may not have a large number of installs, but if its five-star rating on WordPress.org is any indication, it at least has a happy user base.</p>



<p>Diego does have plans for a <a href=\"https://www.blockvisibilitywp.com/premium/\">pro add-on</a>. The tentative release date is set for Spring 2021. He seems to be moving forward with that launch after adding some foundational code in the recent version 1.4 release.</p>



<p>&ldquo;As Block Visibility grows, there will be advanced and/or niche functionality that will be useful for certain users,&rdquo; wrote Diego in the <a href=\"https://www.blockvisibilitywp.com/whats-new-in-version-1-4/\">1.4 release announcement</a>. &ldquo;Think integrations with other third-party plugins. There will always be a free version of the plugin but some of these additional features will ultimately be provided by a premium (paid) add-on called Block Visibility Pro.&rdquo;</p>



<p>In my previous job, one of my primary products focused on membership solutions. There is a seemingly endless number of possibilities that users dream up to control content visibility. I have little doubt that a pro add-on is necessary for catching all of the edge cases.</p>



<h2>How the Plugin Works</h2>



<p class=\"has-drop-cap\">Block Visibility is easy to use. End-users click a toggle switch, select from a date-picker, or tick a radio box. Their blocks are shown or hidden on the front end based on their selections. It does not get much simpler than that.</p>



<p>The plugin adds a new &ldquo;Visibility&rdquo; tab for each block, which displays the visibility controls. The exception to this is for inner blocks. For example, the Columns block has controls, but the inner Column blocks do not. However, this can be enabled for inner blocks via the &ldquo;Full Control Mode&rdquo; on the plugin&rsquo;s settings screen.</p>



<p>There are three primary types of options:</p>



<ul><li>Hide the block from everyone.</li><li>Time-based start and stop dates for displaying.</li><li>Visibility by user role.</li></ul>



<img />Block Visibility&rsquo;s controls in the inspector.



<p>Hiding the block from everyone might be useful for users who are testing on a page or for blocks that are a work in progress. Start and stop dates create the potential for drip or trial content on membership-based sites, especially when combined with the role-based visibility options.</p>



<p>These basic options will cover the majority of scenarios that the average user will need them for.</p>



<p>One of the nicer features of the plugin is that it adds a transparent gray overlay, dashed border, and icon to each block that has visibility options set. This is shown when the block is not selected in the editor. It is one of those small touches that make the plugin useful.</p>



<img />Overlay for blocks with visibility options.



<p>There is one confusing piece of the UI. There are two instances where there is a &ldquo;public&rdquo; option. That label immediately makes me think that the block should be visible to everyone. However, reading the description is necessary. These options are for showing content to logged-out users only. I would rather see these two options renamed to &ldquo;logged out&rdquo; for clarity.</p>



<h2>A Promising Future</h2>



<p class=\"has-drop-cap\">While Block Visibility is a solid plugin right now, we are barely scratching the surface of what will be possible in the long run. In version 1.4, released two weeks ago, Diego added preliminary compatibility with Full Site Editing. This means visibility options will no longer be confined to the post or page content.</p>



<p>&ldquo;Once every piece of content on a website is a &lsquo;block,&rsquo; you will be able to easily control the visibility of practically anything on a WordPress website,&rdquo; wrote Diego in the version 1.4 announcement post. &ldquo;From dynamic navigation menus to user specific headers and footers, the possibilities are endless!&rdquo;</p>



<p>Gutenberg&rsquo;s site editor is a beta feature right now, but the plugin&rsquo;s integration seems to already work well. I ran a quick test to show a custom nav menu to shop customers only. I had no problems on my end.</p>



<img />Setting visibility options for a menu in Gutenberg&rsquo;s site editor.



<p>Users will not be limited to such basic needs in the future. Imagine showing ads in a sidebar to logged-out users. Imagine adding a time-sensitive holiday sale banner in the header. Imagine designing a homepage template that displays different content to subscribers vs. visitors.</p>



<p>There are ways to do all of this today by piecing various plugins together, using custom shortcodes, or writing code. However, when an entire site is made of blocks, you only need one method to control anything&rsquo;s visibility. Literally.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 14 Jan 2021 22:23:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"WPTavern: WordPress Proposal To Align Release Cycle With Industry Standard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110354\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:193:\"https://wptavern.com/wordpress-proposal-to-align-release-cycle-with-industry-standard?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-proposal-to-align-release-cycle-with-industry-standard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7102:\"<p class=\"has-drop-cap\">Yesterday, Francesca Marano opened a <a href=\"https://make.wordpress.org/core/2021/01/12/recap-and-proposal-align-the-wordpress-release-cycle-with-the-industry-standard/\">proposal for changing the phases</a> of the core WordPress release cycle. It was a recap of a <a href=\"https://make.wordpress.org/core/2020/10/29/discussion-align-the-wordpress-release-cycle-with-the-industry-standard/\">discussion</a> the began in October 2020. The goal is to align the platform&rsquo;s phases with the larger development industry standard.</p>



<p>Aside from naming, WordPress has mostly followed the software industry in how it tackles its release cycle. Following a well-known convention can make it easier for developers outside of the WordPress ecosystem to transition into it. It would also allow developers to follow cycles of other projects, many of which are WordPress dependencies. This sort of standardization is generally viewed as a good thing throughout the software development world.</p>



<p>Based on the ongoing discussions since October, there is a consensus on renaming the phases to align with the standard. The following table shows what each phase would be renamed to:</p>



<table class=\"has-subtle-pale-blue-background-color has-background\"><thead><tr><th class=\"has-text-align-right text-right\">Phase</th><th>Current Name</th><th>Proposed Name</th></tr></thead><tbody><tr><td class=\"has-text-align-right text-right\"><strong>1</strong></td><td>Planning and securing team leads</td><td>Preliminary Planning</td></tr><tr><td class=\"has-text-align-right text-right\"><strong>2</strong></td><td>Development work begins</td><td>Alpha</td></tr><tr><td class=\"has-text-align-right text-right\"><strong>3</strong></td><td>Beta</td><td>Beta</td></tr><tr><td class=\"has-text-align-right text-right\"><strong>4</strong></td><td>Release candidate</td><td>Release Candidate</td></tr><tr><td class=\"has-text-align-right text-right\"><strong>5</strong></td><td>Launch</td><td>General release</td></tr></tbody></table>



<p>However, this is a two-part proposal. Simply renaming the phases does not change how the release cycle works. To follow the standard strictly, WordPress would need to change when code is committed too.</p>



<h2>How To Handle the Beta Phase</h2>



<p class=\"has-drop-cap\">There is one point of contention with how to handle the Beta stage. The standard calls for no additional code changes other than new bug fixes introduced earlier in the cycle. For the WordPress project, this creates a problem.</p>



<p>WordPress will be 18 years old this year. Over the years, it has racked up a ton of older bugs. These are often fixed later in the cycle, sometimes during the Beta stage. These older bugs may not have been a part of the Preliminary Planning phase, but does that mean they should wait until the next release to go in? Strictly following the proposal, they should be put on hold.</p>



<p>It would also introduce a hard freeze on any enhancements set for the release but incomplete.</p>



<p>&ldquo;I worry that we aren&rsquo;t allowing space for older bugs that aren&rsquo;t specific to the planned features in the release,&rdquo; wrote Josepha Haden in a <a href=\"https://make.wordpress.org/core/2020/10/29/discussion-align-the-wordpress-release-cycle-with-the-industry-standard/#comment-40391\">comment on the initial discussion</a>. &ldquo;I also worry that by calling hard freeze earlier in the process we narrow the window for feature inclusion too much. I don&rsquo;t like limiting ourselves to feature specific bugs right now, since that excludes so many of our volunteer contributors. It&rsquo;s harder to work on features since they are complex and fast-moving, and older bugs present more opportunities for casual contributors.&rdquo;</p>



<p>On the flip side, there is potential that a bug fix could introduce new, unforeseen bugs. The later it is added during Beta, the less likely such bugs are noticed before the General Release phase. Waiting for the next cycle provides more time for testing.</p>



<p>One of the benefits of this system is that almost no new bugs would be created during Beta. This would allow volunteers to shift more efforts to testing and fixing issues that emerged in Alpha.</p>



<p>WordPress has always marched to the beat of its own drum. It can more closely follow standards while breaking free from strict confines when it makes sense to do so for the project. Beta-stage bug fixes not intended for a particular release could be handled on a case-by-case basis. We have people in leadership positions who are capable of making these calls when they arise. With automatic updates for minor releases, I am less concerned about late-stage bugs.</p>



<p>Tonya Mork <a href=\"https://make.wordpress.org/core/2020/10/29/discussion-align-the-wordpress-release-cycle-with-the-industry-standard/#comment-40380\">proposed two solutions</a> for defect work to continue in and around the release cycle. Both would require that WordPress branch off at Beta, providing contributors an avenue to push forward fixing bugs.</p>



<p>The first proposal calls for an earlier feature freeze, providing two or three weeks before Beta 1. This period at the end of the Alpha phase would be solely dedicated to defect work.</p>



<p>The second solution moves this defect work to overlap the previous release&rsquo;s Beta and Release Candidate. This allows work to continue during the time between major releases. It could also shorten the overall major release cycle.</p>



<p>This second solution is also consistent with Joost de Valk&rsquo;s thoughts on handling defect work. &ldquo;I think we should just branch off earlier, and keep trunk open for normal business,&rdquo; <a href=\"https://make.wordpress.org/core/2020/10/29/discussion-align-the-wordpress-release-cycle-with-the-industry-standard/#comment-40393\">he said on the proposal</a>. &ldquo;That way, <em>everything</em> can be worked on all the time, but it won&rsquo;t be included in the next release depending on when you commit it. That&rsquo;s fine, every piece of open source software I know in the world works like that, except for WordPress.&rdquo;</p>



<p>Many plugin and theme developers already find it tough to keep up when changes drop in the Beta or Release Candidate phases. Having a clear and defined point where changes land will benefit the extension ecosystem, also helping end-users in the long run. This second solution would do that.</p>



<p>There is nothing wrong with combining both solutions either.  Since the plan would be to branch off at the Beta phase, the second solution is already in place by the act of branching.  The real discussion is over whether the project should dedicate a block of time during its Alpha stage that focuses purely on bug fixes.</p>



<p>Comments on the proposal are open through January 20 before moving toward a final decision.</p>



<hr class=\"wp-block-separator\" />



<p>The next proposal: <a href=\"https://semver.org/\">semantic versioning</a>, anyone? <em>Anyone? Is this thing on?</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 13 Jan 2021 21:52:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:30;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"WPTavern: WPScan Can Now Assign CVE Numbers for WordPress Core, Plugin, and Theme Vulnerabilities\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110347\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:235:\"https://wptavern.com/wpscan-can-now-assign-cve-numbers-for-wordpress-core-plugin-and-theme-vulnerabilities?utm_source=rss&utm_medium=rss&utm_campaign=wpscan-can-now-assign-cve-numbers-for-wordpress-core-plugin-and-theme-vulnerabilities\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3148:\"<p><a href=\"https://wpscan.com/\">WPScan</a>, a security company that maintains a database of WordPress vulnerabilities, has been officially designated as a CVE (Common Vulnerability and Exposures) Numbering Authority (CNA). The company joins <a href=\"https://cve.mitre.org/cve/request_id.html#cna_participants\">151</a>&nbsp;organizations from&nbsp;<a href=\"https://cve.mitre.org/cve/cna.html#cnas_growth\">25</a>&nbsp;countries that participate in the <a href=\"https://cve.mitre.org/\">CVE Program</a> as CNAs. These organizations are authorized to assign&nbsp;<a href=\"https://cve.mitre.org/about/terminology.html#cve_id\">CVE Identifiers (CVE IDs)</a>&nbsp;to vulnerabilities within their own distinct scopes of work, contributing to CVE&rsquo;s <a href=\"https://cve.mitre.org/cve/\">list</a>&nbsp;of records for publicly known security vulnerabilities.</p>



<p>WPScan&rsquo;s scope includes WordPress core, plugin, and theme vulnerabilities. The company has catalogued more than 21,905 vulnerabilities since 2014 in its database, which it makes available to the community through an API. That API is also used by the <a href=\"https://wordpress.org/plugins/wpscan/\">WPScan Security Scanner</a> plugin, which is installed on 5,000+ websites. </p>



<p>Being designated as a CNA helps WPScan better manage WordPress vulnerabilities by assigning them unique IDs that are recognized across the industry.</p>



<p>&ldquo;Asking MITRE to assign CVEs for each of our vulnerabilities would have been too time consuming in the past,&rdquo; WPScan founder and CEO Ryan Dewhurst said. &ldquo;Although some security researchers will go through this process directly with MITRE, we didn&rsquo;t due to the volume of vulnerabilities we have to manage. And security researchers only requested them themselves very rarely. The new process means that we ourselves can assign CVE numbers directly to vulnerabilities. This will result in many more WordPress related vulnerabilities being assigned CVE numbers.&rdquo;</p>



<p>WPScan is a team of three security researchers who come from penetration testing backgrounds and have worked within security consulting for the past 10 to 15 years. The company started with a simple Ruby script in 2011, which identified vulnerabilities in self-hosted WordPress sites. For the past two years, Automattic has sponsored the company&rsquo;s efforts in maintaining the database, as WPScan has transitioned to become a sustainable business by selling access to its API.</p>



<p>Dewhurst said the company&rsquo;s customers include &ldquo;some of the biggest security plugins and hosting companies in the world,&rdquo; but many of them don&rsquo;t advertise the fact that use a third-party to source the vulnerabilities. Most of WPScan&rsquo;s enterprise customers are security plugins, companies, and hosts that integrate data from the vulnerability database into their own products and services.</p>



<p>&ldquo;Our business is doing well,&rdquo; he said. &ldquo;Right now we are trying to find the right balance between being a business and making money, while also benefiting the community as much as possible.&rdquo; </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 13 Jan 2021 20:52:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:31;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"WPTavern: Google Introduces Performance Report for Google News Publishers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110267\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:191:\"https://wptavern.com/google-introduces-performance-report-for-google-news-publishers?utm_source=rss&utm_medium=rss&utm_campaign=google-introduces-performance-report-for-google-news-publishers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2915:\"<p>Google has <a href=\"https://developers.google.com/search/blog/2021/01/google-news-performance-report\">launched</a> a new Search Console performance report for sites that appear in Google News. Publishers can now track clicks, impressions, and CTR for traffic coming from <a href=\"https://news.google.com/\">news.google.com</a> and the Google News apps for Android and iOS.</p>



<div class=\"wp-block-image\"><img /></div>



<p>The report helps publishers see how often their articles appear to users in Google News and which ones performed the best. It also includes breakdowns for countries, devices, and dates to give publishers a better overall understanding of how visitors are interacting with their content through Google News. Although the date period defaults to the last three months, the data only goes as far back as December 15, 2020.</p>



<p>In the past, publishers had to submit their sites to be eligible for inclusion in Google News but the policy <a href=\"https://support.google.com/news/publisher-center/answer/9607025\">changed in 2019</a>. Sites are now automatically considered for Top stories or the News tab of Search as long as they &ldquo;produce high-quality content and comply with Google News content policies.&rdquo; </p>



<p>This new report does not include stats from the News tab on Google Search. That information was added in July 2020, when Google updated the Performance report section of its Search Console to allow publishers to filter by News. This screen also lets users compare different traffic sources, i.e. Web vs News to see the impact of articles showing up under the News tab.</p>



<div class=\"wp-block-image\"><img /></div>



<p>The new report can be grouped by dimensions to get more specific information with different combinations of date ranges, reader locations, devices, and pages. For example, you can get a detailed look at clicks, impressions, and average CTR on a per country basis. This can also be filtered for one certain article to explore more narrow branches of the content&rsquo;s reach.</p>



<div class=\"wp-block-image\"><img /></div>



<p>Publishers who are using AMP will want to note that this new report includes data from the canonical URL. If you have multiple versions for different devices, the report contains data for both:</p>



<blockquote class=\"wp-block-quote\"><p>Data will only be shown in the property that contains the canonical URL. Therefore, if you have both&nbsp;AMP and desktop versions of a page, the desktop property (which is usually the canonical property) will contain all the data for both AMP and desktop clicks, impressions, and CTR.</p></blockquote>



<p>Google has published a <a href=\"https://support.google.com/webmasters/answer/10083653?hl=en&ref_topic=9384513\">help document</a> with more information on configuring the report, data discrepancies, and how to filter and compare data across groups.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 13 Jan 2021 03:54:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:32;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"WPTavern: Ask the Bartender: How to Build WordPress Themes from Scratch?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110276\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:185:\"https://wptavern.com/ask-the-bartender-how-to-build-wordpress-themes-from-scratch?utm_source=rss&utm_medium=rss&utm_campaign=ask-the-bartender-how-to-build-wordpress-themes-from-scratch\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:9037:\"<img />



<blockquote class=\"wp-block-quote\"><p>I would like to ask, what is the best way to learn to create WordPress themes from scratch? I would like to learn, but there seems to be no comprehensive resource for this.</p><p>Thanks for any help.</p><p>Mark</p></blockquote>



<p class=\"has-drop-cap\">I have been around the WordPress community long enough to remember the days when there were sparse resources available. Those who were just starting out with theme development 15 or more years ago usually resorted to hacking away at an existing WordPress theme. Budding theme authors were building upon the shoulders of those few giants who had already taken the first steps. It was the magic of open-source at work &mdash; development learned through the act of forking.</p>



<p>Maybe it is the way I learned. Perhaps it is part nostalgia for those early days of going down an unknown path and arriving at the other side with a creation of all my own. But, I still believe the best way to learn any type of development cannot be found in documentation or books (<em>says the co-author of a development book</em>).</p>



<p>It is learned through trial and error.</p>



<p>It is learned through hours of mangling a project and not stopping until you fix it.</p>



<p>It is learned through sheer force of will, fueled by some innate passion within you that wants to see a project through. It is frustrating, but you keep going because you are having fun.</p>



<p>The best developers I have had the privilege to work with were not always the most knowledgeable. They were seemingly natural problem solvers. However, they did not awake one day with this ability. They earned it through years of tackling real problems.</p>



<p>First and foremost, the best resource for learning to build themes is an existing WordPress theme. Any of the default Twenty* themes are great starting points. Choose one, start making changes via your code editor, refresh your browser, and see what happens. Read the code. Look for patterns across various files.</p>



<p>You will not learn theme development overnight. It will probably take a few months before you are building basic themes from scratch. It will probably be a year before you are actually good at it. However, everyone is different. The amount of time you put into it is a factor. Your preexisting development knowledge and skills can change that. Sometimes, your innate gifts and ability to learn play into it. But, you will get there with a bit of effort.</p>



<p>I will be honest. The old-timers here in the community, those of us who started out early in WordPress&rsquo;s history, had some help. Tung Do, known as Small Potato at the time, wrote one of the most comprehensive tutorial series on theme development the community has ever had on his now-defunct web design blog. It was an invaluable resource for several years. It was the answer to the missing documentation that everyone was asking for.</p>



<p>Theme development was also far simpler during that time. With a handful of files and templates, you could build something special.</p>



<p>Today, the landscape is much different. If you want to be competitive as a theme shop owner or build custom solutions for clients, you need a broader skillset. Even as a hobbyist, you need to pick up a few more things than you would have a decade and a half ago.</p>



<p>There is good news: the community is teeming with useful resources.</p>



<h2>Traditional vs. Block-Based Themes</h2>



<img />



<p class=\"has-drop-cap\">The theme development market is nearing an inflection point. WordPress will be introducing more and more tools for <a href=\"https://wptavern.com/what-is-full-site-editing-and-what-does-it-mean-for-the-future-of-wordpress\">Full Site Editing</a> in 2021, and this trend will continue in the years beyond. Traditional theme development will be around for a while &mdash; likely a few more years. However, block-based themes are the long-term bet. While there is some crossover between the two, they are entirely different systems.</p>



<p>Realistically, you will need to learn both methods, especially if you have financial motives for going down this journey.</p>



<p>However, you should learn traditional theme development first. This will make it easier to transition down the road. There are far more resources available too.</p>



<p>Another issue with learning block-based theme development as a starting point is that you may not know whether you are at fault if something is broken. The features that make up Full Site Editing are in a rough beta stage. The experience is still a partially broken one. Beginner theme authors should not pile onto what can sometimes be a frustrating experience.</p>



<p>It is time to start reading about Full Site Editing and testing block-based themes like <a href=\"https://wordpress.org/themes/q/\">Q</a> and <a href=\"https://wordpress.org/themes/block-based-bosco/\">Block-Based Bosco</a>. Then, wait for others as they become available in the <a href=\"https://wordpress.org/themes/tags/full-site-editing/\">theme directory.</a></p>



<h2>Resources to Begin Theme Development</h2>



<img />



<p class=\"has-drop-cap\">Many people will point you to starter themes, command-line scripts, and other automated tools for kick-starting your theme development journey. However, there is no substitute for building a solid foundation.</p>



<p>I will assume you have some basic or intermediate HTML and CSS knowledge under your belt. If not, you should learn to build simple web pages first. Again, there is no substitute for building that foundation. It will carry you through as you get into more advanced topics. Knowing some basic PHP helps too. However, you can hack your way through your first WordPress theme with just WordPress &ldquo;template tags,&rdquo; which are technically PHP functions that sound less scary.</p>



<p>Your go-to resource should be the official <a href=\"https://developer.wordpress.org/themes/\">theme developer handbook</a>.</p>



<p>The breadth of knowledge available there was unavailable for those starting in the early days. You can build a WordPress theme from scratch by simply following along each page in the handbook.</p>



<p>While it was written in 2012, ThemeShaper has a <a href=\"https://themeshaper.com/2012/10/22/the-themeshaper-wordpress-theme-tutorial-2nd-edition/\">17-part tutorial series</a> on developing themes from start to finish. With a few exceptions, most of the information in the tutorials is accurate. The underpinning of traditional theme development has not changed much over the years. This includes basic concepts like templates, The Loop, and similar elements.</p>



<p>ThemeShaper&rsquo;s <a href=\"https://themeshaper.com/category/theme-development/\">Theme Development</a> category is a resource any theme author should be subscribed to. The team continues to post up-to-date tutorials on building themes. Recently, they have focused on block-based theme development. I am sure more tutorials are forthcoming as new features related to Full Site Editing unfold.</p>



<p>Of course, search engines are your friends. Run into a problem? I guarantee you are not the first with that specific problem. The solution is documented somewhere across the web.</p>



<p>If you want to begin block-based theme development, you will need to install the <a href=\"https://wordpress.org/plugins/gutenberg/\">Gutenberg</a> plugin for testing. Your resources will be limited. You will need to be a pioneer, mowing a path for others to follow. It will be a rough trek, but it also offers adventures that others have not taken.</p>



<p>WordPress&rsquo;s block editor handbook has a <a href=\"https://developer.wordpress.org/block-editor/tutorials/block-based-themes/\">guide on creating block-based themes</a>. It makes some assumptions about your knowledge level in terms of theme development. Carolina Nymark, one of the Themes Team representatives, has a site called <a href=\"https://fullsiteediting.com/\">Full Site Editing</a>. It includes an extensive course that is worth taking. There is also the <a href=\"https://github.com/WordPress/theme-experiments\">Theme Experiments</a> repository for testing what some people are currently building.</p>



<p>My strongest recommendation is to learn through trial and error while using documentation as a backup when you get stuck. Start playing around with <a href=\"https://wordpress.org/themes/twentytwenty/\">Twenty Twenty</a> or <a href=\"https://wordpress.org/themes/twentytwentyone/\">Twenty Twenty-One</a>, the two most recent default WordPress themes. Make changes. Get yourself in trouble and break things. Learn by getting yourself out of whatever hole you have dug. Every failure is part of your path toward success. Most of all, enjoy it.</p>



<p>Now, I will throw this question out to our readers, many of whom are theme authors themselves.  Will you share you tips, tricks, and resources for someone who is just starting to build themes?</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 12 Jan 2021 21:58:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:33;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Matt: Iceland Film\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=53458\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://ma.tt/2021/01/iceland-film/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:359:\"<p>I wanted to share with you all a short film I made with the help of Stephen Bollinger, with videos I made a few years ago on a photography trip to Iceland with <a href=\"https://om.co/\">Om</a> and <a href=\"https://twitter.com/markkawano\">Mark</a>. I hope it provides five minutes of serenity in your day.</p>



<div class=\"wp-block-embed__wrapper\">

</div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 12 Jan 2021 21:46:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:34;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"WPTavern: Gutenberg’s Faster Performance Is Eroding Page Builders’ Dominance\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110192\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:193:\"https://wptavern.com/gutenbergs-faster-performance-is-eroding-page-builders-dominance?utm_source=rss&utm_medium=rss&utm_campaign=gutenbergs-faster-performance-is-eroding-page-builders-dominance\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6016:\"<p>WordPress&rsquo; block editor, colloquially still widely known as Gutenberg, is making inroads into the segment of users who have heavily relied on page builders for years. For the most part, <a href=\"https://publishpress.com/blog/gutenberg/growth-pagebuilders/\">page builder plugins have either declined in growth or stagnated in 2020</a>, with the exception of Elementor. In contrast, block collections with page builder features are gaining more users. Performance is becoming an important factor in this migration.</p>



<p>In a post titled &ldquo;<a rel=\"noreferrer noopener\" href=\"https://gutenbergtimes.us1.list-manage.com/track/click?u=e3062ef0fb204dbbc2135b555&id=47325f0912&e=68ffa9a210\" target=\"_blank\">Damn.&nbsp;Gutenberg&nbsp;Smokes Elementor</a>,&rdquo; Kyle Van Deusen published benchmarks from his experience building a simple landing page using Elementor and then Gutenberg. </p>



<p>&ldquo;Like any Elementor user, I&rsquo;ve become increasingly anxious about the future of Elementor and just how bloated it is,&rdquo; Van Deusen said. &ldquo;I think Google PageSpeed Insights agrees.&rdquo;</p>



<p>After recreating the same design with Gutenberg and <a href=\"https://generateblocks.com/\">GenerateBlocks</a>, Van Deusen saw a small difference in <a href=\"https://gtmetrix.com/\">GTMetrix</a> scores. </p>



<div class=\"wp-block-image\"><img />GTMetrix scores: Elementor vs Gutenberg</div>



<p>He found the most profound difference when testing with Google&rsquo;s <a rel=\"noreferrer noopener\" href=\"https://developers.google.com/speed/pagespeed/insights/\" target=\"_blank\">PageSpeed Insights</a>, where Elementor scored 46% on mobile, and 83% on desktop.</p>



<p>&ldquo;Because I&rsquo;ve had such poor luck getting any kind of decent scores with Elementor sites (especially on mobile), I&rsquo;ve given up using this tool,&rdquo; Van Deusen said. &ldquo;Not because it&rsquo;s not a valuable metric (in fact, it may be the most valuable since this is how Google sees things), but because there wasn&rsquo;t much I could do about it.&rdquo;</p>



<p>In contrast, the page built with Gutenberg gave him a 94% score on mobile and a 99% on desktop.</p>



<div class=\"wp-block-image\"><img /></div>



<p>&ldquo;In terms of performance, straight out of the box; Gutenberg absolutely smokes Elementor,&rdquo; Van Deusen said. &ldquo;However, each time I&rsquo;ve taken Gutenberg for a spin, I&rsquo;ve left frustrated. As soon as I feel like I&rsquo;m getting the hang of it, eventually the wheels come off and I&rsquo;m back to installing Elementor.</p>



<p>&ldquo;But when your PageSpeed Insights scores go from 46% to 94%, it&rsquo;s time to perk up and pay attention.&rdquo;</p>



<p>Van Deusen said it took him more time to recreate the design in Gutenberg and he had trouble with mobile views. At the moment, he doesn&rsquo;t see switching as an advantageous move for his business.</p>



<p>&ldquo;While I think we can conclusively say, at least for performance, Gutenberg is the clear winner &mdash; it&rsquo;s just not at a point where a guy like me can jump ship,&rdquo; Van Deusen said.</p>



<p>&ldquo;Gutenberg is fun to play with, and I enjoy dreaming of the day when it&rsquo;s viable for me&mdash; but I like to put food on my table. Elementor still helps me do that more efficiently.&rdquo;</p>



<p>In another experiment, WordPress developer Munir Kamal <a href=\"https://gutenberghub.com/gutenberg-vs-elementor-html-bloat/\">rebuilt Elementor&rsquo;s homepage in Gutenberg</a> to compare the HTML markup both page builders generate. The page built with Elementor includes 356 div&rsquo;s in the markup vs 77 for Gutenberg. Kamal found that Elementor generated 796 lines of code vs Gutenberg&rsquo;s 206 lines, resulting in a difference of 99kb vs 28kb respectively. </p>



<p>In August 2020, DearHive, the makers of the DearFlip WordPress plugin, left CodeCanyon to sell plugins from their own site. DearHive&rsquo;s company site was built with Elementor, but suddenly Google ranking mattered for their product site now that they were selling independently from CodeCanyon. Deepak Ghimire, a software developer at the company, cited performance as the chief issue that impacted their ranking and drove them to <a href=\"https://medium.com/wpunbox/our-move-from-elementor-to-gutenberg-why-we-left-elementor-b525b4caa3da\">switch to Gutenberg</a>.</p>



<p>&ldquo;Our page speed went from 83 with Elementor to 98 with Gutenberg,&rdquo; Ghimire said. </p>



<p>Page builder plugins may still have more features at this point in time, but performance is becoming a critical consideration for those who are doing business online. In May 2021, Google plans to&nbsp;<a href=\"https://wptavern.com/google-search-to-add-page-experience-to-ranking-signals-in-may-2021\">introduce a new ranking signal</a>&nbsp;for Search, based on page experience as measured by&nbsp;<a href=\"https://web.dev/vitals/#core-web-vitals\">Core Web Vitals</a>&nbsp;metrics. Performance is an important part of delivering the kind of scores necessary to pass the Core Web Vitals assessment. This ranking signal update from Google may compel even more site owners to migrate away from slow page builders.</p>



<p>For the past two years, WordPress users have been asking if Gutenberg will replace page builders. It looks more and more likely if the most popular ones remain bloated alternatives and the smaller ones keep on the same trajectory of attrition. It won&rsquo;t happen overnight, but it is bound to accelerate when full-site editing makes its debut in WordPress core. </p>



<p>For those who build websites for clients, the best way to future-proof your skills is to learn how to build pages within the framework of the block editor and, if you can, learn how to build custom blocks. It&rsquo;s also a good time to be experimenting with different block collections to streamline your setup so that you don&rsquo;t have to sacrifice high performance in order to build sites efficiently.  </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 12 Jan 2021 04:15:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:35;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Matt: Thirty-seven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=53415\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://ma.tt/2021/01/thirty-seven/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2689:\"<p>I turn 37 today. I look around and I feel incredibly lucky to be writing this after a topsy-turvy year. I have health. I have friends whom I love. These are all good reasons to feel optimistic about the future. A few unconnected thoughts today:</p>



<p>My father had me when he was exactly 13,300 days old, and this year I passed that number of rotations of the Earth.</p>



<p>It&#8217;s hard to plan when so much is changing, so resolutions this year haven&#8217;t felt the same. But in times like these it&#8217;s even more important to plan for the long-term. A look back, once a year, is enough to remind of what remains.</p>



<p>I&#8217;m so thankful for the internet. It&#8217;s where I learned and practiced my trade. It&#8217;s where I connect every day with the most interesting and eclectic group of people I could imagine, a modern day Florence during the Renaissance. I hope to make a lot more internet and enable others to do the same.</p>



<p>Many years ago I said &#8220;Technology is best when it brings people together.&#8221; This quote has <a href=\"https://www.google.com/search?q=technology+is+best+when+it+brings+people+together&tbm=isch\">taken on a life of its own on motivational posters and images</a>. When I first said it I think I had in mind WordCamps and meetups and other physical gatherings; this year it transformed for me seeing how technology brought together those separated by the pandemic. This year has appeared divisive, so it&#8217;s easy to overlook how many times people came together. It&#8217;s like the old saying, it&#8217;s not how many times you fall, it&#8217;s how many times you get up. Fall thirty-six times, get up thirty-seven.</p>



<p>All birthday posts: <a href=\"https://ma.tt/2003/01/bday/\">19</a>, <a href=\"https://ma.tt/2004/01/so-im-20/\">20</a>, <a href=\"https://ma.tt/2005/01/hot-barely-legal-matt/\">21</a>, <a href=\"https://ma.tt/2006/01/matt-22/\">22</a>, <a href=\"https://ma.tt/2007/01/twenty-three/\">23</a>, <a href=\"https://ma.tt/2008/01/twenty-four/\">24</a>, <a href=\"https://ma.tt/2009/01/twenty-five/\">25</a>, <a href=\"https://ma.tt/2010/01/twenty-six/\">26</a>, <a href=\"https://ma.tt/2011/01/twenty-seven/\">27</a>, <a href=\"https://ma.tt/2012/01/twenty-eight/\">28</a>, <a href=\"https://ma.tt/2013/01/twenty-nine/\">29</a>, <a href=\"https://ma.tt/2014/01/matt-3-0/\">30</a>, <a href=\"https://ma.tt/2015/01/thirty-one/\">31</a>, <a href=\"https://ma.tt/2016/01/thirty-two/\">32</a>, <a href=\"https://ma.tt/2017/01/thirty-three/\">33</a>, <a href=\"https://ma.tt/2018/01/thirty-four/\">34</a>, <a href=\"https://ma.tt/2019/01/thirty-five/\">35</a>, <a href=\"https://ma.tt/2020/01/thirty-six/\">36</a>, 37.</p>



<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 12 Jan 2021 03:07:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:36;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"WPTavern: EatsWP Brings Virtual Restaurant Menus to the WordPress Block Editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110174\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:201:\"https://wptavern.com/eatswp-brings-virtual-restaurant-menus-to-the-wordpress-block-editor?utm_source=rss&utm_medium=rss&utm_campaign=eatswp-brings-virtual-restaurant-menus-to-the-wordpress-block-editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5639:\"<p class=\"has-drop-cap\">Yesterday, Jack Kitterhing launched <a href=\"http://eatswp.com/\">EatsWP</a>, his new restaurant-related WordPress plugin. It is a menu creation system that works in the block editor. It also has a built-in QR code feature to work with customers&rsquo; phones.</p>



<p>Kitterhing is the Product Manager at LearnDash. He is also the founder of Immerseus, a shop that builds plugins for the learning management system. He is now extending his reach with the founding of EatsWP. He contracted out the development work to a private freelancer with who he regularly works.</p>



<p>&ldquo;Apart from that, it&rsquo;s just me on this project,&rdquo; said Kitterhing. &ldquo;My other business, I have five full-time employees, and so if required, one of those could be brought over for support. We, myself and my friend, took this idea to launch in under a month, which I&rsquo;m very pleased with considering that Christmas was in the middle as well.&rdquo;</p>



<p>Kitterhing decided to build this plugin based on what he was seeing with small restaurant owners he knew. Some of the issues facing these single-location restaurants are with their physical menus.</p>



<p>&ldquo;It&rsquo;s expensive to update them or make any changes as it requires a whole new print run,&rdquo; he said. &ldquo;By having a digital menu, they can update in minutes and generate a new QR code print. Then combine that with the current world situation, it also isn&rsquo;t very healthy to have everyone touching physical menus, so digital menus made more sense than ever.&rdquo;</p>



<p><a href=\"https://eatswp.com/pricing/\">Pricing for the plugin</a> begins at $37 per year and increases based on the number of sites the user wants updates and support on.  Kitterhing also offers a custom menu design and setup tier.</p>



<h2>How the Plugin Works</h2>



<img />Editing an EatsWP menu item in the block editor.



<p class=\"has-drop-cap\">At the moment, EatsWP is a simple affair. The plugin does not offer hundreds of options or every feature imaginable for a menu-type of plugin. It is a 1.0. However, for the features it does provide, it does them reasonably well. Kitterhing is off to a good start. He has set a foundation, and the only way to go from here is up.</p>



<p>Where the plugin tends to shine is with its primary features, which are its array of blocks. Users begin by adding the Eats Menu block. From there, they have a selection of inner blocks they can place within the menu:</p>



<ul><li>Item With Picture</li><li>Item With Picture and Addons</li><li>Item Without Picture</li><li>Item Without Picture and Addons</li><li>Eats Section Heading</li></ul>



<p>In reality, most of the blocks are just prearranged sets of existing core WordPress blocks. They provide structure and loads of color options. Plus, end-users can click a button to add a &ldquo;New&rdquo; or &ldquo;Popular&rdquo; tag to their menu items. It is a nice touch.</p>



<p>The color options offer some customizability. In the long term, users will likely want more design options. However, it may be prudent for the plugin author to follow core&rsquo;s lead here and implement such options as they become available in the block editor API.</p>



<p>The one missing feature that should be available now is support for wide and full alignments. Kitterhing assured me this would land in the first quarter of this year.</p>



<p>On top of the plugin&rsquo;s blocks, EatsWP allows end-users to generate a QR code for the page their restaurant&rsquo;s menu is on. When a customer scans the QR code with their phone, the page then opens.</p>



<p>&ldquo;The QR code generation is more straightforward than most people expect,&rdquo; said Kitterhing. &ldquo;We&rsquo;re using a well-known QR code generation library. You then simply select the page your menu is on, generate the QR code, print it off, or show it on your website and you&rsquo;re ready to go.&rdquo;</p>



<h2>The Future of EatsWP</h2>



<p class=\"has-drop-cap\">On the EatsWP website, Kitterhing lightheartedly writes that &ldquo;delicious desserts&rdquo; are coming soon. This includes WooCommerce integration, recipes, and other secret features. Integrating with WooCommerce could open a new avenue for restaurant owners to explore as part of their checkout process.</p>



<p>&ldquo;I&rsquo;m hoping that WooCommerce support will be coming Q1 this year,&rdquo; said Kitterhing. &ldquo;As I&rsquo;m sure you can imagine, it&rsquo;s reasonably technically challenging to incorporate this in a user-friendly way. The goal is to have all the connections and product creation actually done within the block editor interface. So someone wouldn&rsquo;t have to go off to WooCommerce to set a product and come back as that&rsquo;s rather long-winded. I&rsquo;m excited to show everyone!&rdquo;</p>



<p>It will be interesting to watch how this integration unfolds in the coming months. Menus are a solid starting point, but having a payment option is necessary in a world with more people are ordering online. This is especially true in the Covid-era where contactless forms of payment are becoming the norm for takeout. Restaurants need simple solutions that they are not hacking together from multiple, non-integrated sources.</p>



<p>&ldquo;The goal within the next 12 months is to turn EatsWP into everything that a restaurant needs to offer a minimal-contact experience for customers,&rdquo; said Kitterhing. &ldquo;Many restaurants don&rsquo;t have websites either, so I&rsquo;m looking into a SaaS option where I&rsquo;d host the menu/site for the restaurant.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 11 Jan 2021 21:46:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:37;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"WPTavern: WordPress Community Team Proposes Using a Decision Checklist to Restart Local Events\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110022\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:233:\"https://wptavern.com/wordpress-community-team-proposes-using-a-decision-checklist-to-restart-local-events?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-community-team-proposes-using-a-decision-checklist-to-restart-local-events\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4502:\"<img />photo credit: <a href=\"https://stocksnap.io/photo/checklist-goals-TBJ9OPDGMK\">Glenn Carstens-Peters</a>



<p>WordPress&rsquo; Community Team has been <a href=\"https://wptavern.com/wordpress-community-team-discusses-return-to-in-person-events\">discussing the return to in-person events</a> since early December 2020, and has landed on an idea that would allow local meetup organizers to determine readiness <a href=\"https://make.wordpress.org/community/2021/01/07/proposal-decision-making-checklist-for-safe-in-person-meetups/\">using a COVID-19 risk-assessment checklist</a>. This would enable organizers to restart meetups when it is safe for their communities, instead of applying a blanket global policy.</p>



<p>Countries like Australia, New Zealand, The Bahamas, Iceland, and Vietnam, are a few examples of locations that are doing a decent job containing the virus. In contrast, the United States logged more than 4,000 coronavirus deaths in a single day this week, pushing the daily average to over 2,700. While the situation remains bleak for many areas of the world, vaccines are rolling out to vulnerable populations, albeit slowly and with a few snags.</p>



<p>In the previous discussion that happened in early December, WordPress lead developer Dion Hulse shared some feedback from Australian organizers who have been eager to restart their meetups.</p>



<p>&ldquo;One of the problems faced in Australia (and probably NZ &amp; Taiwan too) has been the blanket worldwide restrictions companies have put in place,&rdquo; Hulse said. &ldquo;Australia/NZ have been lucky, the pandemic has been successfully contained &ndash; Australia has seen less than 30k cases this year, and NZ 2k cases. To put that in context, the USA has recorded more (detected) cases in 3 hours today than Australia did all year, and more in 30 minutes than NZ.&rdquo;</p>



<p>Hulse said a few Australian meetup groups were denied the go-ahead for restarting because of the global restrictions, which has &ldquo;led to the abandonment of meetups once again (as online meetups have simply not worked here, as most people can still go out in person, so there&rsquo;s been no major push from most Australians to the online platforms like elsewhere).&rdquo;</p>



<p>The Community Team&rsquo;s proposal for a checklist takes these more unique situations into consideration and allows organizers to move forward in areas where public health measures have adequately curbed the spread of the virus. A few example checklist items include the following:</p>



<ol><li>Is your country&rsquo;s (or state&rsquo;s) average positivity rate over the past 28 days under 4%?</li><li>In the past 28 days, has your country or area&rsquo;s&nbsp;<a href=\"https://en.wikipedia.org/wiki/Basic_reproduction_number\">basic reproduction number</a>&nbsp;stayed under 1?</li><li>In the past 14 days, have there been under 50 new cases per 100,000 people reported?</li><li>Does your local government allow for in-person events?</li><li>If there is a cap on the number of people who can meet at a time, will you as an organizer follow this guideline?</li></ol>



<p>Contributor feedback so far includes recommendations for dealing with violations of the guidelines and assessing the need for contact tracing in case meetup attendees are exposed during an event. Cami Kaos recommended that the team share a list of locations that have already been vetted using the checklist and have not met requirements.</p>



<p>&ldquo;My hope is that this would reduce a lot of duplicated time and effort for areas that we already know aren&rsquo;t yet, by the standards we&rsquo;re setting, safe,&rdquo; Kaos said. &ldquo;It would save time and disappointment for organizers hoping to meet in person and also contributor time and energy for those deputies who will vet the applications to hold in-person events.&rdquo;</p>



<p>Since the virus is mutating and countries are adapting in different ways, the situation can change rapidly, so organizers would need to be prepared to roll back to online events if conditions for safe meetups deteriorate. WordCamps are still out of the question for the time being, but the Community Team is seeking feedback on the <a href=\"https://make.wordpress.org/community/2021/01/07/proposal-decision-making-checklist-for-safe-in-person-meetups/\">proposal</a> by January 15, 2021, including additions to the checklist and recommendations for public health resources that could aid in guiding the process.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 09 Jan 2021 16:50:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:38;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"Matt: Autonomous and Beautiful Home Devices\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=53404\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://ma.tt/2021/01/autonomous-and-beautiful-home-devices/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1532:\"<p>Of all the smart home upgrades I&#8217;ve made, replacing all my regular smoke detectors with Nest Protects (Google&#8217;s smoke detector) has been the one that I regret the most.</p>



<p>I don&#8217;t really need a smart smoke detector. It doesn&#8217;t need to talk, connect to wifi, and cost hundreds of dollars. I don&#8217;t need it integrated with my Google account which is impossible to share, so I need to be personally involved to replace one.</p>



<p>But other smoke detectors are just so unsightly, and the Nest is light years ahead of the competition from a design standpoint.</p>



<img />



<p>There&#8217;s such an opportunity for something that looks as good as the Nest, but doesn&#8217;t require two-factor authentication to replace. I didn&#8217;t want to call it dumb but beautiful, so let&#8217;s say &#8220;autonomous and beautiful&#8221; appliances and home devices. I still want it to be smart, but if you&#8217;re going to have the risk profile of a device that connects to the internet, it needs to be worth it, like <a href=\"https://www.brilliant.tech/\">Brilliant</a>, <a href=\"https://www.sonos.com/\">Sonos</a>, smart TVs, or connected cameras.</p>



<p>I&#8217;m becoming more wary of any hardware that requires an app, just because of the natural decay of non-SaaS and non-open source software. <a href=\"https://www.vanmoof.com/en-US\">Van Moof bikes</a> are beautiful, but will they still connect well when iOS 24 is out and Bluetooth has been removed from iPhones for security reasons?</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 08 Jan 2021 23:45:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:39;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"WPTavern: Blocked-Based Version of Twenty Twenty-One Nearing Readiness for the Theme Directory\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110087\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:233:\"https://wptavern.com/blocked-based-version-of-twenty-twenty-one-nearing-readiness-for-the-theme-directory?utm_source=rss&utm_medium=rss&utm_campaign=blocked-based-version-of-twenty-twenty-one-nearing-readiness-for-the-theme-directory\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5300:\"<img />



<p class=\"has-drop-cap\">Twenty Twenty-One Blocks, now renamed to TT1 Blocks, is inching its way toward the WordPress theme directory. Kjell Reigstad mentioned the prospect in this week&rsquo;s <a href=\"https://make.wordpress.org/themes/2021/01/06/block-based-meeting-notes-january-6/\">block-based themes meeting</a>. Contributors to the theme, which is part of the <a href=\"https://github.com/WordPress/theme-experiments\">Theme Experiments</a> project, have pushed some much-needed code updates to the repository.</p>



<p><a href=\"https://github.com/WordPress/theme-experiments/tree/master/tt1-blocks\">TT1 Blocks</a> is the block-based version of the Twenty Twenty-One theme. Its goal is to provide a version of the original theme that works with Full Site Editing (FSE), currently only available through the Gutenberg plugin.</p>



<p>FSE needs more testers. And, testers need themes that will enable the site editor in Gutenberg. Currently, there are only two WordPress themes, <a href=\"https://wptavern.com/q-first-fse-wordpress-theme-now-live\">Q</a> and <a href=\"https://wptavern.com/block-based-bosco-second-full-site-editing-theme-lands-in-the-wordpress-directory\">Block-Based Bosco</a>, in the directory that support the site editor. <a href=\"https://wptavern.com/armando-wordpress-theme-provides-insight-into-the-current-state-of-full-site-editing\">Armando</a> should join them shortly. If a user attempts to find one via the <a href=\"https://wordpress.org/themes/tags/full-site-editing/\">FSE filter</a>, they will get no results, as pointed out by Gary Taylor in a <a href=\"https://wptavern.com/gutenberg-9-7-improves-user-experience-updates-reusable-blocks-and-brings-page-templates-to-fse-themes#comment-359503\">recent comment</a>. This seems to be an oversight by the theme authors and should be corrected.</p>



<p>With most block-based themes relegated to a few GitHub repositories, it does not bode well if no one can find themes to test the most important set of features coming to WordPress in 2021. Users should be able to easily install an FSE-ready theme today.</p>



<p>&ldquo;It has been brought up that it may be easier for people to test and contribute to full site editing if Twenty Twenty-One blocks was available in the WordPress theme directory,&rdquo; wrote Themes Team representative Carolina Nymark in a <a href=\"https://github.com/WordPress/theme-experiments/issues/140\">ticket about renaming TT1 Blocks</a>.</p>



<p>TT1 Blocks is something that feels more official. While third-party block-based themes are needed, the <em>officialness</em> of something from core contributors gives more users a sense of trust. Plus, it would be easy for someone with .ORG administrator privileges to stick it to the top of the theme directory&rsquo;s featured page to get more eyes on it. <em>Doing this with a third-party theme would unleash a hoard of developers who want the same treatment for their themes.</em></p>



<p>The prospect of the theme coming to the directory is something the WordPress project needs.</p>



<p>The volunteers who have been chipping away at this TT1 Blocks have turned a <a href=\"https://wptavern.com/twenty-twenty-one-blocks-theme-launching-as-a-separate-project\">bare-bones theme</a> into something closer to the original Twenty Twenty-One. There are still some leaps remaining to get it to where it needs to be. Much is this rests in the Gutenberg development team&rsquo;s hands. There are currently over a <a href=\"https://github.com/WordPress/theme-experiments/projects/1#column-12084948\">dozen blockers</a> identified by the Theme Experiments project that need to be resolved in the Gutenberg plugin first.</p>



<img />Single post in the site editor with TT1 Blocks



<p>There are multiple open tickets on the <a href=\"https://github.com/WordPress/theme-experiments/projects/1\">project board</a> for theme developers who are looking for a way to contribute. This is an opportunity to learn more about block-based themes and pay it forward.</p>



<p>At the moment, I am not-so-patiently awaiting the release of TT1 Blocks to the theme directory.</p>



<p>There are days when I wonder if there is a final destination, some light at the end of this never-ending tunnel that leads to block-based themes being the norm. I get overexcited about each new project. I quickly test pull requests and updates on the handful of repositories I am watching, hoping for a glimpse of something spectacular.</p>



<p>Part of this excitement is because I designed and developed WordPress themes for around 15 years in some form or fashion. Today, I am no longer in the design and development game. I must live vicariously through the people who are putting untold hours into this grand experiment. I get to tell their stories, which has its own rewards.</p>



<p>I also know that this sort of development is a slog. Everyone has big ideas, but the real world calls for slow, steady, and dedicated work. Often it is thankless.</p>



<p>When I saw the mere mention of TT1 Blocks potentially coming to the theme directory, it added a bit of spark to an otherwise rough few days. I wanted to end this particular week with something hopeful. And, testing out the latest work those volunteers have put into TT1 Blocks has done just that.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 08 Jan 2021 23:12:39 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:40;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"WPTavern: JetBrains Denies Being Under Investigation for SolarWinds Attack\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110028\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:193:\"https://wptavern.com/jetbrains-denies-being-under-investigation-for-solarwinds-attack?utm_source=rss&utm_medium=rss&utm_campaign=jetbrains-denies-being-under-investigation-for-solarwinds-attack\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4847:\"<p>JetBrains, makers of Phpstorm, one of the most popular IDEs for PHP developers, has published a <a href=\"https://blog.jetbrains.com/teamcity/2021/01/statement-on-the-story-from-the-new-york-times-regarding-jetbrains-and-solarwinds/\">statement</a> denying any involvement in the SolarWinds attack, which compromised multiple US federal agencies and private companies. The company stated that it has not been the subject of an official investigation:</p>



<blockquote class=\"wp-block-quote\"><p>JetBrains has not taken part or been involved in this attack in any way. SolarWinds is one of our customers and uses TeamCity, which is a Continuous Integration and Deployment System, used as part of building software. SolarWinds has not contacted us with any details regarding the breach and the only information we have is what has been made publicly available.</p></blockquote>



<p>This statement contradicts a recent New York Times <a href=\"https://www.nytimes.com/2021/01/06/us/politics/russia-cyber-hack.html\">article</a> that claimed unspecified officials were investigating the company&rsquo;s TeamCity continuous integration software as a possible entry point for the attack: </p>



<blockquote class=\"wp-block-quote\"><p>By compromising TeamCity, or exploiting gaps in how customers use the tool, cybersecurity experts say the Russian hackers could have inconspicuously planted back doors in an untold number of JetBrains&rsquo; clients. Because TeamCity is so widely deployed, experts said, it is imperative to determine whether its software contains a vulnerability, or if attackers exploited TeamCity customers via stolen passwords or gaps in unpatched, outdated software.</p></blockquote>



<p>The New York Times did not specify which officials and &ldquo;cybersecurity experts&rdquo; were the source for this information but claimed that SolarWinds was also investigating the software internally. A <a href=\"https://web.archive.org/web/20210106195835/https://www.nytimes.com/2021/01/06/us/politics/russia-cyber-hack.html\">previous version</a> of the article referred to JetBrains as &ldquo;an obscure software company,&rdquo; which <a href=\"https://twitter.com/razvanbunea/status/1347254615616729090\">ruffled the feathers</a> of the company&rsquo;s most ardent customers. SolarWinds told both the Times and <a href=\"https://www.wsj.com/articles/solarwinds-hack-breached-justice-department-systems-11609958761\">The Wall Street Journal</a> that it has not confirmed a definitive link between JetBrains and the breach of its own software.</p>



<p>A&nbsp;<a rel=\"noreferrer noopener\" href=\"https://www.dni.gov/index.php/newsroom/press-releases/press-releases-2021/item/2176-joint-statement-by-the-federal-bureau-of-investigation-fbi-the-cybersecurity-and-infrastructure-security-agency-cisa-the-office-of-the-director-of-national-intelligence-odni-and-the-national-security-agency-nsa\" target=\"_blank\">joint statement</a> from the FBI, the Cybersecurity and Infrastructure Security Agency (CISA), the Office of the Director of National Intelligence (ODNI) and the National Security Agency (NSA) released this week points to Russia as the origin of the attacks: </p>



<blockquote class=\"wp-block-quote\"><p>This work indicates that an Advanced Persistent Threat (APT) actor, likely Russian in origin, is responsible for most or all of the recently discovered, ongoing cyber compromises of both government and non-governmental networks. At this time, we believe this was, and continues to be, an intelligence gathering effort. We are taking all necessary steps to understand the full scope of this campaign and respond accordingly.</p></blockquote>



<p>Phpstorm is widely used among WordPress developers, especially since&nbsp;<a rel=\"noreferrer noopener\" href=\"https://wptavern.com/phpstorm-8-released-with-full-wordpress-support\" target=\"_blank\">version 8 added official support for WordPress</a> in 2014. JetBrains users took to Twitter with questions and concerns about claims that the company was under investigation. Today, JetBrains published another <a href=\"https://blog.jetbrains.com/blog/2021/01/07/an-update-on-solarwinds/\">update</a> that clarifies its previous statement. It states that the company&rsquo;s IDEs are standalone tools with no relation to TeamCity and that there is no evidence that any of their servers or tools have been tampered with. </p>



<p>JetBrains is organizing an independent security audit of TeamCity and has promised a transparent report of any vulnerabilities found that may have led to a breach.</p>



<p>&ldquo;For over 20 years, one of our pillars has been to be transparent, honest, and truthful with our customers, and nothing hurts us more than seeing unfounded allegations that damage our reputation and instill doubt on our customers,&rdquo; JetBrains CEO Maxim Shafirov said.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 07 Jan 2021 23:12:39 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:41;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:114:\"WPTavern: Gutenberg 9.7 Improves User Experience, Updates Reusable Blocks, and Brings Page Templates to FSE Themes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=110018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:269:\"https://wptavern.com/gutenberg-9-7-improves-user-experience-updates-reusable-blocks-and-brings-page-templates-to-fse-themes?utm_source=rss&utm_medium=rss&utm_campaign=gutenberg-9-7-improves-user-experience-updates-reusable-blocks-and-brings-page-templates-to-fse-themes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7906:\"<p class=\"has-drop-cap\">Gutenberg 9.7 <a href=\"https://make.wordpress.org/core/2021/01/07/whats-new-in-gutenberg-6-january/\">landed yesterday</a> with several updates and improvements. Users should expect to see changes to the interface for block variations, transforms, and patterns. Reusable blocks are being worked on after what seemed to be a hiatus. Developers can also now add custom page templates to their block-based WordPress themes.</p>



<p>This release had the fewest number of bug fixes I have seen in a while. The development team only pushed eight fixes into the update, which could signal that things were more stable than usual after the 9.6 release a couple of weeks ago.</p>



<p>Most of the work in 9.7 dealt with new features and enhancements. As expected, Full Site Editing got its fair share of time. However, even this seemed dialed back a bit for this release. Many of the updates are to the post-editing interface.</p>



<h2>User Experience Improvements</h2>



<p class=\"has-drop-cap\">The team pushed out several updates to how features work in the editor. Some of them might seem minor but improve the overall editor experience.</p>



<p>Block variations received a welcome enhancement. Variations are when one underlying block is used to create multiple variations of the same block. For example, the Embed block has YouTube, Twitter, and other variations. In past versions, the block inspector in the sidebar and block navigation would show the generic name, icon, and description. However, Gutenberg 9.7 will now show the <a href=\"https://github.com/WordPress/gutenberg/pull/27469\">details for the variation</a> in use.</p>



<img />YouTube variation for the Embed block.



<p>When transforming a block, <a href=\"https://github.com/WordPress/gutenberg/pull/27861\">users can see a preview</a> of what the block will look like. This is a small improvement. However, it might save a few headaches when before deciding to transform one block into another.</p>



<img />Preview when transforming Quote block into a Pullquote.



<p>Gutenberg 9.6 introduced a <a href=\"https://wptavern.com/gutenberg-9-6-introduces-drag-and-drop-blocks-and-global-inheritance-for-the-query-block\">drag-and-drop feature</a> for blocks in the inserter. The team has now <a href=\"https://github.com/WordPress/gutenberg/pull/27927\">extended that feature to block patterns</a>. This is just another rung on the ladder for those looking for more drag-and-drop capabilities.</p>



<h2>Reusable Blocks Updated</h2>



<p class=\"has-drop-cap\">It has been a while since I tested reusable blocks. The feature has seemingly taken a backseat to other, newer features in the past year or so. It never felt much better than an initial prototype. There is still no way to easily manage them unless you know where to look. However, it appears the Gutenberg development team is <a href=\"https://github.com/WordPress/gutenberg/pull/27887\">actively developing</a> this almost-forgotten feature.</p>



<p>Users can expect more in future releases. &ldquo;Based on these changes, the UI for reusable blocks is most likely going to see some iterations on the upcoming weeks,&rdquo; wrote Riad Benguella in the announcement post.</p>



<p>I ran an initial test to see what the feature looked like in Gutenberg 9.7. After clicking the &ldquo;Add to reusable blocks&rdquo; button, the editor did a quick flash. Then, a notification appeared at the bottom of the screen that the reusable block had been created. Because I did not have my block options sidebar panel open at the time, I saw no way to edit the reusable block&rsquo;s title. My immediate thought was that the team took an already half-baked feature and made it exponentially worse.</p>



<p>Upon further digging, I found that users can edit the reusable block&rsquo;s title in the block options sidebar. However, the team did not stop there. They added several improvements to the feature.</p>



<img />Editing the reusable block name in the sidebar panel.



<p>Reusable blocks are now editable within the post editor itself. Users can drag an image out of the block, for example. The inspector sidebar is available for the inner blocks. Reusable blocks now look and feel like any other part of the editor. Any edits will reflect across all instances of the reusable blocks on the site.</p>



<p>The big difference is in how they are saved.</p>



<img />Saving a reusable block along with the post.



<p>Reusable blocks are now a part of the &ldquo;multi-entity&rdquo; save system. When clicking the editor&rsquo;s update button, users will have an option to save the entire post and/or individual reusable blocks.</p>



<h2>Custom &ldquo;Page&rdquo; Templates for FSE Themes</h2>



<p class=\"has-drop-cap\">Block-based <a href=\"https://github.com/WordPress/gutenberg/pull/27778\">themes now support</a> what has been traditionally known as page templates. All post types are technically supported with the feature. However, the team seems to be sticking with the &ldquo;page&rdquo; terminology after some discussion.</p>



<p>It took some digging because there is no existing documentation and the original example in the ticket did not reflect the end result of the code that passed. However, I managed to suss out how the feature works. For theme authors who want to test this feature, use the following example code of adding a &ldquo;contact&rdquo; template. Place it at the root level of your theme&rsquo;s <code>experimental-theme.json</code> file. You will also need to accompany this with a <code>block-templates/contact.html</code> template in your theme.</p>



<pre class=\"wp-block-code\"><code>\"pageTemplates\": {
        \"contact\": {
                \"title\": \"Contact\",
                \"postTypes\": [
                        \"page\"
                ]
        }
}</code></pre>



<p>This feature does not do anything particularly groundbreaking right now. It merely adds the custom template to the drop-down select on the edit post/page screen. It is the equivalent of the current page template system available to traditional themes.</p>



<img />Selecting a custom page template from FSE theme.



<p>While this is a nice development, traditional page templates may not make much sense in the block theming paradigm. There is no way to change the visual output of the page in the editor based on the selected template &mdash; users must still view the page on the front end to see the result of its application. The block system is about instant visual feedback. Page templates need to be rethought for the new era.</p>



<p>&ldquo;In terms of UI and integration with the template mode, we can do a lot more than the old select box,&rdquo; said Benguella, who was the developer behind the pull request. &ldquo;We can show a preview for templates and offer a modal or something like that for folks to pick from&hellip;We&rsquo;d need some design thinking and explorations there. This PR just sets the technical requirements to make it work.&rdquo;</p>



<p>Much, but not all, of what page templates were needed for in the past decade can now be replaced by block patterns.</p>



<p>In the long term, I would rather see page templates that behaved more like predesigned block layouts. This is how block templates for custom post types work today. However, that is on the post-type level rather than the level of the individual post.</p>



<p>Traditional page templates are dated. Themes rarely offer more than a few. One to remove the sidebar. One to move the sidebar to the left or right. Another to make the page content area wider.</p>



<p>What is clear is that we need more exploration on what page templates of the future will look like. Are they necessary in the block system? Are there better ways of handling what traditional themes are using them for? How will they work in an interface that needs visual feedback?</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 07 Jan 2021 22:34:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:42;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:123:\"WPTavern: All in One SEO Plugin Turns on Automatic Updates without Notifying Users, Removes Functionality in Latest Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=109933\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:289:\"https://wptavern.com/all-in-one-seo-plugin-turns-on-automatic-updates-without-notifying-users-removes-functionality-in-latest-release?utm_source=rss&utm_medium=rss&utm_campaign=all-in-one-seo-plugin-turns-on-automatic-updates-without-notifying-users-removes-functionality-in-latest-release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4960:\"<p>Buried in the <a href=\"https://aioseo.com/changelog/\">changelog</a> of a series of minor releases that dropped before the Christmas holiday, <a href=\"https://wordpress.org/plugins/all-in-one-seo-pack/\">All in One SEO</a> plugin users were given the surprise gift of automatic updates. After a seemingly endless run of releases (12 updates during a span of six weeks at the end of 2020), the plugin&rsquo;s developers decided to change its auto update policy so that it defaults to &ldquo;on.&rdquo; The plugin is installed on more than 2 million WordPress sites.</p>



<p>Version 4.0.8, released December 21, 2020, flipped on automatic updates without notifying users of the change. Despite having auto updates turned off for the plugin, many users discovered the change when they were notified by email that their sites had been updated without permission. </p>



<div class=\"wp-block-image\"><img /></div>



<p>Frustrated users took to the plugin&rsquo;s support forums to report the issue and find out how it was possible.</p>



<p>&ldquo;Multiple sites have updated to 4.0.11 without my permission and while all auto updates are disabled,&rdquo; one user <a href=\"https://wordpress.org/support/topic/auto-update-29/#post-13837970\">said</a>. &ldquo;I/we do not want to hear that &lsquo;it shouldn&rsquo;t happen&rsquo; and we are looking into.</p>



<p>&ldquo;Your once reliable plugin has destroyed hundreds of pages of social meta data on multiple sites, broken layout (and this after I fixed the problems and told you last week, I will be disabling all updates).&rdquo;</p>



<p>Others commented on the issue, citing problems with a previous major release as the source of many bugs that followed.</p>



<p>&ldquo;The rollout of version 4, and auto-updating without any chance to backup first was a blunder by AIOSEO,&rdquo; plugin user Derek Haines <a href=\"https://wordpress.org/support/topic/sudden-rush-of-5-star-reviews/\">said</a>. &ldquo;It has cost me hours, days, and now weeks to fix the problems caused.&rdquo;</p>



<p>The All in One SEO plugin team <a href=\"https://wordpress.org/support/topic/auto-update-29/#post-13840599\">apologized</a> for the inconvenience users experienced but said they could not reproduce it on their end. The plugin&rsquo;s settings page has a toggle for auto updates but it is just a wrapper for WordPress&rsquo; auto updater.</p>



<p>&ldquo;I just wanted to give you an update and let you know that we&rsquo;ve decided to remove our own auto-update functionality all together since this issue seems to be happening on a limited amount of websites and we aren&rsquo;t able to reproduce it on our end,&rdquo; Arnaud Broes said.</p>



<p>The problem was also <a href=\"https://www.facebook.com/groups/advancedwp/permalink/3806581632737356\">discussed</a> in the Advanced WordPress Facebook group.</p>



<p>&ldquo;All In One SEO Pack apparently turned auto updates on, and in a few cases I found sites where those updates failed,&rdquo; Eric Karkovack reported. &ldquo;I had no idea they were turned on and in one case a site was inaccessible.&rdquo;</p>



<p>Karkovack noted that there was only a small mention in the changelog, despite the plugin liberally using the dashboard notification UI for sales.</p>



<p>William Earnhardt, WordPress core contributor and developer at Bluehost, offered some insight as someone who has worked on core as well as plugins installed on a massive scale.</p>



<p>&ldquo;In my experience if you are weighing the two options, auto-updates prevent significantly more issues and support requests than they create,&rdquo; Earnhardt said. &ldquo;So I&rsquo;m strongly in the camp of enabling them by default, with a mechanism for preventing or disabling for those who prefer (core makes this possible with filters and now with per-plugin UI). </p>



<p>&ldquo;I think when making these decisions, we as developers have to consider what is best for the broadest number of users and be realistic about the type of users we have. If a user is already not updating plugins regularly, it is unlikely they are going to have the awareness to flip a toggle to turn auto-updates on. So opt-in makes them mostly useless.&rdquo;</p>



<p>Earnhardt agreed that notifying users of the change would have been a good idea, but admin notices are already &ldquo;frequently abused and quite noisy.&rdquo;</p>



<p>&ldquo;It would likely be missed if not persistent, but really should only show after the update and then go away,&rdquo; he said. &ldquo;Is that enough when combined with a note in the changelog? Probably for most, but I&rsquo;m sure some would disagree.&rdquo;</p>



<p>As promised nine days ago, All in One SEO&rsquo;s developers have now removed the functionality from the plugin in its first update of 2021, version 4.0.12 released today. It is noted in the changelog: &ldquo;Fixed: Completely remove auto updates wrapper to let WordPress handle updates.&rdquo; </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 06 Jan 2021 23:47:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:43;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"WPTavern: Liquid Web Acquires The Events Calendar WordPress Plugin From Modern Tribe\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=109909\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:213:\"https://wptavern.com/liquid-web-acquires-the-events-calendar-wordpress-plugin-from-modern-tribe?utm_source=rss&utm_medium=rss&utm_campaign=liquid-web-acquires-the-events-calendar-wordpress-plugin-from-modern-tribe\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4092:\"<p class=\"has-drop-cap\">Liquid Web <a href=\"https://ithemes.com/the-events-calendar-plugin-joining-liquid-web-family/\">announced today</a> via the iThemes blog that it acquired The Events Calendar from Modern Tribe. The acquisition gives them ownership of the plugin, its suite of event-related plugins, and the team behind it all.</p>



<p>&ldquo;We&rsquo;ve acquired all the associated plugins, including Event Tickets, etc.,&rdquo; said Matt Danner, the COO at iThemes. &ldquo;They identify under the single umbrella of The Events Calendar as a team, so we&rsquo;ve continued to position the team that way.&rdquo;</p>



<p>As part of the acquisition, the 50+ employees from The Events Calendar plugin team are now a part of the Liquid Web family. They will continue working on the plugin and its related products. Zach Tirrell <a href=\"https://theeventscalendar.com/blog/news/the-events-calendar-joins-the-liquid-web-family/\">announced on The Events Calendar blog</a> that he would remain at the helm and that the team structure was not changing.</p>



<p>The remaining 74 employees of Modern Tribe will continue working on the agency&rsquo;s other projects, including clients like Microsoft and Harvard University. Reid Peifer, the Creative Director at Modern Tribe, teased potential future projects in his <a href=\"https://tri.be/blog/the-events-calendar-joins-the-liquid-web-family/\">announcement post</a>. &ldquo;We can&rsquo;t help but make things, so you may see a few surprises from us in the coming months as well.&rdquo;</p>



<p><a href=\"https://wordpress.org/plugins/the-events-calendar/\">The Events Calendar plugin</a> on WordPress.org currently has over 800,000 active installs with an average rating of 4.4 out of 5 stars. Modern Tribe launched the plugin in 2011 and has continued to build a larger product line and customer base around it over the last decade.</p>



<p>For existing customers, it should be business as usual. Nothing has changed about who is currently developing The Events Calendar. The website is still a separate entity, and billing will remain the same.</p>



<p>The acquisition is mere months after iThemes, owned by Liquid Web, <a href=\"https://wptavern.com/ithemes-enters-the-wordpress-membership-plugin-market-acquires-restrict-content-pro\">purchased Restrict Content Pro</a> (RCP), a membership plugin. While RCP continues to have an independent site, users can snag it with one of the plugin bundles directly from the iThemes website.</p>



<p>However, The Events Calendar will be wholly independent of iThemes. Customers hoping to see a similar bundle with The Events Calendar will be out of luck.</p>



<p>&ldquo;The RCP acquisition was done under the iThemes brand,&rdquo; said Danner. &ldquo;We brought that team into our team, and the membership product is a key part of how we&rsquo;re positioning iThemes. The Event Calendar&rsquo;s acquisition was done under the larger Liquid Web brand. Their team is coming into Liquid Web alongside iThemes as part of the bigger software division. While we definitely think there are future opportunities to collaborate between our teams (which could include bundles of products from both teams), their products are not going to become part of the iThemes product line.&rdquo;</p>



<p>One of the biggest remaining questions is whether the separate teams will eventually create integrations between The Events Calendar and RCP. There are multiple reasons event organizers might want to restrict content based on memberships, especially when it comes to virtual events. Danner did not give up any specific plans in his response.</p>



<p>&ldquo;We&rsquo;re very excited to explore all the opportunities to integrate our products,&rdquo; he said. &ldquo;I think there are some great opportunities for RCP and TEC to work more closely together, and both customer bases have requested deeper integration between the two. This acquisition was a perfect fit from so many angles. The people, the values of the team, and the products all align with what we&rsquo;re building at Liquid Web.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 06 Jan 2021 22:21:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:44;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"Akismet: Version 4.1.8 of the Akismet WordPress Plugin is Now Available\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"http://blog.akismet.com/?p=2109\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"https://blog.akismet.com/2021/01/06/version-4-1-8-of-the-akismet-wordpress-plugin-is-now-available/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:667:\"<p>Version 4.1.8 of <a href=\"http://wordpress.org/plugins/akismet/\">the Akismet plugin for WordPress</a> is now available. It contains the following changes:</p>
<ul>
<li>Removal of a deprecated jQuery function.</li>
<li>A fix for a bug causing some data to be excluded from API calls when marking a comment as spam or not-spam.&nbsp; This should improve spam detection accuracy.</li>
</ul>
<p>To upgrade, visit the Updates page of your WordPress dashboard and follow the instructions. If you need to download the plugin zip file directly, links to all versions are available in <a href=\"http://wordpress.org/plugins/akismet/\">the WordPress plugins directory</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 06 Jan 2021 17:01:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Christopher Finke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:45;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"Matt: Farnam Street and Postlight\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=53384\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"https://ma.tt/2021/01/farnam-street-and-postlight/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2137:\"<p>I recorded two interviews very far apart from each other, but which have surprisingly both come out today. The first is for one of my favorite sites on the web, <a href=\"https://fs.blog/\">Farnam Street</a>. I was honored to be <a href=\"https://fs.blog/knowledge-project/\">episode 100 on their Knowledge Project podcast</a>. Knowledge Project is probably one of the podcasts I&#8217;ve listened to the most since it started. Please check out their other guests as well, they really do have the most interesting conversations with the most interesting folks.</p>



<p>Shane and I cover turnarounds, how environment affects performance, pros and cons of distributed work, uncovering your lacuna, mental models, and patterns of decision making.</p>



<div class=\"wp-block-embed__wrapper\">

</div>



<p>On a completely different vein, I did a deep geek-out on technology and content management systems with <a href=\"https://ginatrapani.org/\">Gina Trapani</a> and <a href=\"https://www.ftrain.com/\">Paul Ford</a>, two of my favorite technologists, <a href=\"https://postlight.com/podcast/wordpress-and-beyond-with-matthew-mullenweg\">on the Postlight podcast</a>. We covered a lot of tech history, my thoughts on Chromium and Mozilla&#8217;s Gecko engine, structured data, Gutenberg, and a lot more. If you&#8217;re a developer or a long-time WordPress community member you&#8217;ll enjoy this one, but it might be esoteric or technical if you&#8217;re not immersed in this world. Here&#8217;s a Spotify embed of the episode:</p>



<div class=\"wp-block-embed__wrapper\">

</div>



<p>In both we do touch on my idea that, on a long enough timeline, the survival rate for all proprietary software drops to zero. (Hat tip to Fight Club.) Proprietary software is an evolutionary dead end. You can think of open source packages like <a href=\"https://en.wikipedia.org/wiki/Gene-centered_view_of_evolution\">genetic alleles that have a higher fitness function</a>, and eventually become the fittest organism. The longer I spend watching mega-trends in technology, the more I see that pattern everywhere, from encyclopedias to cryptocurrencies.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 05 Jan 2021 23:51:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:46;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"WPTavern: Block System Will Create More Commercial Opportunities for WordPress Theme Authors\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=109904\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:229:\"https://wptavern.com/block-system-will-create-more-commercial-opportunities-for-wordpress-theme-authors?utm_source=rss&utm_medium=rss&utm_campaign=block-system-will-create-more-commercial-opportunities-for-wordpress-theme-authors\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6978:\"<p class=\"has-drop-cap\">Ten years ago, a potential WordPress theme buyer might stumble upon a site like ThemeForest. The themes on the site would primarily tout the hundreds of shortcodes they included. These shortcodes would allow the user to build anything they wanted with simple BBCode-like brackets around some tag or another.</p>



<p>The practice was not limited to ThemeForest. Nearly every theme development company at the time &mdash; and they were sprouting up by the dozens a decade ago &mdash; needed to compete in the same arena. Despite all their faults (never mind that no user could reasonably remember hundreds of them), shortcodes topped the list of features.</p>



<p>Today, the landscape is much different. In part powered by page builders like Elementor and Beaver Builder, themes are more apt to offer pre-built design options. Gone are the days when users must painstakingly fill their pages with shortcode soup manually. At the click of a button, their theme will automate the design of their homepage for them. The user merely needs to fill in the content. At the click of another button, the user gets a contact or services page. A restaurant owner might get a fully-laid out food menu. A new online shop owner can get a full set of pre-built WooCommerce products by importing their theme&rsquo;s demo content.</p>



<p><em>Customizability</em> is the name of the game. This has not really changed over the years, but the methods for getting there have.</p>



<p>When perusing commercial theme shops today, the common thread is the multitude of demos. These demos showcase the various layouts the user can have if they just fork over the $50 or $60 for access. There are themes with over 500 demos.</p>



<p>Some themes market hundreds of templates or dozens of pre-built, one-click website designs. At the end of the day, it is all about making the user&rsquo;s site look a certain way without the hassle of hours of work.</p>



<p>The problem with traditional theming is that all of these themes are built with non-standard solutions. This is no fault of the theme authors. They had to build or use third-party systems where WordPress had failed. Elementor has standardized this to some degree &mdash; many commercial theme shops fully support it, often as the default experience. However, it still only represents a fraction of the market and is not a part of the core platform.</p>



<p>WordPress is still catching up to the dream that the premium marketplace has already been capitalizing on.</p>



<p>However, WordPress can do this better in the long term and level the playing field for many other theme developers. We are on the verge of true one-click solutions from the core platform. It will be a tough run for the next year, but the theme shops that adopt the block system the soonest stand the most to gain.</p>



<h2>What the System Offers</h2>



<p class=\"has-drop-cap\">If you have ever installed themes that offered dozens of header designs, the experience has likely been hit or miss. Most such themes require users to go through dozens of options fields in the customizer or &mdash; <em>yikes!</em> &mdash; a custom-built options page that looks nothing like the WordPress interface. While there are simpler solutions that some theme authors have created, WordPress has never had a built-in way of allowing users to do this.</p>



<p>Enter template parts made out of blocks.</p>



<p>Themes Team rep Carolina Nymark showcased just how simple this is with the upcoming site editor. Her <a href=\"https://wptavern.com/armando-wordpress-theme-provides-insight-into-the-current-state-of-full-site-editing\">Armando theme</a> offers three custom header templates.</p>



<img />Selecting a header template with the Armando theme.



<p>The system is far from ready. There are missing features that we will likely not see for a while. For example, there&rsquo;s currently no way to categorize or otherwise group all the header templates just yet. Users can just as easily replace the header with a footer template.</p>



<p>However, this is an important step forward.  The theme author did not write any complicated PHP or JavaScript. There was no need to build a custom options panel or fields. No third-party system was warranted. The developer created the templates, and they became instantly available through the site-editing interface. The theme author&rsquo;s responsibility went back to simply designing. The user has access through a standardized interface.</p>



<p>If theme authors want to offer hundreds of switchable templates, they can. If they want to add two or three while upselling the others, they can do that too.</p>



<p>Now, expand upon this idea with other types of templates. These can be a footer, sidebar, homepage, or any template. The commercial applications are endless. Theme authors can offer commercial themes or upsells with far less work than ever before.</p>



<p>The possibilities do not end with templates. Block patterns are another viable feature to commercialize. As shown with the Genesis Blocks plugin, its &ldquo;layout selector&rdquo; offers various patterns to quickly insert into the post content.</p>



<img />Slate collection from the Genesis Blocks plugin.



<p>Genesis Blocks even offers collections of these patterns that share a similar design aesthetic. In other words, these are essentially pattern categories.</p>



<p>This is an easy path forward for theme authors who are looking to upsell. Build one or two categories of patterns. Periodically bring in new groups of patterns for users who want a fresh look without changing themes.</p>



<p>Gutenberg Hub already provides hundreds of <a href=\"https://wptavern.com/gutenberg-hub-launches-collection-of-100-block-templates\">templates and patterns</a>, filling a void that is currently missing from the theme ecosystem. The site offers convenient solutions, but something is missing: they are not tied into the theme&rsquo;s design. Forward-thinking theme authors should already be building competing solutions that offer all the same templates and patterns that match their themes.</p>



<img />Gutenberg Hub&rsquo;s landing page &ldquo;templates&rdquo; (patterns).



<p>A year or two ago, there was some rumbling about the block editor leading to the death of WordPress theming. <em>Traditional</em> theming will trickle into nonexistence in the coming years. Of course, there will be pockets of holdouts, but the future is about one-click solutions. And, WordPress is setting the stage for all users to have this ability at their fingertips. The theme shops that recognize this the soonest will profit from it the most. Everyone else will be fighting for the scraps they leave behind.</p>



<p>It is not time to abandon traditional theming or forgo page-builder support. However, it is time for themers to begin rolling out block patterns and to start outlining, testing, and building block-based themes.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 05 Jan 2021 22:34:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:47;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"WordPress.org blog: The Month in WordPress: December 2020\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=9508\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://wordpress.org/news/2021/01/the-month-in-wordpress-december-2020/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:11600:\"<p>We bid goodbye to 2020 in style with the release of WordPress 5.6 and the launch of Learn WordPress. But these weren’t the only exciting updates from WordPress in December. Read on to learn more!</p>



<hr class=\"wp-block-separator\" />



<h2>WordPress 5.6 is here</h2>



<p>The latest major WordPress release,<a href=\"https://wordpress.org/news/2020/12/simone/\"> version 5.6</a> “Simone”, came out on December 8. The release ships with a new default theme called <a href=\"https://wordpress.org/themes/twentytwentyone/\">Twenty Twenty One</a>. It offers a host of features, including:</p>



<ul><li>Greater layout flexibility</li><li>More block patterns</li><li>Video captioning support</li><li>Auto-updates</li><li>Beta-compatibility for PHP 8.0</li><li>Application password support for the REST API</li><li>Updates to jQuery</li></ul>



<p>In addition, WordPress 5.6 is now available in 55 languages. You can find more information about the release in the <a href=\"https://make.wordpress.org/core/2020/11/20/wordpress-5-6-field-guide/\">field guide</a>, and you can update to the latest version directly from your WordPress dashboard or by <a href=\"https://wordpress.org/download/\">downloading</a> it directly from WordPress.org. A total of 605 people hailing from 57 different countries contributed to the development of WordPress 5.6. <a href=\"https://profiles.wordpress.org/audrasjb/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>audrasjb</a> has <a href=\"https://jeanbaptisteaudras.com/en/2020/12/wordpress-5-6-core-stats-contributions-by-country-company/\">compiled many more stats like that</a>, showing what a tremendous group effort this was—they’re well worth a read!</p>



<p>Want to contribute to upcoming WordPress releases? Join the WordPress <a href=\"https://wordpress.slack.com/archives/C02RQBWTW\">#core</a> channel on the <a href=\"https://make.wordpress.org/chat/\">Make WordPress Slack</a> and follow the <a href=\"https://make.wordpress.org/core/\">Core team blog</a> to learn the <a href=\"https://make.wordpress.org/core/2020/12/21/wordpress-5-7-planning-roundup/\">latest on WordPress 5.7</a>, which is <a href=\"https://wordpress.org/about/roadmap/\">slated to be out by March 9, 2021</a>. The Core team hosts weekly chats on Wednesdays at <a href=\"https://www.timeanddate.com/worldclock/fixedtime.html?hour=5&min=00&sec=0\">5 a.m.</a> and <a href=\"https://www.timeanddate.com/worldclock/fixedtime.html?hour=20&min=00&sec=0\">8 p.m.</a> UTC.</p>



<h2>Watch the State of the Word 2020 recording</h2>



<p><a href=\"https://wordpress.org/news/\">State of the Word 2020</a>, the annual keynote address delivered by WordPress co-founder Matt Mullenweg, was streamed online for the first time on December 17. It was followed by a live Q&amp;A from community members all across the world. You can find the stream recording on <a href=\"https://www.youtube.com/watch?v=QI3qCoiuG3w\">YouTube</a>, <a href=\"https://www.facebook.com/WordPress/videos/1281447442248369\">Facebook</a>, and <a href=\"https://twitter.com/i/broadcasts/1dRKZNvnrmdKB\">Twitter</a>. The <a href=\"https://wordpress.tv/2020/12/17/matt-mullenweg-2020-state-of-the-word/\">State of the Word</a> video and the <a href=\"https://wordpress.tv/2020/12/17/matt-mullenweg-2020-state-of-the-word-qa/\">Q&amp;A session</a> are also available on WordPress.tv.&nbsp;</p>



<h2>Learn WordPress has launched</h2>



<p>Learn WordPress, a new free, on-demand WordPress learning resource, launched officially on December 15. It offers <a href=\"https://learn.wordpress.org/workshops/\">workshops</a>, <a href=\"https://learn.wordpress.org/lesson-plans/\">lesson plans</a>, quizzes, and <a href=\"https://learn.wordpress.org/courses/\">courses</a> for anyone interested in publishing with, building for, or contributing to WordPress. WordPress enthusiasts can also <a href=\"https://www.meetup.com/learn-wordpress-discussions/\">participate in discussion groups</a> focused on specific topics to learn with and from each other.</p>



<p>Want to participate in Learn WordPress? <a href=\"https://learn.wordpress.org/contribute/\">Here are four ways you can do so</a>! Additionally, contributors have <a href=\"https://make.wordpress.org/training/2020/12/03/learn-wordpress-blue-sky-thinking/\">launched a discussion</a> on the future of <a href=\"https://learn.wordpress.org/\">Learn WordPress</a>—feel free to share your thoughts in the comments. To help promote Learn WordPress, check out the <a href=\"https://make.wordpress.org/marketing/\">Marketing Team</a>’s <a href=\"https://make.wordpress.org/marketing/2020/12/09/help-us-promote-learn-wordpress/\">materials</a>, which detail a <a href=\"https://make.wordpress.org/marketing/2020/12/09/help-us-promote-learn-wordpress/\">range of fun and creative ways</a> to share this new resource.</p>



<h2>Give feedback on the Full Site Editing project</h2>



<p>Contributor teams have kicked off the <a href=\"https://make.wordpress.org/core/2020/12/11/the-fse-outreach-program-is-officially-starting/\">Full Site Editing (FSE) outreach program</a> for anyone who is building or maintaining a WordPress site so that they can give feedback on the upcoming <a href=\"https://make.wordpress.org/design/handbook/focuses/full-site-editing/\">FSE feature</a> that will be part of Gutenberg Phase 2. Your feedback will go a long way in improving FSE user flows. To participate, <a href=\"https://make.wordpress.org/test/2020/12/23/fse-program-testing-call-1-template-editing/\">check out the initial testing call</a> on the <a href=\"https://make.wordpress.org/test/\">Make/Test blog</a> and join the <a href=\"https://make.wordpress.org/core/tag/fse-outreach-experiment/\">#fse-outreach-experiment</a> Slack channel.<br /><br />Want to follow updates on the FSE project? Check out <a href=\"https://make.wordpress.org/core/2020/05/20/ways-to-keep-up-with-full-site-editing-fse/\">this blog post</a>. You can find <a href=\"https://make.wordpress.org/core/2020/12/10/status-check-site-editing-and-customization/\">2020 updates to the FSE project</a> in the Make/Core blog.</p>



<h2>BuddyPress 7.0 “Filippi” and 7.10 are now available</h2>



<p><a href=\"https://buddypress.org/2020/12/buddypress-7-0-0-filippi/\">BuddyPress version 7.0</a> went live on December 9. Its features include:&nbsp;</p>



<ul><li>New administration screens to manage Member and Group Types</li><li>New BP blocks for posts and pages</li><li>A default profile image for network sites</li><li>Improved BuddyPress Noveau support for the Twenty Twenty One theme.&nbsp;</li></ul>



<p>A BuddyPress maintenance release (<a href=\"https://buddypress.org/2020/12/buddypress-7-1-0-maintenance-release/\">version 7.1</a>) launched on December 21.&nbsp;</p>



<p>Want to provide feedback or suggestions for BuddyPress? Share your comments on the announcement posts for <a href=\"https://buddypress.org/2020/12/buddypress-7-0-0-filippi/\">7.0</a> or <a href=\"https://buddypress.org/2020/12/buddypress-7-1-0-maintenance-release/\">7.1</a>. If you find a bug, please report it in the <a href=\"https://buddypress.org/support/\">support forums</a>.&nbsp;</p>



<h2>Gutenberg 9.5 and 9.6 released</h2>



<p>The Core team launched <a href=\"https://make.wordpress.org/core/2020/12/02/whats-new-in-gutenberg-2-december/\">version 9.5</a> and <a href=\"https://make.wordpress.org/core/2020/12/23/whats-new-in-gutenberg-23-december/\">9.6</a> of Gutenberg last month. Both versions include several improvements to FSE flows, bug fixes, and feature upgrades. Version 9.5 introduces features like full height alignment and support for font sizes in the code block. Version 9.6 includes features like the ability to drag blocks from the inserter and a vertical layout for buttons.&nbsp;</p>



<p>Want to get involved in building Gutenberg? Follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, contribute to <a href=\"https://github.com/WordPress/gutenberg/\">Gutenberg on GitHub</a>, and join the <a href=\"https://wordpress.slack.com/archives/C02QB2JS7\">#core-editor</a> channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading</h2>



<ul><li>The Community team <a href=\"https://make.wordpress.org/community/2020/12/01/discussion-how-can-the-wordpress-community-return-to-hosting-safe-in-person-events/\">kicked off a discussion</a> about what the WordPress Community can do to host safe, in-person events again, in light of the continuing pandemic. </li><li>The Polyglots team published its <a href=\"https://make.wordpress.org/polyglots/2020/12/30/polyglots-team-end-of-year-post-2020/\">end-of-year post</a>, along with the <a href=\"https://make.wordpress.org/polyglots/author/evarlese/\">results of its 2020 translator survey</a>.</li><li><a href=\"https://sevilla.wordcamp.org/2020/\">WordCamp Sevilla 2020</a> was held online from December 26-29. You can catch the recorded livestream playback on <a href=\"https://www.youtube.com/c/wordpresssevilla/live\">YouTube</a>. Videos of the event will <a href=\"https://wordpress.tv/event/wordcamp-sevilla-2020/\">soon be available on WordPress.tv</a>.</li><li>WordPress project executive director <a href=\"https://profiles.wordpress.org/chanthaboune/\">Josepha Haden</a> and project co-founder <a href=\"https://profiles.wordpress.org/matt/\">Matt Mullenweg</a> will be jointly hosting <a href=\"https://make.wordpress.org/core/2020/12/15/regular-office-and-listening-hours/\">quarterly office and listening hours</a> in 2021. Sign-ups for the <a href=\"https://make.wordpress.org/core/2020/12/15/regular-office-and-listening-hours/\">first ones in January 2021</a> are almost filled up.</li><li>The Core team <a href=\"https://make.wordpress.org/core/2020/12/02/wp-notify-project-review/\">published updates</a> on the <a href=\"https://make.wordpress.org/core/tag/feature-notifications/\">WP Notify project</a>, which seeks to <a href=\"https://make.wordpress.org/core/2019/08/05/feature-project-proposal-wp-notify/\">improve the notifications system</a> in WordPress Core.</li><li>The Support team <a href=\"https://make.wordpress.org/support/2020/12/handling-potential-jquery-issues-in-wordpress-5-6/\">published a post</a> detailing jQuery issues in WordPress 5.6.</li><li><a href=\"https://india.wordcamp.org/2021/\">WordCamp India Online 2021</a> will be held over three weekends between January 30 and February 14. There will be workshops, a contributor event, and sessions (in that order). The calls for <a href=\"https://india.wordcamp.org/2021/call-for-sponsors/\">sponsors</a>, <a href=\"https://india.wordcamp.org/2021/call-for-workshops/\">workshop presenters</a>, <a href=\"https://india.wordcamp.org/2021/call-for-contributor-team-leads/\">contributor team leads</a>, and <a href=\"https://india.wordcamp.org/2021/call-for-volunteers/\">volunteers</a> are now open. Don’t forget to grab your <a href=\"https://india.wordcamp.org/2021/tickets/\">free tickets</a>!</li><li>The Documentation team <a href=\"https://make.wordpress.org/docs/2020/12/01/external-linking-policy-1st-review-of-plugin-developer-handbook/\">shared a first review</a> of its <a href=\"https://make.wordpress.org/docs/tag/external-linking-policy/\">external linking policy</a>. It is using the <a href=\"https://developer.wordpress.org/plugins/\">plugin developer handbook</a> as a test.</li></ul>



<p><br /><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it using this form</em></a><em>.</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 05 Jan 2021 10:55:56 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Hari Shanker R\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:48;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"WPTavern: WordPress.com Rattles Freelancer Community with New Website Building Service Launch\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=109818\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:231:\"https://wptavern.com/wordpress-com-rattles-freelancer-community-with-new-website-building-service-launch?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-com-rattles-freelancer-community-with-new-website-building-service-launch\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7137:\"<p>WordPress.com launched a new <a href=\"https://wordpress.com/built-by-wordpress-com/?utm_source=enblog&utm_medium=automattic_referred&utm_campaign=january_2021_launch&flags=a8c-analytics.on,ad-tracking,google-analytics&ga_optimize=on\">website building service</a> today with prices starting at $4,900. Automattic has been beta testing the service since the last quarter of 2020. The product <a href=\"https://wordpress.com/blog/2021/01/04/let-our-experts-build-your-dream-website/\">announcement</a> invites customers to let WordPress.com&rsquo;s&nbsp;professional team &ldquo;translate your vision into a compelling and modern website&rdquo; but does not specify pricing for more customized websites:</p>



<blockquote class=\"wp-block-quote\"><p>Whether you need a fast and performant eCommerce store for your products and/or services, a polished website for your professional services firm, or an educational website for your online courses, our experts can build it for you on WordPress.com, the most powerful platform for businesses and enterprises large and small.</p></blockquote>



<p>Initial reactions from the WordPress developer and freelance community were mixed. Some see the competition as good and others perceived it as a threat to WordPress consultants and small agencies, because a product from WordPress.com carries the full weight of the official WordPress brand. </p>



<p>&ldquo;Whether this succeeds or not there are a lot of folks with a sick stomach today because of it,&rdquo; WordPress developer Chris Wiegman <a href=\"https://twitter.com/ChrisWiegman/status/1346151976296443904\">said</a>.</p>



<p>Automattic stepping into the $5k website market came as a surprise to many, after years of keeping to the enterprise space with its <a href=\"https://wpvip.com/\">WordPress.com VIP</a> service. (Sometime in 2019 the service started going by &ldquo;WordPress VIP&rdquo; without the &ldquo;.com&rdquo; appended to it.) Freelancers haven&rsquo;t had to worry too much about competing against a large company like Automattic when trying to attract clients. It&rsquo;s also an interesting move because the company <a href=\"https://wptavern.com/automattic-has-discontinued-active-development-on-edit-flow-plugin\">seemed stretched thin</a> when it came to maintaining plugins used by VIP clients in 2019, despite seeing &ldquo;demand for WordPress in the enterprise market like never before,&rdquo; <a href=\"https://wptavern.com/automattic-has-discontinued-active-development-on-edit-flow-plugin#comment-307821\">according to Nick Gernert</a>, head of VIP. </p>



<p>&ldquo;Can&rsquo;t say I&rsquo;m surprised by this announcement, but it doesn&rsquo;t bode well for the community, to be honest,&rdquo; WordPress consultant Joshua Nelson <a href=\"https://twitter.com/onemorejosh/status/1346147871465353216\">said</a>. &ldquo;Freelancers will be hurt the most. A for instance: My custom built sites start at $3k. Once you factor in a designer that $4.9k rate looks very competitive.&rdquo;</p>



<p>In response to community concerns on Twitter, Automattic CEO Matt Mullenweg said the product is targeted at people who have a difficult time getting started with WordPress.</p>



<p>&ldquo;I would be extremely surprised if this impacts anyone&rsquo;s consulting business, if you do have a current or potential client leave for it please let me know &mdash; it should be all new-to-WP users who wouldn&rsquo;t have been successful getting started,&rdquo; Mullenweg <a href=\"https://twitter.com/photomatt/status/1346212091200491520\">said</a>. He also confirmed that the new service was set up for &ldquo;referring business out&rdquo; and referenced a previous experiment in 2018 where WordPress.com <a href=\"https://wordpress.com/support/upwork/\">partnered with Upwork</a> to refer clients for custom development.</p>



<div class=\"wp-block-embed__wrapper\">
https://twitter.com/photomatt/status/1346212543732170752
</div>



<p>The product launch lacked this information and some <a href=\"https://twitter.com/mattmedeiros/status/1346221279246999552\">noted</a> the copy was confusing with phrases like &ldquo;Built by us&rdquo; and &ldquo;Our experts can build it for you.&rdquo;</p>



<p>WordPress professionals took to <a href=\"https://poststatus.com/\">Post Status</a>&lsquo; Slack to discuss the implications of Automattic&rsquo;s new offering. Mullenweg responded to them, saying he is &ldquo;100% certain this will drive more up-market consulting in the future&rdquo; to consultants who handle larger projects and potentially bring more business to plugin and theme developers. He also noted that <a href=\"https://www.web.com/websites/website-design-services\">Bluehost&rsquo;s full service</a> product is a similar solution and that services like <a href=\"http://web.com/\">Web.com</a> have been competing in this space for awhile.</p>



<p>&ldquo;Typically these are called DIFM (do it for me) vs DIY (do it yourself),&rdquo; he said.</p>



<p>Automattic must be witnessing a strong demand for DIFM, as participants in the discussion at Post Status referenced Mullenweg&rsquo;s comments on the topic during his most recent <a href=\"https://wptavern.com/state-of-the-word-2020-wordpress-moves-toward-full-site-editing\">State of the Word</a> address delivered in December 2020:</p>



<blockquote class=\"wp-block-quote\"><p>Lots of people lost their jobs. Lots of people were looking to supplement their income. This drove an incredible amount of entrepreneurship, so people who were looking for people who knew WordPress. And on the other side of that, normal folks who knew or learned WordPress found that they had a lot to demand for their work, so they were able to supplement or replace their income, essentially for folks who have a do it for me mentality, so someone who is looking for someone else to build a website. It&rsquo;s never been a better time to learn and invest in improving your WordPress skills.</p></blockquote>



<p>The idea behind this product is to help those who get stuck with WordPress  before they turn to competitors that market website creation to beginners. It indicates that WordPress still has a long road ahead before it is truly an approachable tool for beginners embarking on their first site building experience.</p>



<p>Automattic has not published a pricing structure for the features included in a basic $4900 website. Based on images on the <a href=\"https://wordpress.com/built-by-wordpress-com/\">landing page</a>, the sites do not seem extensively customized beyond what existing themes offer. It seems like more of a website setup service and does not explicitly promise custom development.</p>



<p>When asked how agencies can apply to be put into the pipeline for referrals from WordPress.com&rsquo;s new service, Mullenweg indicated that the product is still in the experimental stage.</p>



<p>&ldquo;It&rsquo;s unclear if anyone wants this yet, so for this experiment don&rsquo;t have that yet,&rdquo; Mullenweg <a href=\"https://twitter.com/photomatt/status/1346258917135769600\">said</a>. &ldquo;If it works then definitely we will try to open it up.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 05 Jan 2021 04:40:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:49;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WPTavern: 2021: Reshaping the Tavern Experience\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=109489\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:137:\"https://wptavern.com/2021-reshaping-the-tavern-experience?utm_source=rss&utm_medium=rss&utm_campaign=2021-reshaping-the-tavern-experience\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4025:\"<img />



<p class=\"has-drop-cap\">Resolutions. Goals. Guidelines for the year ahead. Call them what you want. Not everyone takes part, but I am a firm believer in having a vision for the coming months. That vision can be malleable, flowing with the changes of time, yielding to new ideas as they are birthed. However, some large, beaming guideposts help when setting foot into the wild of a new year.</p>



<p>Our team at WP Tavern has gotten a bit of a breather over the holidays. We have an exciting project we are just getting off the ground. We set some things in motion months ago. Now, it is time to push forward.</p>



<p>Without going into all of the details, which are currently in flux, the following are the big goals for the site in 2021.</p>



<h2>New Design</h2>



<p class=\"has-drop-cap\">The biggest goal of 2021 is to add a fresh coat of paint to the website. Going hand in hand with that goal is to launch this new design 100% on blocks. To effectively write about WordPress&rsquo;s upcoming changes, we need to be ahead of the game. That means living a bit on the bleeding edge, running a block-based theme, and testing the site editor. It means sharing what we love and airing our frustrations.</p>



<p>Changing designs is not simply about slapping on some fresh colors. Design is about functionality. At the center of such a change is providing more tools for engagement.</p>



<p>We are thinking over multiple ideas about what this might look like, and we have a generous third-party team standing by to help us implement much of this. Some of those ideas are things like showing the top comments and trending forum topics. Feedback from our readers is more than welcome in this regard. Ultimately, this is the part of the Tavern experience that belongs to you.</p>



<p>The keen-eyed among you may have noticed I slipped in something about forum topics in the preceding paragraph. That was no accident. The return of the Tavern forums is a distinct possibility in 2021. There are many considerations we must make before going down this road around how it is moderated. The goal would be to provide an inviting atmosphere where people could freely talk about our beloved content management system. Again, this would be a feature of the site that is primarily about you.</p>



<h2>Podcast</h2>



<p class=\"has-drop-cap\">While many of you are avid readers of our content, we know some of you have asked us to bring back a podcast in some form. Some of you want to listen to WordPress-related news on your drive to work or while you unwind at the end of a busy day.</p>



<p>We heard you loud and clear.</p>



<p>Our team is actively pursuing adding a podcast. This is a project that we have been working on for a while now. It is something we genuinely want to happen.</p>



<p>Before exploring this project, I had no idea of the amount of work necessary for producing a professional podcast. If you had put me behind the mic a few months ago, I would just be shooting from the hip, hoping to hit a target, any target. I have a newfound respect for anyone who produces a podcast today.</p>



<p>If we get a new podcast off the ground in 2021, it will be a professionally-produced show. The goal is to have planned topics and guests representative of the diversity of the WordPress community. I am excited about the possibility.</p>



<h2>Welcome to 2021</h2>



<p class=\"has-drop-cap\">A new design and potential podcast are big-ticket items. They are not features we can launch overnight. When we do them, we want to do them right.</p>



<p>There are other items on the checklist we will likely get to throughout the year too. But, this is a point in the year where we should sit back and listen. Are there things you want to see changed about the Tavern experience? Are there topics we missed last year that you want to see us cover more?</p>



<p>As always, our team looks forward to bringing you our regular news, reviews, and opinions throughout the year. Stay tuned in for more.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 04 Jan 2021 21:36:33 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Thu, 28 Jan 2021 23:28:47 GMT\";s:12:\"content-type\";s:8:\"text/xml\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Thu, 28 Jan 2021 23:00:08 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 2\";s:16:\"content-encoding\";s:4:\"gzip\";}}s:5:\"build\";s:14:\"20201016172007\";}","no");
INSERT INTO `wp_options` VALUES("288","_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1611919730","no");
INSERT INTO `wp_options` VALUES("289","_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1611876530","no");
INSERT INTO `wp_options` VALUES("290","_transient_timeout_dash_v2_f69de0bbfe7eaa113146875f40c02000","1611919730","no");
INSERT INTO `wp_options` VALUES("291","_transient_dash_v2_f69de0bbfe7eaa113146875f40c02000","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://ru.wordpress.org/news/2020/12/learn-wordpress/\'>Представляем Learn WordPress</a></li><li><a class=\'rsswidget\' href=\'https://ru.wordpress.org/news/2020/10/2020-annual-survey/\'>Ежегодный опрос пользователей и разработчиков WordPress 2020</a></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wptavern.com/wp-lookout-lets-wordpress-users-track-and-receive-notifications-for-their-preferred-plugins-and-themes?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=wp-lookout-lets-wordpress-users-track-and-receive-notifications-for-their-preferred-plugins-and-themes\'>WPTavern: WP Lookout Lets WordPress Users Track and Receive Notifications for Their Preferred Plugins and Themes</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/elasticpress-io-service-considers-next-move-after-elasticsearch-abandons-open-source-licensing?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=elasticpress-io-service-considers-next-move-after-elasticsearch-abandons-open-source-licensing\'>WPTavern: ElasticPress.io Service Considers Next Move after Elasticsearch Abandons Open Source Licensing</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/automattic-launches-the-blank-canvas-wordpress-theme-for-building-single-page-websites?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=automattic-launches-the-blank-canvas-wordpress-theme-for-building-single-page-websites\'>WPTavern: Automattic Launches the Blank Canvas WordPress Theme for Building Single-Page Websites</a></li></ul></div>","no");
INSERT INTO `wp_options` VALUES("292","category_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("293","_transient_doing_cron","1613242753.2661020755767822265625","yes");


DROP TABLE IF EXISTS `wp_postmeta`;

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_postmeta` VALUES("1","2","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("2","3","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("3","5","_form","<label> Your name
    [text* your-name] </label>

<label> Your email
    [email* your-email] </label>

<label> Тема
    [text* your-subject] </label>

<label> Your message (optional)
    [textarea your-message] </label>

[submit \"Submit\"]");
INSERT INTO `wp_postmeta` VALUES("4","5","_mail","a:8:{s:7:\"subject\";s:30:\"[_site_title] \"[your-subject]\"\";s:6:\"sender\";s:38:\"[_site_title] <wordpress@protur.local>\";s:4:\"body\";s:187:\"От: [your-name] <[your-email]>
Тема: [your-subject]

Сообщение:
[your-message]

-- 
Это сообщение отправлено с сайта [_site_title] ([_site_url])\";s:9:\"recipient\";s:19:\"[_site_admin_email]\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";i:0;s:13:\"exclude_blank\";i:0;}");
INSERT INTO `wp_postmeta` VALUES("5","5","_mail_2","a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:30:\"[_site_title] \"[your-subject]\"\";s:6:\"sender\";s:38:\"[_site_title] <wordpress@protur.local>\";s:4:\"body\";s:128:\"Сообщение:
[your-message]

-- 
Это сообщение отправлено с сайта [_site_title] ([_site_url])\";s:9:\"recipient\";s:12:\"[your-email]\";s:18:\"additional_headers\";s:29:\"Reply-To: [_site_admin_email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";i:0;s:13:\"exclude_blank\";i:0;}");
INSERT INTO `wp_postmeta` VALUES("6","5","_messages","a:8:{s:12:\"mail_sent_ok\";s:92:\"Спасибо за Ваше сообщение. Оно успешно отправлено.\";s:12:\"mail_sent_ng\";s:144:\"При отправке сообщения произошла ошибка. Пожалуйста, попробуйте ещё раз позже.\";s:16:\"validation_error\";s:180:\"Одно или несколько полей содержат ошибочные данные. Пожалуйста, проверьте их и попробуйте ещё раз.\";s:4:\"spam\";s:144:\"При отправке сообщения произошла ошибка. Пожалуйста, попробуйте ещё раз позже.\";s:12:\"accept_terms\";s:132:\"Вы должны принять условия и положения перед отправкой вашего сообщения.\";s:16:\"invalid_required\";s:60:\"Поле обязательно для заполнения.\";s:16:\"invalid_too_long\";s:39:\"Поле слишком длинное.\";s:17:\"invalid_too_short\";s:41:\"Поле слишком короткое.\";}");
INSERT INTO `wp_postmeta` VALUES("7","5","_additional_settings","");
INSERT INTO `wp_postmeta` VALUES("8","5","_locale","ru_RU");
INSERT INTO `wp_postmeta` VALUES("9","2","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("10","2","_wp_trash_meta_time","1611876539");
INSERT INTO `wp_postmeta` VALUES("11","2","_wp_desired_post_slug","sample-page");
INSERT INTO `wp_postmeta` VALUES("12","3","_wp_trash_meta_status","draft");
INSERT INTO `wp_postmeta` VALUES("13","3","_wp_trash_meta_time","1611876543");
INSERT INTO `wp_postmeta` VALUES("14","3","_wp_desired_post_slug","privacy-policy");
INSERT INTO `wp_postmeta` VALUES("15","8","_edit_lock","1611876481:1");


DROP TABLE IF EXISTS `wp_posts`;

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_posts` VALUES("1","1","2021-01-27 07:04:56","2021-01-27 04:04:56","<!-- wp:paragraph -->
<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>
<!-- /wp:paragraph -->","Привет, мир!","","publish","open","open","","%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80","","","2021-01-27 07:04:56","2021-01-27 04:04:56","","0","http://protur.local/?p=1","0","post","","1");
INSERT INTO `wp_posts` VALUES("2","1","2021-01-27 07:04:56","2021-01-27 04:04:56","<!-- wp:paragraph -->
<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>...или так:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>Перейдите <a href=\"http://protur.local/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>
<!-- /wp:paragraph -->","Пример страницы","","trash","closed","open","","sample-page__trashed","","","2021-01-29 02:28:59","2021-01-28 23:28:59","","0","http://protur.local/?page_id=2","0","page","","0");
INSERT INTO `wp_posts` VALUES("3","1","2021-01-27 07:04:56","2021-01-27 04:04:56","<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Наш адрес сайта: http://protur.local.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие персональные данные мы собираем и с какой целью</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Комментарии</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email (\"хеш\") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Медиафайлы</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Формы контактов</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Куки</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность \"Запомнить меня\", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Встраиваемое содержимое других вебсайтов</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Веб-аналитика</h3><!-- /wp:heading --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда мы отправляем ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Ваша контактная информация</h2><!-- /wp:heading --><!-- wp:heading --><h2>Дополнительная информация</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Как мы защищаем ваши данные</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Какие принимаются процедуры против взлома данных</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>От каких третьих сторон мы получаем данные</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Какие автоматические решения принимаются на основе данных пользователей</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Требования к раскрытию отраслевых нормативных требований</h3><!-- /wp:heading -->","Политика конфиденциальности","","trash","closed","open","","privacy-policy__trashed","","","2021-01-29 02:29:03","2021-01-28 23:29:03","","0","http://protur.local/?page_id=3","0","page","","0");
INSERT INTO `wp_posts` VALUES("4","1","2021-01-27 07:05:19","0000-00-00 00:00:00","","Черновик","","auto-draft","open","open","","","","","2021-01-27 07:05:19","0000-00-00 00:00:00","","0","http://protur.local/?p=4","0","post","","0");
INSERT INTO `wp_posts` VALUES("5","1","2021-01-27 07:08:43","2021-01-27 04:08:43","<label> Your name
    [text* your-name] </label>

<label> Your email
    [email* your-email] </label>

<label> Тема
    [text* your-subject] </label>

<label> Your message (optional)
    [textarea your-message] </label>

[submit \"Submit\"]
[_site_title] \"[your-subject]\"
[_site_title] <wordpress@protur.local>
От: [your-name] <[your-email]>
Тема: [your-subject]

Сообщение:
[your-message]

-- 
Это сообщение отправлено с сайта [_site_title] ([_site_url])
[_site_admin_email]
Reply-To: [your-email]

0
0

[_site_title] \"[your-subject]\"
[_site_title] <wordpress@protur.local>
Сообщение:
[your-message]

-- 
Это сообщение отправлено с сайта [_site_title] ([_site_url])
[your-email]
Reply-To: [_site_admin_email]

0
0
Спасибо за Ваше сообщение. Оно успешно отправлено.
При отправке сообщения произошла ошибка. Пожалуйста, попробуйте ещё раз позже.
Одно или несколько полей содержат ошибочные данные. Пожалуйста, проверьте их и попробуйте ещё раз.
При отправке сообщения произошла ошибка. Пожалуйста, попробуйте ещё раз позже.
Вы должны принять условия и положения перед отправкой вашего сообщения.
Поле обязательно для заполнения.
Поле слишком длинное.
Поле слишком короткое.","Контактная форма 1","","publish","closed","closed","","%d0%ba%d0%be%d0%bd%d1%82%d0%b0%d0%ba%d1%82%d0%bd%d0%b0%d1%8f-%d1%84%d0%be%d1%80%d0%bc%d0%b0-1","","","2021-01-27 07:08:43","2021-01-27 04:08:43","","0","http://protur.local/?post_type=wpcf7_contact_form&p=5","0","wpcf7_contact_form","","0");
INSERT INTO `wp_posts` VALUES("6","1","2021-01-29 02:28:59","2021-01-28 23:28:59","<!-- wp:paragraph -->
<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>...или так:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>Перейдите <a href=\"http://protur.local/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>
<!-- /wp:paragraph -->","Пример страницы","","inherit","closed","closed","","2-revision-v1","","","2021-01-29 02:28:59","2021-01-28 23:28:59","","2","http://protur.local/2021/01/29/2-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("7","1","2021-01-29 02:29:03","2021-01-28 23:29:03","<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Наш адрес сайта: http://protur.local.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие персональные данные мы собираем и с какой целью</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Комментарии</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email (\"хеш\") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Медиафайлы</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Формы контактов</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Куки</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность \"Запомнить меня\", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Встраиваемое содержимое других вебсайтов</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Веб-аналитика</h3><!-- /wp:heading --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда мы отправляем ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Ваша контактная информация</h2><!-- /wp:heading --><!-- wp:heading --><h2>Дополнительная информация</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Как мы защищаем ваши данные</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Какие принимаются процедуры против взлома данных</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>От каких третьих сторон мы получаем данные</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Какие автоматические решения принимаются на основе данных пользователей</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Требования к раскрытию отраслевых нормативных требований</h3><!-- /wp:heading -->","Политика конфиденциальности","","inherit","closed","closed","","3-revision-v1","","","2021-01-29 02:29:03","2021-01-28 23:29:03","","3","http://protur.local/2021/01/29/3-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("8","1","2021-01-29 02:30:15","0000-00-00 00:00:00","","Главная","","draft","closed","closed","","","","","2021-01-29 02:30:15","2021-01-28 23:30:15","","0","http://protur.local/?page_id=8","0","page","","0");


DROP TABLE IF EXISTS `wp_term_relationships`;

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_term_relationships` VALUES("1","1","0");


DROP TABLE IF EXISTS `wp_term_taxonomy`;

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_term_taxonomy` VALUES("1","1","category","","0","1");


DROP TABLE IF EXISTS `wp_termmeta`;

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_terms`;

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_terms` VALUES("1","Без рубрики","%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8","0");


DROP TABLE IF EXISTS `wp_usermeta`;

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_usermeta` VALUES("1","1","nickname","admin");
INSERT INTO `wp_usermeta` VALUES("2","1","first_name","");
INSERT INTO `wp_usermeta` VALUES("3","1","last_name","");
INSERT INTO `wp_usermeta` VALUES("4","1","description","");
INSERT INTO `wp_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("6","1","syntax_highlighting","true");
INSERT INTO `wp_usermeta` VALUES("7","1","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("8","1","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("9","1","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("10","1","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES("11","1","locale","");
INSERT INTO `wp_usermeta` VALUES("12","1","wp_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("13","1","wp_user_level","10");
INSERT INTO `wp_usermeta` VALUES("14","1","dismissed_wp_pointers","theme_editor_notice");
INSERT INTO `wp_usermeta` VALUES("15","1","show_welcome_panel","1");
INSERT INTO `wp_usermeta` VALUES("16","1","session_tokens","a:1:{s:64:\"7ba34de493be8a478c8ebdbeec7177d43b782777d70e772ee16f915800927bdb\";a:4:{s:10:\"expiration\";i:1612929915;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36\";s:5:\"login\";i:1611720315;}}");
INSERT INTO `wp_usermeta` VALUES("17","1","wp_dashboard_quick_press_last_post_id","4");
INSERT INTO `wp_usermeta` VALUES("18","1","community-events-location","a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}");
INSERT INTO `wp_usermeta` VALUES("19","1","closedpostboxes_page","a:1:{i:0;s:10:\"wpXSG-meta\";}");
INSERT INTO `wp_usermeta` VALUES("20","1","metaboxhidden_page","a:0:{}");


DROP TABLE IF EXISTS `wp_users`;

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_users` VALUES("1","admin","$P$Be0lypHZHAPy4gJtHr0i2xwsGGV90V1","admin","d359753@gmail.com","http://protur.local","2021-01-27 04:04:55","","0","admin");


DROP TABLE IF EXISTS `wp_xsg_sitemap_meta`;

CREATE TABLE `wp_xsg_sitemap_meta` (
  `itemId` int(11) DEFAULT 0,
  `inherit` int(11) DEFAULT 0,
  `itemType` varchar(8) DEFAULT '',
  `exclude` int(11) DEFAULT 0,
  `priority` int(11) DEFAULT 0,
  `frequency` int(11) DEFAULT 0,
  UNIQUE KEY `idx_xsg_sitemap_meta_ItemId_ItemType` (`itemId`,`itemType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='generatated by XmlSitemapGenerator.org';



